package com.ebao.austin.batch;

import com.ebao.pub.batch.help.BatchHelp;
import com.ebao.pub.batch.help.PieceableBatchProgram;
import com.ebao.pub.batch.help.SelfPieceBatchProgram;
import com.ebao.pub.batch.type.JobStatus;

public class AustinSelfPieceBatchProgram extends AustinSuperBatch implements SelfPieceBatchProgram {

	@Override
	public int gainIds() throws Exception {
		this.logInfo("gainIds...");
		String[] ids = new String[]{"A", "B", "C", "D", "E"};
		BatchHelp.saveIdentities2Database(ids);
		return JobStatus.EXECUTE_SUCCESS;
	}

	@Override
	public int exeSingleRecord(String arg0) throws Exception {
		return JobStatus.EXECUTE_SUCCESS;
	}

	@Override
	public int postProcess() throws Exception {
		return JobStatus.EXECUTE_SUCCESS;
	}

	@Override
	public int preProcess() throws Exception {
		return JobStatus.EXECUTE_SUCCESS;
	}

	@Override
	public int pieceJob() {

		System.out.println("Thread["+Thread.currentThread().getName() + "] executed : "+System.currentTimeMillis());
		return JobStatus.EXECUTE_SUCCESS;
	}

}
