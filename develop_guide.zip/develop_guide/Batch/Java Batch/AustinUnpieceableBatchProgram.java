package com.ebao.austin.batch;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.transaction.UserTransaction;

import com.ebao.pub.batch.help.BatchHelp;
import com.ebao.pub.batch.job.BaseUnpieceableJob;
import com.ebao.pub.batch.type.JobStatus;
import com.ebao.pub.batch.type.LogLevel;
import com.ebao.pub.batch.util.BatchLogUtils;
import com.ebao.pub.framework.AppContext;
import com.ebao.pub.framework.ExceptionFactory;
import com.ebao.pub.framework.GenericException;
import com.ebao.pub.util.Trans;

public class AustinUnpieceableBatchProgram extends BaseUnpieceableJob {

	@Override
	public int exeSingleRecord(String arg0) throws Exception {
		System.out.println(String.format("exeSingleRecord([%s])", arg0));
		return JobStatus.EXECUTE_SUCCESS;
	}

	@Override
	public int postProcess() throws Exception {
		System.out.println("postProcess");
		return JobStatus.EXECUTE_SUCCESS;
	}

	@Override
	public int preProcess() throws Exception {
		System.out.println("preProcess");
		return JobStatus.EXECUTE_SUCCESS;
	}

	@Override
	public int mainProcess() throws Exception {
		BaseUnpieceableJob b;

		int intBatchResult = 0;
		String prarmeter1 = BatchHelp.getParameter("1");
		BatchLogUtils.addLog(LogLevel.INFO, null,
				String.format("mainProcess test, param 1 : [%s]", prarmeter1));

		Date processDate = BatchHelp.getProcessDate();
		List policyIdList = new ArrayList();
		BatchLogUtils.addLog(LogLevel.WARN, null, "a new list");
		try {
			policyIdList = findAllPolicy(prarmeter1);
		} catch (NumberFormatException e) {
			GenericException ex = ExceptionFactory.parse(e);
			intBatchResult = 2;
			BatchLogUtils.addLog(LogLevel.ERROR, null, ex.getMessage());
		}
		UserTransaction trans = Trans.getUserTransaction();
		for (Iterator it = policyIdList.iterator(); it.hasNext();) {
			Long policyId = (Long) it.next();
			try {
				trans.begin();
				// process each policy.
				long result = process(policyId, processDate);
				BatchLogUtils.addLog(LogLevel.INFO, null,
						String.valueOf(result) + policyId);
				trans.commit();
				// Integer.parseInt("a");
			} catch (Exception e) {
				BatchLogUtils.addLog(LogLevel.ERROR, null, e.getMessage()
						+ policyId);
				try {
					trans.rollback();
					intBatchResult = 1;
				} catch (Exception ex) {
					throw ExceptionFactory.parse(ex);
				}
			}
		}
		int result = -1;
		if (intBatchResult == 0) {
			result = JobStatus.EXECUTE_SUCCESS;
			BatchHelp.setResult("success without any warning");
		} else if (intBatchResult == 1) {
			result = JobStatus.EXECUTE_PARTIAL_SUCESS;
			BatchHelp.setResult("partial success");
		} else {
			result = JobStatus.EXECUTE_FAILED;
			BatchHelp.setResult("fail to execute");
		}
		return result;

	}

	protected List findAllPolicy(String param) throws NumberFormatException {
		List list = new ArrayList();
		list.add(new Long(param));
		return list;
	}

	protected long process(Long policyId, Date processDate)
			throws GenericException {
		if (processDate.before(AppContext.getCurrentUserLocalTime())) {
			return policyId.longValue();
		}
		return 0;
	}

}
