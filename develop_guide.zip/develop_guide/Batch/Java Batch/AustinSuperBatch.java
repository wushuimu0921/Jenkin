package com.ebao.austin.batch;

import com.ebao.foundation.core.logging.Log;
import com.ebao.pub.batch.type.LogLevel;
import com.ebao.pub.batch.util.BatchLogUtils;

public class AustinSuperBatch {

	
	private Log logger = Log.getLogger(this.getClass());
	
	protected void logInfo(String message, String... params) {
		String logString = String.format(message, params);
		
		logger.info(logString);
		BatchLogUtils.addLog(LogLevel.INFO, null, logString);
	}
	
	
}
