package com.ebao.austin.batch;

import com.ebao.pub.batch.help.BatchHelp;
import com.ebao.pub.batch.help.PieceableBatchProgram;
import com.ebao.pub.batch.type.JobStatus;

/**
 * Bean name : austinPieceableBatchJob
 * @author tgl04
 *
 */
public class AustinPieceableBatchJob extends AustinSuperBatch implements PieceableBatchProgram {

	@Override
	public int exeSingleRecord(String arg0) throws Exception {

		this.logInfo("exeSingleRecord[%s]", arg0);
		
		return JobStatus.EXECUTE_SUCCESS;
	}

	@Override
	public int postProcess() throws Exception {
		return JobStatus.EXECUTE_SUCCESS;
	}

	@Override
	public int preProcess() throws Exception {
		return JobStatus.EXECUTE_SUCCESS;
	}

	@Override
	public int gainIds() throws Exception {

		this.logInfo("gainIds...");
		String[] ids = new String[]{"A", "B", "C", "D", "E"};
		BatchHelp.saveIdentities2Database(ids);
		
		return JobStatus.EXECUTE_SUCCESS;
	}

}
