# jenkins-pipeline-examples
A collection of examples scripting for the Jenkins Pipeline.
