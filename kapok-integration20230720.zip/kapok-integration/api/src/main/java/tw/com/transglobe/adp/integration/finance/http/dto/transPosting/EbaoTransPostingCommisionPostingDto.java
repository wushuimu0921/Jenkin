package tw.com.transglobe.adp.integration.finance.http.dto.transPosting;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EbaoTransPostingCommisionPostingDto {

  @Schema(description = "成功筆數")
  Integer successCount;

  @Schema(description = "失敗筆數")
  Integer failCount;

  @Schema(description = "總筆數")
  Integer totalCount;

  List<EbaoTransPostingResultDto> postingResult;
}
