package tw.com.transglobe.adp.integration.liaroc2.http.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class Liaroc2UploadFailDto {

  @Schema(description = "產壽險別")
  String cmptype;

  @Schema(description = "公司代號")
  String cmpno;

  @Schema(description = "被保險人身分證字號")
  String idno;

  @Schema(description = "被保險人出生日期")
  String birdate;

  @Schema(description = "保單號碼")
  String insno;

  @Schema(description = "保單分類")
  String insclass;

  @Schema(description = "險種分類")
  String inskind;

  @Schema(description = "險種")
  String insitem;

  @Schema(description = "公會回傳的處理代碼")
  String code;

  @Schema(description = "公會回傳的錯誤訊息")
  String msg;

}
