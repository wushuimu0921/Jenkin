package tw.com.transglobe.adp.integration.liaroc2.enums;

public enum TodayMode {

  TodayMode_0(0), //不分日期(預設)
  TodayMode_1(1); //當日

  Integer value;

  private TodayMode(Integer value) {
    this.value = value;
  }

  public Integer getValue() {
    return this.value;
  }

}
