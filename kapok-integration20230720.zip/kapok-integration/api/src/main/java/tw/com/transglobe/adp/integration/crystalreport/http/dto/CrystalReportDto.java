package tw.com.transglobe.adp.integration.crystalreport.http.dto;

import lombok.Data;

@Data
public class CrystalReportDto {
  byte[] file;
}
