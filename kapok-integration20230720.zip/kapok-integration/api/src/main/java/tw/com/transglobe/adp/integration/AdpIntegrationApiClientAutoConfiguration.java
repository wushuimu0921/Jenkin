package tw.com.transglobe.adp.integration;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Configuration;

@EnableFeignClients
@ConditionalOnProperty("transglobe.adp.integration.api-client.enabled")
@Configuration(proxyBeanMethods = false)
@EnableConfigurationProperties(AdpIntegrationApiClientProperties.class)
class AdpIntegrationApiClientAutoConfiguration {

}
