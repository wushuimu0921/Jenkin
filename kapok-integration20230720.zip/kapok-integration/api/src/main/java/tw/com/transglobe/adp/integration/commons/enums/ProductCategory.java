package tw.com.transglobe.adp.integration.commons.enums;

public enum ProductCategory { //商品大類
  T,
  V
}
