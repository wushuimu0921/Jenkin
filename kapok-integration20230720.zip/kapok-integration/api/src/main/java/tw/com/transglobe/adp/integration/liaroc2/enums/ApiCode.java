package tw.com.transglobe.adp.integration.liaroc2.enums;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Schema(description = "公會API編號")
public enum ApiCode {

  @Schema(description = "上傳「保險存摺保單基本資料-1」資料")
  A_902("902"),

  @Schema(description = "查詢未上傳資料總筆數")
  A_904("904"),

  @Schema(description = "取得未上傳資料清單")
  A_905("905");

  @Getter
  final String code;

}
