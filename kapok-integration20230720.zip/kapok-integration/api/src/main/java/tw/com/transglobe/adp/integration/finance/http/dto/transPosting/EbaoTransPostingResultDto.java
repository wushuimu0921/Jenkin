package tw.com.transglobe.adp.integration.finance.http.dto.transPosting;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import tw.com.transglobe.adp.integration.commons.enums.YesNo;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EbaoTransPostingResultDto {

  @Schema(description = "過帳狀態")
  YesNo posted;

  @Schema(description = "eBao的Int表流水號")
  Long feeId;

  @Schema(description = "團旅險提供")
  String refId;

  @Schema(description = "需要合併時的合併後表的流水號")
  Long adpFeeId;

  @Schema(description = "交易狀態名稱")
  String statusName;

  @Schema(description = "交易狀態代碼")
  Integer statusCode;

  @Schema(description = "實際過帳日期")
  String accountGlDate;

  @Schema(description = "付款方式代碼")
  String payMode;

  @Schema(description = "付款方式名稱")
  String payModeName;

  @Schema(description = "變更前支票狀態代碼")
  String oriChequeStatus;

  @Schema(description = "變更前支票狀態名稱")
  String oriChequeStatusName;

  @Schema(description = "變更後支票狀態代碼")
  String afterChequeStatus;

  @Schema(description = "變更後支票狀態名稱")
  String afterChequeStatusName;
}
