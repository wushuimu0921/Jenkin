package tw.com.transglobe.adp.integration.kmiddle.http.dto;

import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class KmiddlePolicyDto {

  String policyNo;
  LocalDate effTime;
  String localName;
  LocalDate birthday;

}
