package tw.com.transglobe.adp.integration.finance.http.dto.transPayment;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;
import io.swagger.v3.oas.annotations.media.Schema;

@Data
@Builder
@Schema(description = "付款結果查詢結果")
public class EbaoFinancePaymentResultDto {

  @Schema(description = "付款日期")
  LocalDate paymentDate;

  @Schema(description = "保單號碼")
  String policyCode;

  @Schema(description = "付款結果查詢結果資料")
  @Builder.Default
  EbaoTransPaymentResultInfoDto paymentResultInfo = EbaoTransPaymentResultInfoDto.builder().build();
}
