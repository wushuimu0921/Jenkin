package tw.com.transglobe.adp.integration.finance.http.req;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class EbaoFinancePayableRequest {

  @Schema(description = "保單號碼")
  String policyNo;

  @Schema(description = "應付資料")
  List<EbaoFinanceAparRequest> aparRequests;

  @Schema(description = "實付資料")
  List<EbaoFinancePaymentRequest> payRequests;
}
