package tw.com.transglobe.adp.integration.commons.enums;

public enum ServiceId {

  SERVICE_ID_1(1);

  Integer value;

  private ServiceId(Integer value) {
    this.value = value;
  }

  public Integer getValue() {
    return this.value;
  }
}
