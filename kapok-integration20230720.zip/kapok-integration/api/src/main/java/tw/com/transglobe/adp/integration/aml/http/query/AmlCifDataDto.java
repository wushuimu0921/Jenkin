package tw.com.transglobe.adp.integration.aml.http.query;

import java.util.Map;
import javax.validation.constraints.NotEmpty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;
import tw.com.transglobe.adp.integration.aml.enums.AmlIdentType;

@Schema(description = "AML CIF 資料")
@Data
@Builder
public class AmlCifDataDto {

  @NotEmpty
  @Schema(description = "客戶的身份證字號, 不得為空白, 如果沒有身份證字號, 請自行編寫 建議為 ADP-GI-{id}")
  String idno;

  @Schema(description = "當 rel 時, 需要給予此筆客戶資料是個人還是法人")
  AmlIdentType type;

  @Schema(description = "客戶附屬欄位資訊")
  Map<String, String> fields;

}
