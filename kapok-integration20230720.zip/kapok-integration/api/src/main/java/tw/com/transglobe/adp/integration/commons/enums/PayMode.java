package tw.com.transglobe.adp.integration.commons.enums;

public enum PayMode {

  PAY_MODE_1(1), // 現金
  PAY_MODE_2(2), // 票據
  PAY_MODE_3(3), // 銀行轉帳
  PAY_MODE_5(5), // 內部轉帳
  PAY_MODE_7(7), // 匯款
  PAY_MODE_15(15), // 劃撥
  PAY_MODE_22(22), // 銀行離櫃
  PAY_MODE_23(23), // eATM 線上繳款
  PAY_MODE_24(24), // ATM (自動櫃員機)
  PAY_MODE_25(25), // 便利商店
  PAY_MODE_30(30), // 信用卡
  PAY_MODE_94(94), // 回籠票
  PAY_MODE_95(95); // 全國繳費網

  Integer value;

  private PayMode(Integer value) {
    this.value = value;
  }

  public Integer getValue() {
    return this.value;
  }

}
