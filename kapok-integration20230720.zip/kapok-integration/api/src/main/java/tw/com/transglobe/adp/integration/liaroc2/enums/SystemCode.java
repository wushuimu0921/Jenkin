package tw.com.transglobe.adp.integration.liaroc2.enums;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "來源模組系統名稱")
public enum SystemCode {

  @Schema(description = "易保")
  EBAO,

  @Schema(description = "EC")
  EC,

  @Schema(description = "團險")
  GRP,

  @Schema(description = "旅平")
  TRV

}
