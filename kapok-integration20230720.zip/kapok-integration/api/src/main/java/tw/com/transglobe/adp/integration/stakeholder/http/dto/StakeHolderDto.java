package tw.com.transglobe.adp.integration.stakeholder.http.dto;

import lombok.Builder;
import lombok.Data;

@Data
public class StakeHolderDto {

  Long id;

  String caseId;

  String userId;

  String userName;

  String userIdno;

  String userCompanyLocalName;

  String userCompanyEngName;

  String familyIdno;

  String familyName;

  String familyRelationshipType;

  String familyCompanyLocalName;

  String familyCompanyEngName;
}
