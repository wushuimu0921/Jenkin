package tw.com.transglobe.adp.integration.aml.enums;

public enum AmlIdentType {

  I, // 個人
  C // 公司
}
