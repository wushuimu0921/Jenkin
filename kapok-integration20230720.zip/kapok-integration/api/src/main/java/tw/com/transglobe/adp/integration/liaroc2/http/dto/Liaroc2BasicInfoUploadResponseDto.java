package tw.com.transglobe.adp.integration.liaroc2.http.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import tw.com.transglobe.adp.integration.liaroc2.enums.Module;
import tw.com.transglobe.adp.integration.liaroc2.enums.SystemCode;

@Data
public class Liaroc2BasicInfoUploadResponseDto {

  @Schema(description = "來源模組系統名稱")
  SystemCode systemId;

  @Schema(description = "來源模組單位")
  Module module;

  @Schema(description = "來源序號")
  String rqUid;

  @Schema(description = "上傳公會總筆數")
  Integer total;

  @Schema(description = "上傳公會成功筆數")
  Integer success;

  @Schema(description = "上傳公會失敗筆數")
  Integer fail;

  @Schema(description = "call 公會API失敗的筆數")
  Integer apiFailDataSize;

  @Schema(description = "現在 liaroc2.0 系統處理狀態")
  String processStatus;

  @Schema(description = "執行的錯誤訊息")
  String processErrorMsg;

  @Schema(description = "公會回傳的失敗件清單")
  List<Liaroc2BasicInfoUploadErrorResponseDto> failResDatas = new ArrayList<>();

}
