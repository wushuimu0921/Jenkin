package tw.com.transglobe.adp.integration.commons.enums;

public enum MoneyId {

  MONEY_ID_CNY(1),
  MONEY_ID_USD(4),
  MONEY_ID_TWD(8);

  Integer value;

  private MoneyId(Integer value) {
    this.value = value;
  }

  public Integer getValue() {
    return this.value;
  }

}
