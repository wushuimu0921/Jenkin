package tw.com.transglobe.adp.integration.aml.http;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import tw.com.transglobe.adp.integration.aml.http.dto.AmlCifResponse;
import tw.com.transglobe.adp.integration.aml.http.query.AmlQueryRequest;

@Tag(name = "AmlApi", description = "AML API")
public interface AmlApi {
  @Operation(summary = "AML API", description = "查詢是否為洗錢風險名單")
  @PostMapping("/aml")
  AmlCifResponse checkAml(@RequestBody AmlQueryRequest request);
}

@FeignClient(name = "aml-application", url = "${transglobe.adp.integration.api-client.url}")
interface AmlApplicationClient extends AmlApi {

}
