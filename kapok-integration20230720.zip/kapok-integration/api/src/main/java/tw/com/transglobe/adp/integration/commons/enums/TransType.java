package tw.com.transglobe.adp.integration.commons.enums;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
@Schema(description = "收付費類型")
public enum TransType {

  @Schema(description = "收費")
  RECEIVABLE("C"),

  @Schema(description = "付費")
  PAYABLE("P");

  private final String code;

}
