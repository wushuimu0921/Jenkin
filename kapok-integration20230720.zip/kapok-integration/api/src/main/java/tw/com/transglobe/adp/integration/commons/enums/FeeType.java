package tw.com.transglobe.adp.integration.commons.enums;

public enum FeeType {

  FEE_TYPE_7(7), // 存入保單帳戶
  FEE_TYPE_8(8), // 保單帳戶領取-本金
  FEE_TYPE_9(9), // 存款利息領取
  FEE_TYPE_10(10), // 體檢及報告費用
  FEE_TYPE_11(11), // 收費
  FEE_TYPE_12(12), // 懸帳退費
  FEE_TYPE_13(13), // 交割前失效懸帳退費
  FEE_TYPE_14(14), // 交割後失效懸帳退費
  FEE_TYPE_15(15), // 無效懸帳退費
  FEE_TYPE_16(16), // 債權扣押懸帳退費
  FEE_TYPE_18(18), // 保單帳戶領取-利息
  FEE_TYPE_21(21), // 首期暫收到帳保費
  FEE_TYPE_32(32), // 付款
  FEE_TYPE_33(33), // 自動墊繳/保單借款
  FEE_TYPE_38(38), // 自動墊繳/保單借款還本
  FEE_TYPE_39(39), // 自動墊繳/保單借款還息
  FEE_TYPE_41(41), // 保費收入（傳統、投資參考）
  FEE_TYPE_42(42), // 退還保費(傳統、投資參考)
  FEE_TYPE_43(43), // 保全更約權舊單金額轉入新單（舊單價值<新單保費）
  FEE_TYPE_51(51), // 退保價金/解約金
  FEE_TYPE_52(52), // 解約金（PUA）
  FEE_TYPE_53(53), // 欠繳利息
  FEE_TYPE_56(56), // 工本費
  FEE_TYPE_61(61), // 復效危險保費收費
  FEE_TYPE_62(62), // 復效危險保費退費
  FEE_TYPE_69(69), // 彈性保費
  FEE_TYPE_70(70), // 投資型解約/部分解約退AV
  FEE_TYPE_71(71), // 理賠責任金
  FEE_TYPE_72(72), // 紅利/生存金/活力金分配
  FEE_TYPE_73(73), // 補償金
  FEE_TYPE_76(76), // 保費GST
  FEE_TYPE_77(77), // 保費GST退還
  FEE_TYPE_81(81), // 分期付款
  FEE_TYPE_82(82), // 保證提領-保證給付
  FEE_TYPE_83(83), // 年金
  FEE_TYPE_85(85), // 滿期金淨值
  FEE_TYPE_86(86), // 理賠金淨值
  FEE_TYPE_87(87), // 理賠欠費
  FEE_TYPE_107(107), // 餘額帳戶沖銷
  FEE_TYPE_108(108), // 撤銷多餘的費種類
  FEE_TYPE_110(110), // 醫療矯正沖銷
  FEE_TYPE_118(118), // 雇主費
  FEE_TYPE_120(120), // Penalty fee
  FEE_TYPE_121(121), // Dunning fee
  FEE_TYPE_154(154), // 轉移未理賠的金額
  FEE_TYPE_155(155), // 未理賠金額
  FEE_TYPE_176(176), // 執行人工抽檔
  FEE_TYPE_177(177), // 滿期 O/S轉至滿期帳戶
  FEE_TYPE_179(179), // CPF成本計算，利潤，虧損交易
  FEE_TYPE_180(180), // 滿期金抵繳應收
  FEE_TYPE_181(181), // 其他應付款轉滿期金應付
  FEE_TYPE_183(183), // 首期保費短繳補費
  FEE_TYPE_184(184), // 儲蓄帳戶餘額
  FEE_TYPE_187(187), // 理賠分期貼現
  FEE_TYPE_188(188), // 代扣延滯息所得稅
  FEE_TYPE_189(189), // 滿期WHT
  FEE_TYPE_190(190), // 滿期淨利息
  FEE_TYPE_192(192), // 保額紅利滿期
  FEE_TYPE_193(193), // 終了紅利滿期
  FEE_TYPE_194(194), // 满期金
  FEE_TYPE_195(195), // 理賠金抵繳應收
  FEE_TYPE_196(196), // 其他應付款轉理賠應付
  FEE_TYPE_197(197), // 理賠O/S轉至期繳O/S
  FEE_TYPE_198(198), // 失效處理 - 自動墊繳/保單借款本金
  FEE_TYPE_199(199), // 儲蓄沖銷
  FEE_TYPE_200(200), // 新契約保費短繳墊繳
  FEE_TYPE_201(201), // DC保費短繳墊繳
  FEE_TYPE_235(235), // 保費憑證和借方代理人付款
  FEE_TYPE_258(258), // 提供債務失效保單沖銷
  FEE_TYPE_259(259), // 撤銷提供債務失效保單沖銷
  FEE_TYPE_260(260), // 理賠O/S轉移
  FEE_TYPE_261(261), // 延滯息
  FEE_TYPE_270(270), // 責任準備金退費
  FEE_TYPE_541(541), // 投資保費
  FEE_TYPE_561(561), // 體檢費
  FEE_TYPE_562(562), // 撤件費
  FEE_TYPE_563(563), // 工本費
  FEE_TYPE_569(569), // 定期超額保險費
  FEE_TYPE_570(570), // 契撤保費(定期超額保險費)
  FEE_TYPE_711(711), // 保額紅利滿期付款
  FEE_TYPE_712(712), // 終了紅利理賠付款
  FEE_TYPE_720(720), // 理賠調查費用
  FEE_TYPE_721(721), // 理賠調查行政手續費
  FEE_TYPE_722(722), // 帳簿利潤和虧空
  FEE_TYPE_761(761), // 服務費
  FEE_TYPE_762(762), // 代扣印花稅
  FEE_TYPE_763(763), // Income Tax
  FEE_TYPE_764(764), // Insurance tax
  FEE_TYPE_769(769), // 代扣所得稅
  FEE_TYPE_770(770), // Withholding Tax Reverse
  FEE_TYPE_771(771), // 服務稅退費
  FEE_TYPE_772(772), // 印花稅退費
  FEE_TYPE_773(773), // 手續費
  FEE_TYPE_774(774), // Insurance tax payment
  FEE_TYPE_777(777), // 無保單收費退費
  FEE_TYPE_780(780), // 無理賠優惠
  FEE_TYPE_781(781), // 投資不足額還款
  FEE_TYPE_782(782), // 溢付年金追扣
  FEE_TYPE_783(783), // 溢付生存金/活力金理賠追扣
  FEE_TYPE_784(784), // 溢付滿期金理賠追扣
  FEE_TYPE_785(785), // 代扣二代健保補充保費（理賠）
  FEE_TYPE_786(786), // 理賠金回退
  FEE_TYPE_787(787), // 代扣印花稅(理賠)
  FEE_TYPE_788(788), // 雜收退費
  FEE_TYPE_789(789), // 無理賠優惠追扣
  FEE_TYPE_790(790), // 豁免保費給付
  FEE_TYPE_791(791), // 契撤保費（投資彈性）
  FEE_TYPE_792(792), // 保單重置費（應追扣佣金）
  FEE_TYPE_793(793), // 理賠投資贖回未決行準備金
  FEE_TYPE_794(794), // 理賠投資贖回待決行
  FEE_TYPE_795(795), // 自動墊繳/保單借款利息豁免
  FEE_TYPE_796(796), // 已發放的即期年金追回
  FEE_TYPE_797(797), // 已發放的生存金追回
  FEE_TYPE_798(798), // 已給付之理賠金追回
  FEE_TYPE_799(799), // 派員收費件自行繳納折扣
  FEE_TYPE_800(800), // 配現退費
  FEE_TYPE_801(801), // 周轉金撥補
  FEE_TYPE_802(802), // 區隔過渡調整（Company 0與6不平）
  FEE_TYPE_803(803), // 退匯手續費（收回）
  FEE_TYPE_804(804), // 未達帳逾二年轉列收入
  FEE_TYPE_805(805), // 應收票據未決轉催收
  FEE_TYPE_808(808), // 商品大類過渡調整（傳統/投資）
  FEE_TYPE_809(809), // 區隔過渡調整 （Company 0 與K不平）
  FEE_TYPE_810(810), // 應付佣金轉實付區隔調整 （Company）
  FEE_TYPE_811(811), // 保價金差額補費
  FEE_TYPE_813(813), // 內部轉帳過渡調整
  FEE_TYPE_814(814), // 應付佣金轉實付帳本幣調整 （GL Currency)
  FEE_TYPE_815(815), // 帳本幣過渡調整 （GL Currency)
  FEE_TYPE_816(816), // 復效ADM
  FEE_TYPE_817(817), // 復效COI
  FEE_TYPE_818(818), // 營業費用
  FEE_TYPE_819(819), // 復效ADM/COI退費
  FEE_TYPE_820(820), // 失效處理 - 自動墊繳/保單借款利息
  FEE_TYPE_821(821), // 失效處理 - 投資不足額
  FEE_TYPE_822(822), // SVSUS贖回過渡調整
  FEE_TYPE_823(823), // 應付票據（For DC導入）
  FEE_TYPE_824(824), // 應收票據（For DC導入）
  FEE_TYPE_825(825), // 身故後年金
  FEE_TYPE_826(826), // 更約權轉新單(原承保日)過渡調整
  FEE_TYPE_827(827), // 更約權轉新單(原承保日)保價金差額
  FEE_TYPE_828(828), // 投資不足額還款 (基金部位)
  FEE_TYPE_829(829), // 失效處理 - 投資不足額(基金部位)
  FEE_TYPE_832(832), // 爭議件差額支付
  FEE_TYPE_833(833), // 爭議件差額收回
  FEE_TYPE_834(834), // 回籠票過渡調整-轉出
  FEE_TYPE_835(835), // 回籠票過渡調整-轉入
  FEE_TYPE_836(836), // 投資型帳戶價值
  FEE_TYPE_837(837), // 保險成本
  ;

  Integer value;

  private FeeType(Integer value) {
    this.value = value;
  }

  public Integer getValue() {
    return this.value;
  }

}
