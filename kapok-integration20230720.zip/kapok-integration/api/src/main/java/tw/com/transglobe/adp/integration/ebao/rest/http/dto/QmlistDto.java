package tw.com.transglobe.adp.integration.ebao.rest.http.dto;

import java.time.LocalDate;
import lombok.Data;
import tw.com.transglobe.adp.integration.ebao.rest.enums.QmlistType;

@Data
public class QmlistDto {

  QmlistType type;

  String idno;

  String idnoType;

  String agentNo;

  String channelCode;

  String channelName;

  String localName;

  LocalDate birthday;

  String cause;

  String causeDescription;

  String source;

  String sourceDescription;

  LocalDate effDate;

  LocalDate expDate;

  String remark;

  String sourceListId;
}
