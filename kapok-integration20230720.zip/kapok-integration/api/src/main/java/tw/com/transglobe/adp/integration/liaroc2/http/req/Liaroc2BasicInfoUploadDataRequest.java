package tw.com.transglobe.adp.integration.liaroc2.http.req;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import tw.com.transglobe.adp.integration.liaroc2.enums.BasicInfoCelectronicType;
import tw.com.transglobe.adp.integration.liaroc2.enums.BasicInfoConvenantType;
import tw.com.transglobe.adp.integration.liaroc2.enums.BasicInfoReqModel;
import tw.com.transglobe.adp.integration.liaroc2.enums.Cmptype;

@Data
public class Liaroc2BasicInfoUploadDataRequest {

  @Schema(description = "操作模式")
  BasicInfoReqModel reqMode;

  @Schema(description = "產壽險別")
  Cmptype cmptype;

  @Schema(description = "公司代號")
  String cmpno;

  @Schema(description = "被保險人身分證字號")
  String idno;

  @Schema(description = "被保險人出生日期")
  String birdate;

  @Schema(description = "保單號碼")
  String insno;

  @Schema(description = "保單分類")
  String insclass;

  @Schema(description = "險種分類")
  String inskind;

  @Schema(description = "險種")
  String insitem;

  @Schema(description = "主附約")
  BasicInfoConvenantType convenantType;

  @Schema(description = "保險公司的產品名稱，會顯示給民眾看的")
  String cprodName;

  @Schema(description = "保險公司自行定義的險種名稱")
  String cinsKindName;

  @Schema(description = "電子保單/紙本保單")
  BasicInfoCelectronicType celectronicType;

}
