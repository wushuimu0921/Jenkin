package tw.com.transglobe.adp.integration.claim.http.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

@Schema(description = "INT-CLM-071 聯盟鏈理賠記錄查詢")
@Data
@Builder
public class EbaoClaimQueryRequest {

  @Schema(description = "查詢條件")
  String queryType;

  @Schema(description = "查詢參數")
  String queryParam;

  @Schema(description = "受理起日")
  LocalDate startDate;

  @Schema(description = "受理迄日")
  LocalDate endDate;

  @Schema(description = "是否含DC資料")
  String isDC;

  @Schema(description = "服務業務員登錄字號")
  String serviceRegisterCode;

  @Schema(description = "送件業務員登錄字號")
  String reporterRegisterCode;

  @Schema(description = "限制保單查詢")
  Integer limitIndicator;

  @Schema(description = "查詢來源")
  String querySource;
}
