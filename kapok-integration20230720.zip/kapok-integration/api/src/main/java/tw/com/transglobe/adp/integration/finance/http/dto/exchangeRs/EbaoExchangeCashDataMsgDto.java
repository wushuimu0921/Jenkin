package tw.com.transglobe.adp.integration.finance.http.dto.exchangeRs;

import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EbaoExchangeCashDataMsgDto {

  Integer dataSeq; // Cash的流水號

  String dataMsgCode; // Cash資料執行結果

  String dataMsg; // Cash資料執行結果說明

  Long ebaoFeeId; // 儲存後的eBao流水號

  String refId; // 團旅險提供的資料

  @Builder.Default
  List<EbaoExchangeEventMsgDto> eventMsgs = new ArrayList<EbaoExchangeEventMsgDto>(); // 檢核或錯誤事件主檔
}
