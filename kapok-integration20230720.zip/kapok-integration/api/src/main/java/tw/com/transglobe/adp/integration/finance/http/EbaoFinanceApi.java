package tw.com.transglobe.adp.integration.finance.http;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.SpringQueryMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import tw.com.transglobe.adp.integration.finance.http.dto.EbaoStandardResponse;
import tw.com.transglobe.adp.integration.finance.http.dto.exchangeRs.EbaoExchangeRsDto;
import tw.com.transglobe.adp.integration.finance.http.dto.transPayment.EbaoFinanceQueryChequeDto;
import tw.com.transglobe.adp.integration.finance.http.dto.transPayment.EbaoFinancePaymentResultDto;
import tw.com.transglobe.adp.integration.finance.http.dto.transPosting.EbaoTransPostingResponseDto;
import tw.com.transglobe.adp.integration.finance.http.req.*;

@Tag(name = "EbaoFinanceApi", description = "EBao Finance Common WebService")
public interface EbaoFinanceApi {

  @Operation(summary = "INT-FIN-001 createReceivable", description = "建立 Receivable")
  @PostMapping("/ebao/finance/receivables")
  EbaoExchangeRsDto createReceivable(@RequestBody EbaoFinanceReceivableRequest requests);

  @Operation(summary = "INT-FIN-002 createPayable", description = "建立 Payable")
  @PostMapping("/ebao/finance/payables")
  EbaoExchangeRsDto createPayable(@RequestBody EbaoFinancePayableRequest request);

  @Operation(summary = "INT-FIN-003 getChequeInfo", description = "查詢支票")
  @GetMapping("/ebao/finance/cheque-info")
  EbaoFinanceQueryChequeDto getChequeInfo(@SpringQueryMap EbaoFinanceQueryCheckRequest request);

  @Operation(summary = "INT-FIN-004 getPaymentResult", description = "查詢收付費回傳結果")
  @GetMapping("/ebao/finance/payment")
  EbaoFinancePaymentResultDto getPaymentResult(@SpringQueryMap EbaoGetPaymentResultRequest request);

  @Operation(summary = "cancel", description = "取消交易")
  @PutMapping("/ebao/finance/cancel")
  void cancel();

  @Operation(summary = "INT-FIN-006 getPostingResult", description = "過帳結果查詢")
  @GetMapping("/ebao/finance/posting")
  EbaoTransPostingResponseDto getPostingResult(@SpringQueryMap EbaoFinanceTransPostingRequest request);

}

@FeignClient(name = "ebao-common-ws", url = "${transglobe.adp.integration.api-client.url}")
interface EbaoCommonWsApiClient extends EbaoFinanceApi {

}
