package tw.com.transglobe.adp.integration.liaroc2.http.req;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Liaroc2ClaimUploadRequest {

}
