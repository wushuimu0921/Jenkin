package tw.com.transglobe.adp.integration.commons.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

@AllArgsConstructor
@Getter
public enum EbaoChequeStatus {

  Cheque_Status_1(1), //清空
  Cheque_Status_2(2), //取消
  Cheque_Status_3(3), //列印
  Cheque_Status_10(10), //入帳中
  Cheque_Status_11(11), //待託收
  Cheque_Status_12(12), //託收
  Cheque_Status_13(13), //兌現
  Cheque_Status_14(14), //抽票申請
  Cheque_Status_15(15), //抽票中
  Cheque_Status_16(16), //退票未決
  Cheque_Status_17(17), //抽票未決
  Cheque_Status_18(18), //抽票結案
  Cheque_Status_19(19), //退票結案
  Cheque_Status_30(30), //已領用
  Cheque_Status_31(31), //開立
  Cheque_Status_32(32), //兌現
  Cheque_Status_33(33), //掛失
  Cheque_Status_34(34), //除權判決
  Cheque_Status_35(35), //作廢
  Cheque_Status_36(36), //逾一年
  Cheque_Status_37(37), //逾二年
  Cheque_Status_38(38); //撤銷掛失做廢

  final Integer value;

  public static EbaoChequeStatus toEbaoChequeStatus(String input) {
    return Arrays.stream(EbaoChequeStatus.values())
        .filter(status -> status.getValue().toString().equals(input))
        .findAny().orElse(null);
  }
}
