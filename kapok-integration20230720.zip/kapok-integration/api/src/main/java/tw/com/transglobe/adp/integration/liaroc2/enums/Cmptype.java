package tw.com.transglobe.adp.integration.liaroc2.enums;

public enum Cmptype {

  R, //收件-壽險
  r, //收件-產險
  L, //承保-壽險
  N; //承保-產險

}
