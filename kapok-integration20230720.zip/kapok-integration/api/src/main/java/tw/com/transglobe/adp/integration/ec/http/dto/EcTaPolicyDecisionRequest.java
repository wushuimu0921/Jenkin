package tw.com.transglobe.adp.integration.ec.http.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Deprecated
@Data
@Builder
@Schema(description = "EC線下核保新契約通知保單核保結論")
public class EcTaPolicyDecisionRequest {

  @NotNull
  @Schema(description = "保單號碼")
  String policyNo;

  @NotNull
  @Schema(description = "核保結論: A(核保通過), 1(逾期未補全), 2(延期), 3(謝絕承保), 4(要保撤回), 5(不同意加費), 6(不同意批註), 7(未繳費), 8(未體檢), 0(其他)")
  String policyDecision;

}
