package tw.com.transglobe.adp.integration.finance.http.req;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;
import tw.com.transglobe.adp.integration.commons.enums.*;

@Data
@Builder
public class EbaoFinanceAparRequest {
  LocalDateTime dataDate; // 轉檔到 ebao 日期
  Integer seqNo; // policy.seqNo, 旅平只有 1 ebao:arapSeq
  Integer systemId; // 團旅險設定 1
  Integer subSystemId; // 2:團險 , 3:旅平險 , 4:團旅險理賠
  Integer businessTypeId; // 1: 個險, 2:團險, 3:旅平險
  String refId; // REF ID, 取得 policy.UUID
  PayMode payMode; // 付款方式
  FeeType feeType; // 費用類型
  BigDecimal feeAmount; // 費用金額, 這張保單的 totalPremium
  FeeStatus feeStatus; // 費用狀態 , default 0
  String policyNo; // 保單號碼, 非必填 ebao:adpPolNo
  String divideIndi; // 區隔標記 ?? 設定 "T"
  MoneyId moneyId; // 保單幣別
  MoneyId payMoneyId; // 交易幣別
  BigDecimal payAmount; // 交易幣金額
  LocalDate checkEnterTime; // 交易日期, 使用者輸入日期
  String applicantIdno; // ebao:phCertiCode
  PhCertiType applicantIdnoType; //ebao:phCertiType
  String applicantLocalName; // ebao:phName
  String applicantNation; //ebao:phNational
  String applicantZipCode; //ebao:phPostCode
  ChannelType agentChannelType;//業務員通路別 ebao:agentChannelTypeCode .order = agentChannelType
  String agentChannelCode; //業務員單位代碼
  String agentNo; //toEbao:AgentRegisterCode
  String agentChannelName;
  ChannelType issueChannelType;//領傭業務員通路別 ebao:issueChannelTypeCode .order = issueChannelType
  String issueChannelCode;
  String issueRegisterCode;
  String issueChannelName;
  LocalDate validateDate;//保項生效日
  LocalDate dueTime; // 應收應付日期, 給予 policy.effTime
  String cashierDeptCode; // 輸入人員單位 code
  String cashierDeptLocalName; // 輸入人員單位名稱
  String cashierLocalName; // 輸入人員姓名
  String cashierJobNo;
  LocalDateTime cashierTime;

  LocalDate accountingDate; // 入帳日, 轉檔日期
  Integer policyYear; //保費年度
  Integer premAllocYear;//保費認證年度
  String mainCode;//險種代碼 ebao:internalId
  String productName;//險種名稱
  ProductCategory productCategory;//商品大類
  ProdContract prodContract;//合約種類 ebao:prodContract .value = prodContractName
  ChargeType chargeType;//繳別
  ChargePeriod chargePeriod;//繳費類型
  Integer chargeYear;//繳費年期(民國)
  CoveragePeriod coveragePeriod;//保障類型
  Integer coverageYear;//保障年期
  Integer familyId;//眷屬碼
  Integer giempId;//個人碼
  Integer policyPeriod;
  WithdrawType withdrawType;//付費原因
  String glPeriod;
  String glPlanCode;
  String isDiscretion;// 具有裁量參與特性(是/否)

  String grTotalIndi; //總額制
  LocalDate grValidateDate; //團險生效日
  String grEmpPolIndi; //員工保險保單註記

  //理賠
  String clmCaseNo;
  Integer clmAuditDecision;
  String liabCategory;
  String liabId;
  Long clmAccidentAge;
  String insuredCertiType;
  String insuredCertiCode;
  String insuredGender;
  Integer insuredEntryAge;
  String payeeNationality;
}
