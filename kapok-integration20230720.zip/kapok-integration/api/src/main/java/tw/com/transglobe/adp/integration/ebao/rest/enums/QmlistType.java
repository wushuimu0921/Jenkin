package tw.com.transglobe.adp.integration.ebao.rest.enums;

public enum QmlistType {

  CLIENT("1"), // 客戶
  AGENT("2"), // 業務員
  DOCTOR("3"), // 醫生
  HOSPITAL("4"); // 醫院
  //  OTHER, // 其他

  private final String ebaoCode;

  private QmlistType(String ebaoCode) {
    this.ebaoCode = ebaoCode;
  }

  public String getEbaoCode() {
    return this.ebaoCode;
  }

  public static QmlistType getByEbaoCode(String ebaoCode) {
    for (QmlistType e : values()) {
      if (e.ebaoCode.equals(ebaoCode)) {
        return e;
      }
    }
    return null;
  }
}
