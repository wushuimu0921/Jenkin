package tw.com.transglobe.adp.integration.commons.enums;

public enum CancelReason {
  CANCEL_REASON_1("1"), //保單持有者更改需求
  CANCEL_REASON_2("2"), //錯誤資料登錄
  CANCEL_REASON_3("3"), //批准人拒絕
  CANCEL_REASON_4("4"), //受損支票
  CANCEL_REASON_5("5"), //改變付款詳細資料
  CANCEL_REASON_6("6"), //無效的支付申請
  CANCEL_REASON_7("7"), //正常狀態
  CANCEL_REASON_8("8"), //支票詳細資料更改
  CANCEL_REASON_9("9"), //受損支票
  CANCEL_REASON_11("11"), //內部-到期終止
  CANCEL_REASON_12("12"), //內部-在列印時損壞
  CANCEL_REASON_13("13"), //內部-傳真錯誤
  CANCEL_REASON_14("14"), //內部插入錯誤的支票開始號
  CANCEL_REASON_15("15"), //內部的-錯置股份支票
  CANCEL_REASON_16("16"), //內部的-錯誤的領款人姓名
  CANCEL_REASON_17("17"), //內部的-錯誤的付款額
  CANCEL_REASON_18("18"), //內部的-錯誤的付款日
  CANCEL_REASON_19("19"), //內部的-停止付款
  CANCEL_REASON_20("20"), //內部的-其他錯誤
  CANCEL_REASON_21("21"), //到期終止
  CANCEL_REASON_22("22"), //損壞或內部錯誤
  CANCEL_REASON_23("23"), //無效付款
  CANCEL_REASON_31("31"), //保單持有者要求-購買新保單
  CANCEL_REASON_32("32"), //保單持有人要求-為另一份保單付款
  CANCEL_REASON_33("33"), //保單持有人要求-保留存款帳戶
  CANCEL_REASON_34("34"), //保單持有人要求-丟失/錯置支票
  CANCEL_REASON_35("35"), //保單持有人要求-變更付款方式
  CANCEL_REASON_36("36"), //保單持有人要求-變更操作規則
  CANCEL_REASON_40("40"), //保單持有人要求-其他
  CANCEL_REASON_44("44"), //Data patch
  CANCEL_REASON_55("55"), //不兌現的支票
  CANCEL_REASON_56("56"), //不正確金額
  CANCEL_REASON_57("57"), //取消申請
  CANCEL_REASON_58("58"), //人為錯誤/客戶要求
  CANCEL_REASON_61("61"), //銀行轉帳-帳戶關閉
  CANCEL_REASON_63("63"), //銀行轉帳-帳戶不存在
  CANCEL_REASON_64("64"), //銀行轉帳-參考支付組織
  CANCEL_REASON_65("65"), //退費抽檔取消
  CANCEL_REASON_66("66"), //銀行轉帳-錯誤的帳戶號
  CANCEL_REASON_70("70"), //銀行轉帳-其他
  CANCEL_REASON_71("71"), //銀行轉帳-帳戶關閉
  CANCEL_REASON_72("72"), //銀行轉帳-錯誤的帳戶號
  CANCEL_REASON_77("77"), //銀行轉帳-帳戶不存在
  CANCEL_REASON_80("80"), //銀行轉帳-其他
  CANCEL_REASON_81("81"), //CPF-帳戶關閉
  CANCEL_REASON_82("82"), //CPF-錯誤帳號
  CANCEL_REASON_83("83"), //CPF-帳戶不存在
  CANCEL_REASON_90("90"), //CPF-其他
  CANCEL_REASON_91("91"), //理賠審批
  CANCEL_REASON_92("92"), //退匯
  CANCEL_REASON_93("93"), //作廢-重印
  CANCEL_REASON_94("94"), //作廢-重新付費
  CANCEL_REASON_95("95"), //作廢-面額重開
  CANCEL_REASON_96("96"), //作廢-取消付費
  CANCEL_REASON_97("97"), //抽退票結案
  CANCEL_REASON_98("98"), //撤銷掛失
  CANCEL_REASON_99("99"), //付款檔案取消
  CANCEL_REASON_A1("A1"), //帳務調整
  CANCEL_REASON_A2("A2"), //支票退票
  CANCEL_REASON_A3("A3"), //新契約會辦
  CANCEL_REASON_A4("A4"), //保全會辦
  CANCEL_REASON_A5("A5"), //理賠會辦
  CANCEL_REASON_A6("A6"),//其他
  ;
  String value;

  CancelReason(String value) {
    this.value = value;
  }

  public String getValue() {
    return this.value;
  }
}
