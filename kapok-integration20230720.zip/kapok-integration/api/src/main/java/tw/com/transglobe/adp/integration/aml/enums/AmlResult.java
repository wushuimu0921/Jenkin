package tw.com.transglobe.adp.integration.aml.enums;

public enum AmlResult {

  NOHIT, // 通過 (NOHIT 或 假命中)
  SANCTION, // 制裁名單
  WARN, // 警示, 命中, 但不是制裁名單
  PENDING, // 尚未確認
}
