package tw.com.transglobe.adp.integration.liaroc2.http.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Liaroc2ClaimUploadResponse {

}
