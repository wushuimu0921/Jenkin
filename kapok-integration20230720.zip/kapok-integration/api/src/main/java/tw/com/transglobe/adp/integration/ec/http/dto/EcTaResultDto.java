package tw.com.transglobe.adp.integration.ec.http.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "執行結果")
public class EcTaResultDto {

  @Schema(description = "執行結果: Y(執行成功), N(執行錯誤)")
  String status;

  @Schema(description = "錯誤代碼")
  String errorCode;

  @Schema(description = "錯誤訊息: 錯誤時才顯示")
  String errorMsg;

}
