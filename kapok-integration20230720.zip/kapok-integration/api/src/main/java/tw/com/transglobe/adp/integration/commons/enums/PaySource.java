package tw.com.transglobe.adp.integration.commons.enums;

public enum PaySource {

  PAY_SOURCE_21(21), // 現金/匯款 - 保戶臨櫃
  PAY_SOURCE_24(24), // 現金 - 業務代表收費

  PAY_SOURCE_28(28), // 劃撥 - 客戶自行劃撥

  PAY_SOURCE_31(31), // 便利商店 - 7-11
  PAY_SOURCE_32(32), // 便利商店 - 全家
  PAY_SOURCE_33(33), // 便利商店 - 萊爾富
  PAY_SOURCE_34(34), // 便利商店 - OK

  PAY_SOURCE_25(25), // 信用卡 - 人工請款
  PAY_SOURCE_26(26), // 信用卡 - 批次請款
  PAY_SOURCE_27(27), // 信用卡 - 線上授權

  PAY_SOURCE_36(36), // 全國繳費網 - 帳戶繳費(網路投保)
  PAY_SOURCE_37(37), // 全國繳費網 - 晶片金融卡(線上繳費)
  PAY_SOURCE_38(38), // 全國繳費網 - 帳戶繳費(線上繳費)
  PAY_SOURCE_40(40), // 全國繳費網 - 帳戶繳費(IVR)

  PAY_SOURCE_11(11), //團旅險理賠

  ;

  final Integer value;

  PaySource(Integer value) {
    this.value = value;
  }

  public Integer getValue() {
    return this.value;
  }
}
