package tw.com.transglobe.adp.integration.claim.http.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Schema(description = "INT-CLM-071 聯盟鏈理賠記錄 列表物件")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EbaoClaimQueryDto {

  @Schema(description = "理賠案件清單")
  List<EbaoClaimStatusDto> claimStatusList;

}
