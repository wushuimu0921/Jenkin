package tw.com.transglobe.adp.integration.ebao.common.http;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import tw.com.transglobe.adp.integration.ebao.common.http.dto.EbaoCommonRequest;
import tw.com.transglobe.adp.integration.ebao.common.http.dto.EbaoCommonResponse;

@Tag(name = "EbaoGenericWsApi", description = "EBao Generic WebService request")
public interface EbaoGenericWsApi {
  @Operation(summary = "Ebao WebService", description = "ebao webservice通用查詢")
  @PostMapping(value = "/ebao/commonWs", produces = "application/json;charset=UTF8")
  EbaoCommonResponse commonWs(@RequestBody EbaoCommonRequest request);
}

@FeignClient(name = "ebao-generic-ws", url = "${transglobe.adp.integration.api-client.url}")
interface EbaoCommonWsApiClient extends EbaoGenericWsApi {

}
