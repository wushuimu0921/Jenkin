package tw.com.transglobe.adp.integration.finance.http.dto.chequeInfo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ChequeHistDto {
  @Schema(description = "變更前支票狀態")
  String oriChequeStatus;

  @Schema(description = "變更前支票狀態中文")
  String oriStatusName;

  @Schema(description = "變更後支票狀態")
  String aftChequeStatus;

  @Schema(description = "變更後支票狀態中文")
  String aftChequeName;

  @Schema(description = "變更日期")
  LocalDate changeDate;

  @Schema(description = "支票歷程流水號")
  Integer seq;

  @Schema(description = "產生歷程人員名")
  String histCreateUserName;
}
