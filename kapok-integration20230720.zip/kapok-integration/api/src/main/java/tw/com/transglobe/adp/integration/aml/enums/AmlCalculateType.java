package tw.com.transglobe.adp.integration.aml.enums;

public enum AmlCalculateType {

  CALC_0("0"), //不計算但進行名單檢測,
  CALC_1("1"), //計算且進行名單檢測,
  CALC_2("2"), //計算但不進行名單檢測,
  CALC_3("3"); //不計算且不進行名單檢測

  private String numCode;

  AmlCalculateType(String numCode) {
    this.numCode = numCode;
  }

  public String getNumCode() {
    return numCode;
  }

}
