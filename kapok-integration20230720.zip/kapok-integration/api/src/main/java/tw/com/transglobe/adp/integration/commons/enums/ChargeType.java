package tw.com.transglobe.adp.integration.commons.enums;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum ChargeType {
  @Schema(description = "無關")
  CHARGE_TYPE_0("0"),
  @Schema(description = "年繳")
  CHARGE_TYPE_1("1"),
  @Schema(description = "半年繳")
  CHARGE_TYPE_2("2"),
  @Schema(description = "季繳")
  CHARGE_TYPE_3("3"),
  @Schema(description = "月繳")
  CHARGE_TYPE_4("4"),
  @Schema(description = "躉繳")
  CHARGE_TYPE_5("5"),
  @Schema(description = "天繳")
  CHARGE_TYPE_7("7"),
  @Schema(description = "當天的")
  CHARGE_TYPE_8("8");
  @Getter
  final private String value;

}
