package tw.com.transglobe.adp.integration.commons.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum WithdrawType {

  WITHDRAW_TYPE_1("1"), //	拒保退費
  WITHDRAW_TYPE_10("10"), //	生日性別變更退費
  WITHDRAW_TYPE_11("11"), //	職業變更退費
  WITHDRAW_TYPE_12("12"), //	補充告知退費
  WITHDRAW_TYPE_13("13"), //	保單借款
  WITHDRAW_TYPE_14("14"), //	批次加減保
  WITHDRAW_TYPE_15("15"), //	投連部分領取
  WITHDRAW_TYPE_16("16"), //	年度末結算退費
  WITHDRAW_TYPE_17("17"), //	分紅產品部分退保
  WITHDRAW_TYPE_18("18"), //	分紅產品全部退保
  WITHDRAW_TYPE_19("19"), //	滿期領取
  WITHDRAW_TYPE_2("2"), //	延期退費
  WITHDRAW_TYPE_20("20"), //	年金
  WITHDRAW_TYPE_21("21"), //	分期生存金領取
  WITHDRAW_TYPE_22("22"), //	體檢費用
  WITHDRAW_TYPE_23("23"), //	分期理賠給付
  WITHDRAW_TYPE_24("24"), //	基金轉換P/L
  WITHDRAW_TYPE_25("25"), //	首期暫收退費
  WITHDRAW_TYPE_26("26"), //	紅利領取
  WITHDRAW_TYPE_27("27"), //	存款領取
  WITHDRAW_TYPE_28("28"), //	檔次變更退費
  WITHDRAW_TYPE_29("29"), //	預付賠款
  WITHDRAW_TYPE_3("3"), //	批次扣款/核印失敗取消承保(批次)
  WITHDRAW_TYPE_30("30"), //	部分退保
  WITHDRAW_TYPE_31("31"), //	保全暫收退費
  WITHDRAW_TYPE_32("32"), //	分期理賠金一次領取
  WITHDRAW_TYPE_33("33"), //	自動退保退費
  WITHDRAW_TYPE_34("34"), //	應收應付沖銷支付
  WITHDRAW_TYPE_35("35"), //	業務員傭金付費
  WITHDRAW_TYPE_36("36"), //	累積紅利領取
  WITHDRAW_TYPE_37("37"), //	雇主
  WITHDRAW_TYPE_38("38"), //	強制
  WITHDRAW_TYPE_39("39"), //	息票
  WITHDRAW_TYPE_4("4"), //	溢繳退費
  WITHDRAW_TYPE_40("40"), //	股息
  WITHDRAW_TYPE_41("41"), //	傭金付款-內部通路
  WITHDRAW_TYPE_42("42"), //	Commission Tax
  WITHDRAW_TYPE_43("43"), //	Payment Tax
  WITHDRAW_TYPE_5("5"), //	強撤退費
  WITHDRAW_TYPE_51("51"), //	懸帳退費
  WITHDRAW_TYPE_52("52"), //	高保額退費
  WITHDRAW_TYPE_53("53"), //	核保作業延期／拒保退費/...等未承保退費
  WITHDRAW_TYPE_54("54"), //	手續費(收費)
  WITHDRAW_TYPE_55("55"), //	手續費(付費)
  WITHDRAW_TYPE_56("56"), //	印花稅
  WITHDRAW_TYPE_57("57"), //	退匯手續費(收回)
  WITHDRAW_TYPE_58("58"), //	核印費
  WITHDRAW_TYPE_59("59"), //	劃撥手續費
  WITHDRAW_TYPE_6("6"), //	猶豫期撤保
  WITHDRAW_TYPE_60("60"), //	轉帳手續費
  WITHDRAW_TYPE_61("61"), //	信用卡手續費
  WITHDRAW_TYPE_62("62"), //	超商手續費
  WITHDRAW_TYPE_63("63"), //	手續費收回
  WITHDRAW_TYPE_64("64"), //	匯款手續費
  WITHDRAW_TYPE_65("65"), //	退匯手續費
  WITHDRAW_TYPE_66("66"), //	債權扣押移轉
  WITHDRAW_TYPE_67("67"), //	傭金付款-外部通路
  WITHDRAW_TYPE_68("68"), //	失效
  WITHDRAW_TYPE_69("69"), //	保單到期給付
  WITHDRAW_TYPE_7("7"), //	失效給付
  WITHDRAW_TYPE_70("70"), //	契變退費
  WITHDRAW_TYPE_71("71"), //	終止
  WITHDRAW_TYPE_72("72"), //	理賠退費(不扣佣金)
  WITHDRAW_TYPE_73("73"), //	DC導入(應付票據)
  WITHDRAW_TYPE_74("74"), //	紅利抵繳逾額
  WITHDRAW_TYPE_75("75"), //	DC導入(應付票據-不入A檔)
  WITHDRAW_TYPE_8("8"), //	終止附約
  WITHDRAW_TYPE_9("9"), //	理賠給付
  WITHDRAW_TYPE_98("98"), //	核保中退費
  WITHDRAW_TYPE_99("99"),//	其它
  ;
  @Getter
  final String value;

}
