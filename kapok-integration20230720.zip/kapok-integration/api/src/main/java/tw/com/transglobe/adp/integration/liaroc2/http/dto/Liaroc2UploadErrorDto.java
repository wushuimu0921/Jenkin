package tw.com.transglobe.adp.integration.liaroc2.http.dto;

import lombok.Data;

@Data
public class Liaroc2UploadErrorDto {

  String code;
  String message;

}
