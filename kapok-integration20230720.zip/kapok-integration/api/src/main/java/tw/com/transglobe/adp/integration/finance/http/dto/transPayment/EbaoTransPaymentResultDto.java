package tw.com.transglobe.adp.integration.finance.http.dto.transPayment;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EbaoTransPaymentResultDto {

  String resultCode; //回傳代碼
  String resultDesc; //銀行失敗訊息
  String resultEbaoDesc; //易保失敗訊息
  String refId;

}
