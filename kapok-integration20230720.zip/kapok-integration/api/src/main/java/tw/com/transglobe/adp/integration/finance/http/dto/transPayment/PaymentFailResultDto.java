package tw.com.transglobe.adp.integration.finance.http.dto.transPayment;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class PaymentFailResultDto {
  List<EbaoTransPaymentResultDto> paymentFailResult;
}
