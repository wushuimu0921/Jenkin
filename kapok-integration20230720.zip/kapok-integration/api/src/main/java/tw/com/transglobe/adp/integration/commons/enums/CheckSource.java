package tw.com.transglobe.adp.integration.commons.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum CheckSource {
  CHECK_SOURCE_0(0), //個險保單
  CHECK_SOURCE_1(1), //團險保單
  CHECK_SOURCE_2(2), //旅平險保單
  CHECK_SOURCE_3(3);//團險理賠
  @Getter
  final Integer value;

}
