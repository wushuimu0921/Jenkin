package tw.com.transglobe.adp.integration.crystalreport.http.query;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.constraints.NotEmpty;
import lombok.Builder;
import lombok.Data;
import tw.com.transglobe.adp.integration.commons.enums.ReportType;

@Schema(description = "CrystalReport 查詢")
@Data
@Builder
public class CrystalReportRequest {

  @NotEmpty
  @Schema(description = "報表類別")
  ReportType reportType;

  @NotEmpty
  @Schema(description = "查詢條件 reportId")
  String reportId;

  @NotEmpty
  @Schema(description = "使用者 AD 帳號")
  String userAccount;

}
