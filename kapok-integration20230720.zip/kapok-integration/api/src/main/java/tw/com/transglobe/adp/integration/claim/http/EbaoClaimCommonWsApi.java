package tw.com.transglobe.adp.integration.claim.http;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.SpringQueryMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import tw.com.transglobe.adp.integration.claim.http.dto.EbaoClaimQueryDto;
import tw.com.transglobe.adp.integration.claim.http.dto.EbaoClaimQueryRequest;
import tw.com.transglobe.adp.integration.commons.enums.ProductGroupType;
import tw.com.transglobe.adp.integration.kmiddle.http.KmiddleCommonWsApi;

@Tag(name = "EbaoClaimCommonWsApi", description = "EbaoClaim Common WebService")
public interface EbaoClaimCommonWsApi {

  @Operation(summary = "理賠查詢", description = "依據查詢條件進行理賠查詢")
  @GetMapping("/ebao/claim/{productGroupType}")
  EbaoClaimQueryDto queryClaim(@PathVariable("productGroupType") ProductGroupType productGroupType,
      @SpringQueryMap EbaoClaimQueryRequest request);

}

@FeignClient(name = "ebao-claim-common-ws", url = "${transglobe.adp.integration.api-client.url}")
interface EbaoClaimCommonWsClient extends EbaoClaimCommonWsApi {

}
