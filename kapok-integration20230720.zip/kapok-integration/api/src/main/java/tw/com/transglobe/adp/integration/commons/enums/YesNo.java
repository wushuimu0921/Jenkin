package tw.com.transglobe.adp.integration.commons.enums;

public enum YesNo {

  Y,
  N

}
