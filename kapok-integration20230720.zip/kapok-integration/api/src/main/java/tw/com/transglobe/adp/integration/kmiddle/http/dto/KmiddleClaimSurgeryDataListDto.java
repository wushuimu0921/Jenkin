package tw.com.transglobe.adp.integration.kmiddle.http.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class KmiddleClaimSurgeryDataListDto {

  List<KmiddleClaimSurgeryDataDto> claimSurgeryData;

}
