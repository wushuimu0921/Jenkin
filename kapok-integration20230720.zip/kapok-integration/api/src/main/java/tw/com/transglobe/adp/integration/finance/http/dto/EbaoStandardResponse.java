package tw.com.transglobe.adp.integration.finance.http.dto;

import lombok.Data;
import tw.com.transglobe.adp.integration.commons.enums.Status;

@Data
public class EbaoStandardResponse {

  Status status;

  String message;
}
