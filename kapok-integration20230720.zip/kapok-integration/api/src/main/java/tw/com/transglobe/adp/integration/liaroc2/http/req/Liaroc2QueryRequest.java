package tw.com.transglobe.adp.integration.liaroc2.http.req;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;
import tw.com.transglobe.adp.integration.liaroc2.enums.LoadingType;
import tw.com.transglobe.adp.integration.liaroc2.enums.Module;
import tw.com.transglobe.adp.integration.liaroc2.enums.SystemCode;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;

@Schema(description = "公會索引查詢")
@Data
@Builder
public class Liaroc2QueryRequest {

  @NotNull
  @Schema(description = "來源模組系統名稱, EBAO, EC, GRP(團險), TRV(旅平險)")
  SystemCode systemCode;

  @NotNull
  @Schema(description = "來源模組單位, EBAO模組：AFINS, FOA, POS, UNB, CLM, 其他系統：EC, GRP, TRV")
  Module moduleCode;

  @NotNull
  @Schema(description = "查詢類型 EbaoAll：收件+承保 InsActRv：收件，InsAct：承保，InsActCl：理賠，InsDead：身故")
  LoadingType loadingType;

  @NotNull
  @Schema(description = "被保險人身分證字號")
  String idno;

  @Schema(description = "被保險人生日")
  LocalDate birthday;

}
