package tw.com.transglobe.adp.integration.liaroc2.enums;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * 保險存摺操作模式
 */
@RequiredArgsConstructor
public enum BasicInfoReqModel {

  @Schema(description = "新增/異動")
  UPDATE("update"),

  @Schema(description = "刪除舊的資料")
  DELETE("delete");

  @Getter
  final String cmdValue;
}
