package tw.com.transglobe.adp.integration.liaroc2.enums;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * 保險存摺 電子保單/紙本保單
 */
@RequiredArgsConstructor
public enum BasicInfoCelectronicType {

  @Schema(description = "紙本保單")
  PAPER("1"),

  @Schema(description = "電子保單")
  ELECTRONIC("2"),

  @Schema(description = "紙本QR Code保單")
  PAPER_WITH_QR_CODE("3"),

  @Schema(description = "電子QR Code保單")
  ELECTRONIC_WITH_QR_CODE("4");

  @Getter
  final String cmdValue;

}
