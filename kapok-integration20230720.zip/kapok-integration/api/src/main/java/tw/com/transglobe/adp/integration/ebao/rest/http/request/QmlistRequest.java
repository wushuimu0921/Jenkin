package tw.com.transglobe.adp.integration.ebao.rest.http.request;

import java.time.LocalDate;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import tw.com.transglobe.adp.integration.ebao.rest.enums.QmlistType;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class QmlistRequest {

  @Schema(name = "type", description = "查詢類別 CLIENT, AGENT, DOCTOR, HOSPITAL, OTHER ")
  QmlistType type;

  @Schema(name = "idno", description = "身分證字號 CLIENT, AGENT, HOSPITAL idno")
  String idno;

  @Schema(name = "agentNo", description = "只有業務員(type=AGENT)才需要輸入")
  String agentNo;

  @Schema(description = "資料來源, UNB, POS 等")
  String source;

  @Schema(name = "checkDate", description = "驗證日期")
  LocalDate checkDate;

}
