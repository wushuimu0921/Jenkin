package tw.com.transglobe.adp.integration.esp.http;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import tw.com.transglobe.adp.integration.esp.http.req.EspSmsMessageRequest;

@Tag(name = "EspSmsApi", description = "ESP mail API")
public interface EspSmsApi {

  @Operation(summary = "sendSmsMessage", description = "寄發簡訊")
  @PostMapping(value = "/esp/sms")
  String sendSmsMessage(@RequestBody EspSmsMessageRequest request);

}

@FeignClient(name = "crystal-esp-sms-api", url = "${transglobe.adp.integration.api-client.url}")
interface EspSmsApiClient extends EspSmsApi {

}
