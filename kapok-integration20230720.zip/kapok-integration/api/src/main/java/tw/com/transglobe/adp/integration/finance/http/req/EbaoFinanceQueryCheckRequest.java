package tw.com.transglobe.adp.integration.finance.http.req;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
@Schema(description = "支票查詢")
public class EbaoFinanceQueryCheckRequest {

  @Schema(description = "支票id")
  List<Long> chequeIds;

}
