package tw.com.transglobe.adp.integration.finance.http.req;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Schema(description = "eBao取消交易請求")
public class EbaoCancelRequest {

  @Schema(description = "交易類型")
  String transType;

  @Schema(description = "eBao流水號")
  Long feeId;

  @Schema(description = "團旅險判別key")
  String refId;

}
