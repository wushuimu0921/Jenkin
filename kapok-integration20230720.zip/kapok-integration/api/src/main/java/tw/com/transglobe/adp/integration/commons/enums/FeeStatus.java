package tw.com.transglobe.adp.integration.commons.enums;

import io.swagger.v3.oas.annotations.media.Schema;

public enum FeeStatus {

  @Schema(description = "待確認")
  FEE_STATUS_NEG_3(-3),
  @Schema(description = "簽核中")
  FEE_STATUS_NEG_2(-2),
  @Schema(description = "已簽核待付款")
  FEE_STATUS_NEG_1(-1),
  @Schema(description = "付款確認")
  FEE_STATUS_0(0),
  @Schema(description = "付款成功")
  FEE_STATUS_1(1),
  @Schema(description = "取消付款")
  FEE_STATUS_2(2),
  @Schema(description = "付款失敗")
  FEE_STATUS_3(3),
  @Schema(description = "付款中")
  FEE_STATUS_4(4),
  @Schema(description = "付款失敗未決")
  FEE_STATUS_5(5),
  @Schema(description = "支票已列印")
  FEE_STATUS_6(6),
  @Schema(description = "帳號待覆核")
  FEE_STATUS_7(7),
  @Schema(description = "帳號覆核退回")
  FEE_STATUS_8(8),
  @Schema(description = "再保障單已出")
  FEE_STATUS_9(9),
  @Schema(description = "轉帳暫停")
  FEE_STATUS_10(10),
  @Schema(description = "記帳後取消")
  FEE_STATUS_11(11);

  final Integer value;

  private FeeStatus(Integer value) {
    this.value = value;
  }

  public Integer getValue() {
    return this.value;
  }

}
