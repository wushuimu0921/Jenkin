package tw.com.transglobe.adp.integration.finance.http.dto.transPayment;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import io.swagger.v3.oas.annotations.media.Schema;

@Data
@Builder
@Schema(description = "付款結果查詢結果明細資料")
public class EbaoTransPaymentFailResultDto {

  @Schema(description = "付款註記: S:付款成功, F:付款失敗, P:付款中, NULL:尚未付款")
  String paymentIndi; // 

  @Schema(description = "付款狀態代碼: *匯款、信用卡 : 1 : 產生報盤, 2 : 付款中, 3 : 付款中 (已上傳), 4 : 已回銷 (檔案), 5 : 已取消, 6 : 暫停付款, 7 : 已回銷 (人工), *支票 : NULL")
  String paymentStatus;

  @Schema(description = "付款狀態代碼中文, 支票件為 NULL")
  String paymentStatusDesc; // 支票 : NULL

  @Schema(description = "付款日期")
  LocalDate paymentDate;

  @Schema(description = "資料輸入日期")
  LocalDate dataDate;

  @Schema(description = "出納的付款批次編號")
  String batchNo;

  @Schema(description = "付款回銷代碼")
  String resultCode; // 支票 : NULL

  @Schema(description = "付款回銷說明")
  String resultDesc; // 支票 : NULL

  @Schema(description = "付款回饋說明, ebao 內建說明")
  String resultEbaoDesc;

  @Schema(description = "ADP.record.uuid")
  String refId;

  @Schema(description = "ebao 的流水號")
  Long feeId;

  @Schema(description = "執行付款人姓名")
  String paymentUserName;

  @Schema(description = "執行付款人部門")
  String paymentUserDeptName;

  @Schema(description = "支票號碼")
  String chequeNo;

  @Schema(description = "支票ID (ebao)")
  Long chequeId;

  @Schema(description = "支票狀態 :11 : 待託收, 12 : 託收, 13 : 兌現, 14 : 抽票申請, 15 : 抽票中, \r\n"
      + "16 : 退票未決, 17 : 抽票未決, 18 : 抽票結案, 19 : 退票結案, \r\n"
      + "30 : 已領用, 31 : 開立, 32 : 兌現, 33 : 掛失, 34 : 除權判決, \r\n"
      + "35 : 作廢, 36 : 逾一年, 37 : 逾二年, 38 : 撤銷掛失作廢")
  String chequeStatus;

  @Schema(description = "交易資料狀態:-1 : 已簽核待付款\r\n"
      + "1 : 付款成功\r\n"
      + "2 : 取消付款\r\n"
      + "3 : 付款失敗\r\n"
      + "4 : 付款中\r\n"
      + "5 : 付款失敗未決\r\n"
      + "6 : 支票已列印\r\n"
      + "11 : 記帳後取消\r\n"
      + "0 : 付款確認")
  String transStatus;

  @Schema(description = "交易資料狀態名稱")
  String transStatusName;

  @Schema(description = "執行退匯原因代碼")
  String rtnRemitReason;

  @Schema(description = "執行退匯原因名稱")
  String rtnRemitReasonName;

  // 7 碼
  @Schema(description = "付款銀行分行代碼 (7 碼)")
  String paymentBranchBankCode;

  // 3 碼
  @Schema(description = "付款銀行代碼 (3 碼)")
  String paymentBankCode;

  @Schema(description = "付款銀行帳戶")
  String paymentBankAccount;

  @Schema(description = "付款銀行名稱")
  String paymentBankName;

  @Schema(description = "付款銀行縮寫")
  String paymentAbbrName;
}
