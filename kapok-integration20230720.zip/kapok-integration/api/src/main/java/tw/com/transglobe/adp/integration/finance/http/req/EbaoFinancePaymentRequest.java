package tw.com.transglobe.adp.integration.finance.http.req;

import lombok.Builder;
import lombok.Data;
import tw.com.transglobe.adp.integration.commons.enums.ChannelType;
import tw.com.transglobe.adp.integration.commons.enums.FeeType;
import tw.com.transglobe.adp.integration.commons.enums.MoneyId;
import tw.com.transglobe.adp.integration.commons.enums.PayMode;
import tw.com.transglobe.adp.integration.commons.enums.PhCertiType;
import tw.com.transglobe.adp.integration.commons.enums.ProductCategory;
import tw.com.transglobe.adp.integration.commons.enums.YesNo;
import tw.com.transglobe.adp.integration.commons.enums.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Builder
public class EbaoFinancePaymentRequest {

  LocalDateTime dataDate; //資料日期

  Integer seqNo; //流水號 toEbao:cashSeq
  Integer systemId; //系統代碼
  Integer subSystemId; //子系統代碼
  Integer businessTypeId; //業務設定檔

  String refId; // REF ID, 取得 Record.UUID
  String policyNo; // 保單號碼, 非必填 toEbao:adpPolNo
  String divideIndi; // 區隔標記 ??

  String applicantIdno;//要保人ID toEbao:phCertiCode
  PhCertiType applicantIdnoType;//要保人證件別:ebao:phCertiType
  String applicantLocalName; //要保人姓名 toEbao:phName

  FeeType feeType; // 費用類型
  PayMode payMode; // 付款方式
  MoneyId moneyId; // 保單幣別
  BigDecimal feeAmount; // 費用金額
  MoneyId payMoneyId; // 交易幣別
  BigDecimal payAmount; // 交易幣金額

  //  PaySource paySource; // 付款來源

  //  FeeStatus feeStatus; // 費用狀態 , default 0

  //  BigDecimal payMergeAmount;

  String cashierDeptCode;
  String cashierDeptLocalName;//toEbao:cashierDeptName
  String cashierLocalName; //toEbao:cashierName
  String cashierJobNo;
  LocalDateTime cashierTime;

  ChannelType agentChannelType; //通路別
  String agentChannelCode; //經手單位代號
  String agentNo; //服務業務員登錄證字號 toEbao:AgentRegisterCode

  LocalDate dueDate;//ebao:dueTime
  LocalDateTime approveDate;//簽核日期
  String approverId;//ebao:approveUserId
  String approverLocalName;//ebao:approveUserName
  String approverDeptCode;//ebao:approveUserDeptCode
  String approverDeptName;//ebao:approveUserDeptName
  String approverJobNo; //ebao:approveUserJobNo
  PaymentSource paymentSource;
  WithdrawType withdrawType;
  LocalDate checkEnterTime; // 交易日期
  LocalDate finishTime; // 公司入帳日

  //匯款
  String payeeIdno;//ebao:payeeCertiCode
  String payeeLocalName;//ebao:payeeName
  String payeeBankCode;
  String payeeBankName;
  String payeeAccount;

  //信用卡資料
  String creditCardNo; //toEbao:creditCardNum
  String creditCardApproveCode; //toEbao:creditCardAuth
  String creditCardExpDate;//toEbao:creditCardExpireDate
  LocalDate creditCardTransDate;
  Long creditCardAcquirerId;//信用卡收單行

  // 支票
  YesNo cancelEndorsement;//ebao:cancelEndorsementIndo
  YesNo cancelScore; //ebao:cancelScoreIndi
  String sendZipCode;
  String sendAddress;
  String companyName;
  String recipientName;
  String attachmentIndi;
  String posAcceptNo;
  String checkSendType;//ebao:chequeSendType
  String refNo;
  String formNo;
  String docNo;

  //  LocalDate paymentDate;

  //  String voucherNo;
  //  LocalDate voucherDate;
  //  BigDecimal voucherAmount;

  String clmCaseNo;
  LocalDate accountingDate;
  ProductCategory productCategory;//商品大類
  String agentChannelName; //業務單位名
  String agentChannelTypeCode;
  Long relatedId;

}
