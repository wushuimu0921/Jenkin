package tw.com.transglobe.adp.integration.finance.http.dto.transPayment;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import tw.com.transglobe.adp.integration.finance.http.dto.chequeInfo.ChequeDto;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EbaoFinanceQueryChequeDto {

  List<ChequeDto> cheques;
}
