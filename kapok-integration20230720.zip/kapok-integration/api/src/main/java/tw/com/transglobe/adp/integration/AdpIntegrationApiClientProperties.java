package tw.com.transglobe.adp.integration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Data
@ConfigurationProperties(prefix = "transglobe.adp.integration.api-client")
class AdpIntegrationApiClientProperties {

  /**
   * 啟用 API FeignClient
   */
  boolean enabled;
  /**
   * 設定 FeignClient url
   */
  String url;
}
