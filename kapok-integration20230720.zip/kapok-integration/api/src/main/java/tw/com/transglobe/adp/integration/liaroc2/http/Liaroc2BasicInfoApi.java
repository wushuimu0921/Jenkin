package tw.com.transglobe.adp.integration.liaroc2.http;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import tw.com.transglobe.adp.integration.liaroc2.http.dto.Liaroc2BasicInfoUploadResponseDto;
import tw.com.transglobe.adp.integration.liaroc2.http.req.Liaroc2BasicInfoUploadRequest;

@Tag(name = "Liaroc2BasicInfoApi", description = "Liaroc2 保險存摺 資料交換 API")
public interface Liaroc2BasicInfoApi {

  @Operation(summary = "保險存摺 資料交換 API", description = "資料交換資料")
  @PostMapping("/liaroc2/basic-info/update")
  Liaroc2BasicInfoUploadResponseDto update(@RequestBody Liaroc2BasicInfoUploadRequest request);

}

@FeignClient(name = "liaroc2-basic-info", url = "${transglobe.adp.integration.api-client.url}")
interface Liaroc2BasicInfoClient extends Liaroc2BasicInfoApi {

}
