package tw.com.transglobe.adp.integration.liaroc2.enums;

public enum ProcessMode {

  ProcessMode_0(0), //REST傳送
  ProcessMode_1(1); //SFTP傳送

  Integer value;

  private ProcessMode(Integer value) {
    this.value = value;
  }

  public Integer getValue() {
    return this.value;
  }

}
