package tw.com.transglobe.adp.integration.liaroc2.http;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import tw.com.transglobe.adp.integration.liaroc2.http.dto.LiaInfoResponseDto;
import tw.com.transglobe.adp.integration.liaroc2.http.dto.LiaUploadResponseDto;
import tw.com.transglobe.adp.integration.liaroc2.http.dto.Liaroc2ClaimUploadResponse;
import tw.com.transglobe.adp.integration.liaroc2.http.req.Liaroc2ClaimUploadRequest;
import tw.com.transglobe.adp.integration.liaroc2.http.req.Liaroc2PolicyUploadRequest;
import tw.com.transglobe.adp.integration.liaroc2.http.req.Liaroc2QueryRequest;

import java.util.List;

@Tag(name = "Liaroc2Api", description = "Liaroc2 公會資料交換 API")
public interface Liaroc2Api {

  @Operation(summary = "公會索引 API", description = "查詢公會相關資料")
  @PostMapping("/liaroc2/download")
  LiaInfoResponseDto download(@RequestBody Liaroc2QueryRequest request);

  @Operation(summary = "公會收件承保通報 API", description = "通報公會相關收件承保資料")
  @PostMapping("/liaroc2/upload/policy")
  LiaUploadResponseDto policyUpload(@RequestBody List<Liaroc2PolicyUploadRequest> request);

  @Operation(summary = "公會理賠通報 API", description = "通報公會相關理賠資料")
  @PostMapping("/liaroc2/upload/claim")
  Liaroc2ClaimUploadResponse claimUpload(@RequestBody Liaroc2ClaimUploadRequest request);

}

@FeignClient(name = "liaroc2-application", url = "${transglobe.adp.integration.api-client.url}")
interface Liaroc2ApplicationClient extends Liaroc2Api {

}
