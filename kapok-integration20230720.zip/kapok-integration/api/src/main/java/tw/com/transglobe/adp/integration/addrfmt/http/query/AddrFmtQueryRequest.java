package tw.com.transglobe.adp.integration.addrfmt.http.query;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;

@Schema(description = "地址正規化 查詢")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AddrFmtQueryRequest {

  @NotEmpty
  @Schema(description = "輸入的地址")
  String address;

}
