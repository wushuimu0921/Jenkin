package tw.com.transglobe.adp.integration.esp.http.req;

import java.util.List;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class UploadFileDto {

  String fileName;

  String extName;

  String pvcFileKey;

  List<String> pvcPaths;

}
