package tw.com.transglobe.adp.integration.aml.http.dto;

import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;
import tw.com.transglobe.adp.integration.aml.enums.AmlResult;

@Data
@Builder
public class AmlRelResponse {

  String idno;
  AmlResult result;

  int hitCount;
  String decType;
  String decState;
  LocalDateTime decDate;
  String decBy;
  String decComments;
}
