package tw.com.transglobe.adp.integration.finance.http.dto.exchangeRs;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EbaoExchangeRsDto {

  @Builder.Default
  EbaoExchangeRsObjDto responseObj = EbaoExchangeRsObjDto.builder().build();

  String responseCode; // XML執行結果

  String responseDesc; // XML執行結果說明

}
