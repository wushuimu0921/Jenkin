package tw.com.transglobe.adp.integration.finance.http.dto.transPosting;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EbaoTransPostingResponseDto {

  @Schema(description = "查詢提供的日期")
  LocalDate postingDate;

  @Schema(description = "查詢提供的RefId")
  String refId;

  @Schema(description = "查詢的結果")
  String responseCode;

  @Schema(description = "查詢結果說明")
  String responseDesc;

  @Schema(description = "現金付款過帳結果")
  EbaoTransPostingCashPayPostingDto cashPayPosting;

  @Schema(description = "現金收款過帳結果")
  EbaoTransPostingCashColPostingDto cashColPosting;

  @Schema(description = "應收應付過帳結果")
  EbaoTransPostingArapPostingDto arapPosting;

  @Schema(description = "佣金過帳結果")
  EbaoTransPostingCommisionPostingDto commisionPosting;
}