package tw.com.transglobe.adp.integration.claim.http.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Schema(description = "INT-CLM-071 聯盟鏈理賠記錄 診斷物件")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EbaoClaimDiagnosisDto {

  @Schema(description = "診斷代碼")
  String diagnosisCode;

  @Schema(description = "診斷名")
  String diagnosisName;

}
