package tw.com.transglobe.adp.integration.liaroc2.enums;

public enum Insurant {

  Insurant_0(0), //依被保人查詢(預設)
  Insurant_1(1); //依要保人查詢

  Integer value;

  private Insurant(Integer value) {
    this.value = value;
  }

  public Integer getValue() {
    return this.value;
  }

}
