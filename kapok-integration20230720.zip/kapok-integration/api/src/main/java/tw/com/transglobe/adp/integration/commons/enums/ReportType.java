package tw.com.transglobe.adp.integration.commons.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum ReportType {

  APPLICATION_A("GT_QOT_0001", "ReportId"), // 要保書 A 版

  APPLICATION_COMMON("GT_QOT_0002", "ReportId"), // 要保書一般版

  PROPOSAL_COVER_COMMON("GT_QOT_0003_A", "ReportId"), // 計劃書封面一般紙 :

  PROPOSAL_COVER_SPECIAL("GT_QOT_0003_B", "ReportId"), // 計劃書封面特殊紙 :

  PROPOSAL_INSURANCE_FEE("GT_QOT_0003_C", "ReportId"), // 計劃書保險費用表 :

  PROPOSAL_REFUND_FORM("GT_QOT_0003_D", "ReportId"), // 計劃書經驗退費表 :

  PROPOSAL_INSURANCE_PLAN("GT_QOT_0003_E", "ReportId"), // 計劃書計劃內容 :

  AGREEMENT_A("GT_QOT_0004_A", ""), // 1.生效日-勞保生效日約定書30日

  AGREEMENT_B("GT_QOT_0004_B", ""), // 2.生效日~到職離職生效日約定書-45日

  AGREEMENT_C("GT_QOT_0004_C", ""), // 3.生效日~每月一日

  AGREEMENT_D("GT_QOT_0004_D", ""), // 4.生效日~員工到職30日,眷屬受理日翌日

  AGREEMENT_E("GT_QOT_0004_E", ""), // 5.生效日~員工勞保30日,眷屬生效契約相當日,停效當期保費期滿日零時

  AGREEMENT_F("GT_QOT_0004_F", ""), // 6.生效日~員工到職30日,眷屬通知日次月1日

  AGREEMENT_G("GT_QOT_0004_G", ""), // 7.自費案生效日

  AGREEMENT_H("GT_QOT_0004_H", ""), // 8.自費案生效日

  ;

  @Getter
  final String reportName;

  @Getter
  final String reportParam;

}
