package tw.com.transglobe.adp.integration.claim.http.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Schema(description = "INT-CLM-071 聯盟鏈理賠記錄 就醫經過")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EbaoClaimMedicalBillDto {

  @Schema(description = "診療院所")
  String hospitalName;

  @Schema(description = "就醫期間起日")
  String billStartDate;

  @Schema(description = "就醫期間迄日")
  String billEndDate;

  @Schema(description = "就醫的醫療單據類型")
  String receiptTypeCode;

  @Schema(description = "限制保單查詢")
  Integer limitIndicator;

  @Schema(description = "已結案件之理賠決定")
  String auditDecision;

  @Schema(description = "已結案件之理賠決定描述")
  String auditDecisionDesc;
}
