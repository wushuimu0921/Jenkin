package tw.com.transglobe.adp.integration.finance.http.dto.transPayment;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EbaoTransPaymentFailDto {
  Integer failCount;
  PaymentFailResultDto paymentFailResults;
}
