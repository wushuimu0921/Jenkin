package tw.com.transglobe.adp.integration.liaroc2.http.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;

@Data
public class LiaUploadResponseDto {

  Liaroc2UploadSuccessDto success;

  Liaroc2UploadErrorDto error;

  @Schema(description = "上傳公會總筆數")
  Integer totalSize;

  @Schema(description = "上傳公會成功筆數")
  Integer successSize;

  @Schema(description = "上傳公會失敗筆數")
  Integer failSize;

  @Schema(description = "公會回傳的失敗件清單")
  List<Liaroc2UploadFailDto> failResDatas = new ArrayList<>();
}
