package tw.com.transglobe.adp.integration.liaroc2.http.req;

import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import javax.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Data;
import tw.com.transglobe.adp.integration.liaroc2.enums.LoadingType;
import tw.com.transglobe.adp.integration.liaroc2.enums.Module;
import tw.com.transglobe.adp.integration.liaroc2.enums.SourceType;
import tw.com.transglobe.adp.integration.liaroc2.enums.SystemCode;

@Data
public class Liaroc2BasicInfoUploadRequest {

  @NotNull(message = "來源模組名稱不得為空")
  @Schema(description = "來源模組名稱")
  SystemCode systemId;

  @NotNull(message = "來源模組單位不得為空")
  @Schema(description = "來源模組單位")
  Module module;

  @Schema(description = "上傳資料清單")
  List<Liaroc2BasicInfoUploadDataRequest> requestDatas = new ArrayList<>();

}
