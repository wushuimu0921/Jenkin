package tw.com.transglobe.adp.integration.ebao.common.http.dto;

import lombok.Data;
import tw.com.transglobe.adp.integration.commons.enums.Status;

@Data
public class EbaoCommonResponse {
  Status status;
  String message;
  String rsBody;
}
