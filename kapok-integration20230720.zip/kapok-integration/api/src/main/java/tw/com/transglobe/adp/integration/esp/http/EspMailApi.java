package tw.com.transglobe.adp.integration.esp.http;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import tw.com.transglobe.adp.integration.esp.http.req.EspMailAttachFileRequest;
import tw.com.transglobe.adp.integration.esp.http.req.EspMailRequest;

@Tag(name = "EspMailApi", description = "ESP mail API")
public interface EspMailApi {

  @Operation(summary = "sendMailWithAttachFile", description = "夾檔寄發 Mail ")
  @PostMapping(value = "/esp/mail/attachfile")
  String sendMailWithAttachFile(@RequestBody EspMailAttachFileRequest request);

  @Operation(summary = "sendMail", description = "寄發 Mail ")
  @PostMapping(value = "/esp/mail")
  String sendMail(@RequestBody EspMailRequest request);

}

@FeignClient(name = "crystal-esp-mail-api", url = "${transglobe.adp.integration.api-client.url}")
interface EspMailApiClient extends EspMailApi {

}
