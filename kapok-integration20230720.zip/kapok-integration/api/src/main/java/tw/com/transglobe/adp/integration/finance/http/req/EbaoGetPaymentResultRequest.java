package tw.com.transglobe.adp.integration.finance.http.req;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;
import tw.com.transglobe.adp.integration.commons.enums.TransType;

import java.time.LocalDate;

@Schema(description = "查詢收付費回傳結果")
@Data
@Builder
public class EbaoGetPaymentResultRequest {

  @Schema(description = "收付費類型")
  TransType transType;

  @Schema(description = "交易日期")
  LocalDate paymentDate;

  @Schema(description = "保單號碼")
  String policyNo;

}
