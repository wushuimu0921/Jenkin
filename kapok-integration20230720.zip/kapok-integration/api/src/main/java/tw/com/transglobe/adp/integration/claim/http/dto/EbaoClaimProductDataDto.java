package tw.com.transglobe.adp.integration.claim.http.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Schema(description = "INT-CLM-071 聯盟鏈理賠記錄 險種內容物件")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EbaoClaimProductDataDto {

  @Schema(description = "險種代號")
  String internalId;

  @Schema(description = "險種名稱")
  String productName;

  @Schema(description = "理賠金額")
  BigDecimal payAmount;
}
