package tw.com.transglobe.adp.integration.finance.http.req;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;
import tw.com.transglobe.adp.integration.commons.enums.ChannelType;
import tw.com.transglobe.adp.integration.commons.enums.CheckSource;
import tw.com.transglobe.adp.integration.commons.enums.FeeType;
import tw.com.transglobe.adp.integration.commons.enums.MoneyId;
import tw.com.transglobe.adp.integration.commons.enums.PayMode;
import tw.com.transglobe.adp.integration.commons.enums.PaySource;
import tw.com.transglobe.adp.integration.commons.enums.PhCertiType;
import tw.com.transglobe.adp.integration.commons.enums.ProductCategory;

@Data
@Builder
public class EbaoFinanceCollectionRequest {

  LocalDateTime dataDate; //資料日期

  Integer seqNo; //流水號 toEbao:cashSeq
  Integer systemId; //系統代碼
  Integer subSystemId; //子系統代碼
  Integer businessTypeId; //業務設定檔

  String refId; // REF ID, 取得 Record.UUID
  String policyNo; // 保單號碼 toEbao:adpPolNO
  String divideIndi; // 區隔標記 ??

  String applicantIdno;//要保人ID toEbao:phCertiCode
  String applicantLocalName; //要保人姓名 toEbao:phName

  FeeType feeType; // 費用類型
  PayMode payMode; // 付款方式
  PaySource paySource; // 付款來源
  //FeeStatus feeStatus; // 費用狀態 , default 0
  MoneyId moneyId; // 保單幣別
  BigDecimal feeAmount; // 費用金額
  MoneyId payMoneyId; // 交易幣別
  BigDecimal payAmount; // 交易幣金額
  LocalDate checkEnterTime; // 交易日期
  LocalDate finishTime; // 公司入帳日

  String cashierDeptCode;
  String cashierDeptLocalName;//toEbao:cashierDeptName
  String cashierLocalName; //toEbao:cashierName
  String cashierJobNo; //
  LocalDateTime cashierTime;

  ChannelType agentChannelType; //業務員通路別
  String agentChannelCode; //經手單位代號
  String agentNo; //服務業務員登錄證字號 toEbao:AgentRegisterCode

  String voucherNo;
  LocalDate voucherDate;
  BigDecimal voucherAmount;

  String evidenceVoucherSeqNo; //劃撥憑證序號 toEbao:postTransNo

  //信用卡資料
  String creditCardNo; //toEbao:creditCardNum
  String creditCardApproveCode;// toEbao:creditCardAuth
  String creditCardExpDate;//toEbao:creditCardExpireDate
  Integer creditCardAcquirerId; // 信用卡收單行 ( 83:聯信, 80:台新)

  String checkNo; //支票號碼 toEbao:chequeNo
  CheckSource checkSource;//支票來源 toEbao:chequeSource
  BigDecimal checkAmount; //支票金額 toEbao:chequeAmount
  String checkBankCode; //支票付款行代碼 toEbao:chequeBank
  String checkAccount; // 支票帳號
  LocalDate checkDueDate; //支票到期日 toEbao:chequeDueDate
  String checkHolderIdno; //支票付款人證號 toEbao:chequePhCertiCode
  PhCertiType checkHolderIdnoType;//支票付款人證號類型 toEbao:ChequePhCertiType
  String checkHolderLocalName; //支票付款人姓名 toEbao:chequePhName

  LocalDate accountingDate;

  ProductCategory productCategory;//商品大類

  String agentChannelName; //業務單位名
  String agentChannelTypeCode;

  Integer overPaymentType;
  BigDecimal overPaymentAmount;
  Long relatedId;

  Long internalAccount;

  LocalDate validateDate;

}
