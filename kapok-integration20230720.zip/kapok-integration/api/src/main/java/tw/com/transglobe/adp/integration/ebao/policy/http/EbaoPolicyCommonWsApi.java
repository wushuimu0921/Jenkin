package tw.com.transglobe.adp.integration.ebao.policy.http;

import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import tw.com.transglobe.adp.integration.commons.enums.ProductGroupType;
import tw.com.transglobe.adp.integration.ebao.policy.http.dto.EbaoPolicyDto;

@Tag(name = "EbaoPolicyCommonWsApi", description = "EbaoPolicy Common WebService")
public interface EbaoPolicyCommonWsApi {

  @Operation(summary = "ebao-團險有效契約客戶查詢", description = "根據被保險人ID查詢 ebao 是否存在有效契約")
  @GetMapping("/ebao/policy/idno/{productGroupType}/{idno}")
  List<EbaoPolicyDto> queryPolicyByIdno(@PathVariable("productGroupType") ProductGroupType productGroupType,
      @PathVariable("idno") String idno);

}

@FeignClient(name = "ebao-policy-common-ws", url = "${transglobe.adp.integration.api-client.url}")
interface EbaoPolicyCommonWsApiClient extends EbaoPolicyCommonWsApi {

}
