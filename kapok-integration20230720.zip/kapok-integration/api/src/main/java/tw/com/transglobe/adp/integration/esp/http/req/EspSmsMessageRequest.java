package tw.com.transglobe.adp.integration.esp.http.req;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import tw.com.transglobe.adp.integration.commons.enums.ProductGroupType;

import javax.validation.constraints.NotNull;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EspSmsMessageRequest {

  @Schema(description = "險別")
  @NotNull
  ProductGroupType productGroupType;

  @Schema(description = "來源系統 功能類型 id") //ESP 紀錄用，方便查詢問題，Ex: member
  @NotNull
  String contactSysOperatorId;

  @Schema(description = "來源系統 功能類型中文敘述") //ESP 紀錄用，方便查詢問題，Ex: 會員專區
  String contactSysOperatorName;

  @Schema(description = "訊息類型 id") //ESP 紀錄用，方便查詢問題，Ex: LOGON
  @NotNull
  String functionCategory;

  @Schema(description = "訊息類型 id") //ESP 紀錄用，方便查詢問題，Ex: 全球人壽保戶專區會員登入通知
  @NotNull
  String functionName;

  @Schema(description = "保單號碼")
  @NotNull
  String policyNo;

  @Schema(description = "要保人證號")
  @NotNull
  String proposerId;

  @Schema(description = "被保人證號")
  String insuredId;

  @Schema(description = "受益人證號")
  String beneficiaryId;

  @Schema(description = "簡訊檔 id")
  @NotNull
  Long referenceId;

  @Schema(description = "簡訊收件人手機")
  @NotNull
  String destPhoneNo;

  @Schema(description = "事件ID")
  @NotNull
  String eventId;

  @Schema(description = "簡訊內容")
  @NotNull
  String msgData;

  @Schema(description = "簡訊費用歸屬的模組代碼") //RED、CLM、UNB、GROUP，不輸入預設UNB
  String chargeCode;

}
