package tw.com.transglobe.adp.integration.commons.enums;

public enum ProductGroupType {
  GL,
  GI,
  GA,
  TA,
  ADP,
  CSIS,
}
