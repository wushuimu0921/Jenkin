package tw.com.transglobe.adp.integration.aml.http.dto;

import java.time.LocalDateTime;
import java.util.List;
import lombok.Builder;
import lombok.Data;
import tw.com.transglobe.adp.integration.aml.enums.AmlResult;

@Data
@Builder
public class AmlCifResponse {

  String idno;
  AmlResult result;

  int hitCount;
  String decType;
  String decState;
  LocalDateTime decDate;
  String decBy;
  String decComments;

  // calculate
  LocalDateTime calculateDate;
  Integer calculateScore;
  String calculateLevel;
  Integer calculateReview;

  List<AmlRelResponse> rels;

}
