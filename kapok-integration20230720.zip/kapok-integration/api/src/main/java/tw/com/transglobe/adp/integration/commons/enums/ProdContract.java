package tw.com.transglobe.adp.integration.commons.enums;

public enum ProdContract { //商品合約種類
  L("保險合約"),
  I("投資合約");

  final String value;

  ProdContract(String value) {
    this.value = value;
  }

  public String getValue() {
    return this.value;
  }
}
