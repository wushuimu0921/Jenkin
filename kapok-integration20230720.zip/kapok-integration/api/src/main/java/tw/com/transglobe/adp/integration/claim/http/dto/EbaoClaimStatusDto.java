package tw.com.transglobe.adp.integration.claim.http.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Schema(description = "INT-CLM-071 聯盟鏈理賠記錄 理賠案件")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EbaoClaimStatusDto {

  @Schema(description = "保單來源別")
  String policySource;

  @Schema(description = "理賠案號")
  String caseNo;

  @Schema(description = "理賠受理日")
  LocalDate acceptTime;

  @Schema(description = "事故人ID")
  String certCode;

  @Schema(description = "事故人姓名")
  String accidentName;

  @Schema(description = "事故者生日")
  LocalDate accidentBirthday;

  @Schema(description = "事故日期")
  LocalDate accidentTime;

  @Schema(description = "結案日期")
  LocalDate approveTime;

  @Schema(description = "審核員員編")
  String auditorId;

  @Schema(description = "審核員姓名")
  String auditorName;

  @Schema(description = "審核員單位")
  String auditorOrgan;

  @Schema(description = "審核員電話")
  String auditorTel;

  @Schema(description = "審核員分機")
  String auditorExt;

  @Schema(description = "審核員Email")
  String auditorEmail;

  @Schema(description = "理賠案件狀態")
  String caseStatusCode;

  @Schema(description = "理賠案件狀態描述")
  String caseStatusDesc;

  @Schema(description = "是否調查")
  String isSurvey;

  @Schema(description = "備註")
  String generalComm;

  @Schema(description = "送件業務員登錄證號")
  String rptrNo;

  @Schema(description = "送件業務員姓名")
  String rptrName;

  @Schema(description = "診斷清單")
  List<EbaoClaimDiagnosisDto> diagnosisList;

  @Schema(description = "就醫經過清單")
  List<EbaoClaimMedicalBillDto> medicalBillList;

  @Schema(description = "保單內容清單")
  List<EbaoClaimPolicyDataDto> policyDataList;

  @Schema(description = "是否可調閱")
  String checkFlag;

  @Schema(description = "申請類型")
  Integer claimType;

  @Schema(description = "事故種類代碼")
  Integer claimNature;
}
