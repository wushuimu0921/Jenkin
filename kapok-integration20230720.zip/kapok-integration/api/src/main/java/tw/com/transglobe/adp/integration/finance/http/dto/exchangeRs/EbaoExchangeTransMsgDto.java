package tw.com.transglobe.adp.integration.finance.http.dto.exchangeRs;

import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EbaoExchangeTransMsgDto {

  Integer transSeq; // 交易流水號

  @Builder.Default
  List<EbaoExchangeCashDataMsgDto> cashDataMsgs = new ArrayList<EbaoExchangeCashDataMsgDto>();

  @Builder.Default
  List<EbaoExchangeArapDataMsgDto> arapDataMsgs = new ArrayList<EbaoExchangeArapDataMsgDto>();
}
