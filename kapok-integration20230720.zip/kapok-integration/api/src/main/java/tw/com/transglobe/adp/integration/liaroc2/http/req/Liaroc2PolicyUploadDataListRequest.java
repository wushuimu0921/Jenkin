package tw.com.transglobe.adp.integration.liaroc2.http.req;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;
import tw.com.transglobe.adp.integration.liaroc2.enums.Cmptype;

@Data
@Builder
public class Liaroc2PolicyUploadDataListRequest {

  @Schema(description = "通報類型")
  Cmptype cmptype;

  @Schema(description = "公司代碼")
  String cmpno;

  @Schema(description = "被保險人姓名")
  String name;

  @Schema(description = "被保險人idno")
  String idno;

  @Schema(description = "被保險人生日")
  String birdate;

  @Schema(description = "被保險人性別")
  String sex;

  @Schema(description = "主約保單號碼")
  String insnom;

  @Schema(description = "保單號碼")
  String insno;

  @Schema(description = "來源別")
  String origin;

  @Schema(description = "銷售通路別")
  String channel;

  @Schema(description = "商品代碼")
  String prdcode;

  @Schema(description = "保單分類")
  String insclass;

  @Schema(description = "險種分類")
  String inskind;

  @Schema(description = "險種")
  String insitem;

  @Schema(description = "公、自費件")
  String paytype;

  @Schema(description = "給付項目(身故)")
  String itema;

  @Schema(description = "給付項目(全殘或最高級殘)")
  String itemb;

  @Schema(description = "給付項目(殘廢扶助金)")
  String itemc;

  @Schema(description = "給付項目(特定事故保險金)")
  String itemd;

  @Schema(description = "給付項目(初次罹患)")
  String iteme;

  @Schema(description = "給付項目(醫療限額)")
  String itemf;

  @Schema(description = "給付項目(醫療限額自負額)")
  String itemg;

  @Schema(description = "給付項目(日額)")
  String itemh;

  @Schema(description = "給付項目(住院手術)")
  String itemi;

  @Schema(description = "給付項目(門診手術)")
  String itemj;

  @Schema(description = "給付項目(門診)")
  String itemk;

  @Schema(description = "給付項目(重大疾病(含特定傷病))")
  String iteml;

  @Schema(description = "給付項目(重大燒燙傷)")
  String itemm;

  @Schema(description = "給付項目(癌症療養)")
  String itemn;

  @Schema(description = "給付項目(出院療養)")
  String itemo;

  @Schema(description = "給付項目(失能)")
  String itemp;

  @Schema(description = "給付項目(喪葬費用)")
  String itemq;

  @Schema(description = "給付項目(銜接原醫療限額之自負額)")
  String itemr;

  @Schema(description = "給付項目(分期給付)")
  String items;

  @Schema(description = "契約生效日")
  String valdate;

  @Schema(description = "契約生效時分")
  String valtime;

  @Schema(description = "契約滿期日")
  String ovrdate;

  @Schema(description = "契約滿期時分")
  String ovrtime;

  @Schema(description = "保費")
  String prm;

  @Schema(description = "保費繳別")
  String bamttype;

  @Schema(description = "保費繳費年期")
  String prmyears;

  @Schema(description = "保單狀況")
  String con;

  @Schema(description = "保單狀況生效日期")
  String condate;

  @Schema(description = "保單狀況生效時分")
  String contime;

  @Schema(description = "要保人姓名")
  String askname;

  @Schema(description = "要保人身分證號")
  String askidno;

  @Schema(description = "要保人出生日期")
  String askbirdate;

  @Schema(description = "要保人被保人關係")
  String asktype;

  @Schema(description = "要保書填寫日期")
  String filldate;

  @Schema(description = "保經代類別")
  String broktype;

}
