package tw.com.transglobe.adp.integration.ebao.policy.http.dto;

import java.time.LocalDate;
import lombok.Data;

@Data
public class EbaoPolicyDto {
  String policyNo;
  String localName;
  LocalDate birthday;
}
