package tw.com.transglobe.adp.integration.ebao.rest.http;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.SpringQueryMap;
import org.springframework.web.bind.annotation.GetMapping;
import tw.com.transglobe.adp.integration.ebao.rest.http.dto.QmlistDto;
import tw.com.transglobe.adp.integration.ebao.rest.http.request.QmlistRequest;

import java.util.List;

@Tag(name = "EbaoRestApi", description = "eBao standard REST API")
public interface EbaoRestApi {

  @Operation(summary = "Qmlist API", description = "取得品控名單")
  @GetMapping("/ebao/rest/qmlist")
  List<QmlistDto> getQmlist(@SpringQueryMap QmlistRequest request);
}

@FeignClient(name = "ebao-rest-api", url = "${transglobe.adp.integration.api-client.url}")
interface EbaoRestApiClient extends EbaoRestApi {

}
