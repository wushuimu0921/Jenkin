package tw.com.transglobe.adp.integration.aml.enums;

public enum AmlAppCode {

  GRP,
  TA,
  CLM

}
