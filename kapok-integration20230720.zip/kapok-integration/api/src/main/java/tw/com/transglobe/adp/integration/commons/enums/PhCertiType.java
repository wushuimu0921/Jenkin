package tw.com.transglobe.adp.integration.commons.enums;

public enum PhCertiType {
  PH_CERTI_TYPE_1("1"), //身分證字號
  PH_CERTI_TYPE_2("2"), //統一編號
  PH_CERTI_TYPE_3("3"), //統一證號
  PH_CERTI_TYPE("9") //其他
  ;

  final String value;

  PhCertiType(String value) {
    this.value = value;
  }

  public String getValue() {
    return this.value;
  }

}
