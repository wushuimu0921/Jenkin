package tw.com.transglobe.adp.integration.liaroc2.http.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.Data;

@Data
public class LiaInfoDto {

  // 通報類別 產壽險別 承保：壽險=L，產險=N 收件：壽險=R，產險=r
  String cmptype;

  // 公司別
  String cmpno;

  // 被保險人姓名
  String name;

  // 被保險人性別
  String sex;

  // 主約保單號碼
  String insnom;

  // 保單號
  String insno;

  // 來源別
  String origin;

  // 銷售通路別
  String channel;

  // 商品代碼
  String prdcode;

  // 保單分類 1個人  2團體  5網路投保
  String insclass;

  // 險種分類 1 人壽保險   2傷害保險    3健康保險
  String inskind;

  // 險種
  String insitem;

  // 公、自費件
  String paytype;

  // 給付項目(身故)
  BigDecimal itema;

  // 給付項目(全殘或最高級殘)
  BigDecimal itemb;

  // 給付項目(殘廢扶助金)
  BigDecimal itemc;

  // 給付項目(特定事故保險金)
  BigDecimal itemd;

  // 給付項目(初次罹患)
  BigDecimal iteme;

  // 給付項目(醫療限額)
  BigDecimal itemf;

  // 給付項目(醫療限額自負額)
  BigDecimal itemg;

  // 給付項目(日額)
  BigDecimal itemh;

  // 給付項目(住院手術)
  BigDecimal itemi;

  // 給付項目(門診手術)
  BigDecimal itemj;

  // 給付項目(門診)
  BigDecimal itemk;

  // 給付項目(重大疾病(含特定傷病))
  BigDecimal iteml;

  // 給付項目(重大燒燙傷)
  BigDecimal itemm;

  // 給付項目(癌症療養)
  BigDecimal itemn;

  // 給付項目(出院療養)
  BigDecimal itemo;

  // 給付項目(失能)
  BigDecimal itemp;

  // 給付項目(喪葬費用)
  BigDecimal itemq;

  // 給付項目(銜接原醫療限額之自負額)
  BigDecimal itemr;

  // 給付項目(分期給付)
  BigDecimal items;

  // 契約生效日
  String valdate;

  // 契約生效時分
  String valtime;

  // 契約滿期日
  String ovrdate;

  // 契約滿期時分
  String ovrtime;

  // 保費
  BigDecimal prm;

  // 保費繳別
  String bamttype;

  // 保費繳費年期
  String prmyears;

  // 保單狀況
  String con;

  // 保單狀況生效日期
  String condate;

  // 保單狀況生效時分
  String contime;

  // 要保人姓名
  String askname;

  // 要保人身分證號
  String askidno;

  // 要保人Birthday
  String askbirdate;

  // 要保人被保人關係
  String asktype;

  // 通報時間
  String adddate;

  // 要保書填寫日期
  String filldate;

  // 保經代類別
  String broktype;
}
