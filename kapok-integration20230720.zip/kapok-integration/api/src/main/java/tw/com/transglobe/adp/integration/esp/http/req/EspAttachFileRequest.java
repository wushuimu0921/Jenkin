package tw.com.transglobe.adp.integration.esp.http.req;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EspAttachFileRequest {

  String fileName;

  String extName;

  byte[] bytes;

}
