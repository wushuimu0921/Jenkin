package tw.com.transglobe.adp.integration.ebao.common.http.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EbaoCommonRequest {
  String systemCode;
  String serviceName;
  String rqBody;
}
