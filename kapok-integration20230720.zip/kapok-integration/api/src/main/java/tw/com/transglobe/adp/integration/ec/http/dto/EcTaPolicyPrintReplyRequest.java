package tw.com.transglobe.adp.integration.ec.http.dto;

import java.time.LocalDateTime;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;
import tw.com.transglobe.adp.integration.commons.enums.ProductGroupType;

@Data
@Builder
@Schema(description = "新旅平險AML 中風險簽核狀態通知")
public class EcTaPolicyPrintReplyRequest {

  @Schema(description = "產品類別 : default'TA'")
  ProductGroupType productGroupType;

  @Schema(description = "產品類別代碼 : default'TA'")
  String productTypeCode; // TA

  @Schema(description = "保單號碼")
  String policyNo;

  @Schema(description = "通過時間")
  LocalDateTime approveTime;

}
