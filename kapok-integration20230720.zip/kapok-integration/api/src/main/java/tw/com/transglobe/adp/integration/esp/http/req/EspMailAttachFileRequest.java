package tw.com.transglobe.adp.integration.esp.http.req;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EspMailAttachFileRequest {

  @NotNull
  Long policyId;

  String quotationNo;

  String policyNo;

  @NotEmpty
  String applicantIdno;

  @NotEmpty
  String senderEmail;

  @NotEmpty
  String senderName;

  @NotEmpty
  String contactEmail;

  String mailSubject;

  String mailContent;

  @Schema(description = "檔案加密密碼, 應給予要保單位或要保人 idno")
  String filePassword;

  //  @Schema(description = "附加檔名")
  //  String fileKey;

  @Schema(description = "事件代號, ADP-0001")
  String eventCode;

  @Schema(description = "附加檔案路徑")
  List<UploadFileDto> files;
}
