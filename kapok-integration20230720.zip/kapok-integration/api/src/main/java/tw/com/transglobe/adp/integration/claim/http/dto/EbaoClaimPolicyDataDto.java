package tw.com.transglobe.adp.integration.claim.http.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Schema(description = "INT-CLM-071 聯盟鏈理賠記錄 保單內容物件")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EbaoClaimPolicyDataDto {

  @Schema(description = "保單號碼")
  String policyCode;

  @Schema(description = "保單地址")
  String policyAddress;

  @Schema(description = "關係")
  String relation;

  @Schema(description = "保單總賠付額")
  String policyPayAmount;

  @Schema(description = "險種內容清單")
  List<EbaoClaimProductDataDto> productDataList;

}
