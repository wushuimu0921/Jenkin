package tw.com.transglobe.adp.integration.commons.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum ChargePeriod {
  CHARGE_PERIOD_0("0"), // 無關
  CHARGE_PERIOD_1("1"), // 躉繳
  CHARGE_PERIOD_2("2"), // 按年限繳
  CHARGE_PERIOD_3("3"), // 繳至某定年齡
  CHARGE_PERIOD_4("4");// 終身繳費

  @Getter
  final private String value;

}
