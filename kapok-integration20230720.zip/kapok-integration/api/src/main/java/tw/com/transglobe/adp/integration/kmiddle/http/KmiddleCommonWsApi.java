package tw.com.transglobe.adp.integration.kmiddle.http;

import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import tw.com.transglobe.adp.integration.claim.http.dto.EbaoClaimQueryDto;
import tw.com.transglobe.adp.integration.commons.enums.ProductGroupType;
import tw.com.transglobe.adp.integration.kmiddle.http.dto.KmiddlePolicyDto;

@Tag(name = "KmiddleCommonWsApi", description = "K-middle Common WebService")
public interface KmiddleCommonWsApi {

  @Operation(summary = "理賠查詢", description = "以事故者ID進行理賠查詢")
  @GetMapping("/kmiddle/claim/idno/{productGroupType}/{idno}")
  EbaoClaimQueryDto queryClaimByIdno(@PathVariable("productGroupType") ProductGroupType productGroupType,
      @PathVariable("idno") String idno);

  @Operation(summary = "理賠查詢", description = "以保單號進行理賠查詢")
  @GetMapping("/kmiddle/claim/policyno/{productGroupType}/{policyNo}")
  EbaoClaimQueryDto queryClaimByPolicyNo(@PathVariable("productGroupType") ProductGroupType productGroupType,
      @PathVariable("policyNo") String policyNo);

  @Operation(summary = "K-團險有效契約客戶查詢", description = "根據被保險人ID查詢K-團險是否存在有效契約")
  @GetMapping("/kmiddle/policy/idno/{productGroupType}/{idno}")
  List<KmiddlePolicyDto> queryPolicyByIdno(@PathVariable("productGroupType") ProductGroupType productGroupType,
      @PathVariable("idno") String idno);

}

@FeignClient(name = "kmiddle-common-ws", url = "${transglobe.adp.integration.api-client.url}")
interface KmiddleCommonWsApiClient extends KmiddleCommonWsApi {

}
