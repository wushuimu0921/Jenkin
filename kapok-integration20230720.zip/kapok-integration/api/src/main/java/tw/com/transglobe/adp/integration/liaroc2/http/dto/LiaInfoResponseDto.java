package tw.com.transglobe.adp.integration.liaroc2.http.dto;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;

@Data
public class LiaInfoResponseDto {

  // 資料檢查碼
  String rqUid;

  // 索引結果
  boolean liaSuccess;

  // 查詢之被保險人身分證號
  String keyidno;

  // 查詢之被保險人出生日期
  LocalDate keybirdate;

  // 公會回傳狀態代碼
  String rtncode;

  // 公會回傳狀態訊息
  String rtnmsg;

  // 是否有公會資料
  boolean hasLiaData;

  // 查詢資料日期
  LocalDate queryDate;

  List<LiaInfoDto> infoDtos = new ArrayList<>();
}
