package tw.com.transglobe.adp.integration.stakeholder.http;

import io.swagger.v3.oas.annotations.Operation;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import tw.com.transglobe.adp.integration.stakeholder.http.dto.StakeHolderDto;
import tw.com.transglobe.adp.integration.stakeholder.http.request.StakeHolderQueryRequest;

public interface StakeHolderApi {
  @Operation(summary = "stakeholder API", description = "查詢是否為利害關係人")
  @PostMapping("/stakeholder")
  StakeHolderDto getStakeHolder(@RequestBody StakeHolderQueryRequest request);
}

@FeignClient(name = "stakeholder-application", url = "${transglobe.adp.integration.api-client.url}")
interface StakeHolderApplicationClient extends StakeHolderApi {

}
