package tw.com.transglobe.adp.integration.stakeholder.http.request;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class StakeHolderQueryRequest {

  String applicantIdno; // 公司統編

  String applicantName; // 公司名稱 (有中文優先放中文, 也可以放英文)

  String representiveIdno; // 負責人身分證字號

  String representiveName; // 負責人姓名 (有中文優先放中文, 也可以放英文)
}
