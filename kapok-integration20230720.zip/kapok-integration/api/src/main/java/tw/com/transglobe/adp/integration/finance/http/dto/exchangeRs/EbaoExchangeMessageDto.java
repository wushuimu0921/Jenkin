package tw.com.transglobe.adp.integration.finance.http.dto.exchangeRs;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EbaoExchangeMessageDto {

  String columnName;

  String systemLength;

  String dataLength;

  String desc;
}
