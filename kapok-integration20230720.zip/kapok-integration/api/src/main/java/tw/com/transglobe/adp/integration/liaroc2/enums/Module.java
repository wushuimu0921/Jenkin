package tw.com.transglobe.adp.integration.liaroc2.enums;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "來源模組單位")
public enum Module {

  AFINS,
  FOA,
  POS,
  UNB,
  CLM,
  EC,
  GRP,
  TRV;

}
