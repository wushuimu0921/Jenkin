package tw.com.transglobe.adp.integration.liaroc2.http.req;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;
import tw.com.transglobe.adp.integration.liaroc2.enums.LoadingType;
import tw.com.transglobe.adp.integration.liaroc2.enums.Module;
import tw.com.transglobe.adp.integration.liaroc2.enums.SourceType;
import tw.com.transglobe.adp.integration.liaroc2.enums.SystemCode;

import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@Builder
public class Liaroc2PolicyUploadRequest {

  @NotNull(message = "來源模組名稱不得為空")
  @Schema(description = "來源模組名稱")
  SystemCode systemId;

  @NotNull(message = "來源模組單位不得為空")
  @Schema(description = "來源模組單位")
  Module module;

  @NotNull(message = "通報類型不得為空")
  @Schema(description = "通報類型")
  LoadingType loadingType;

  @Schema(description = "通報方式")
  String processMode;

  @Schema(description = "來源資料類型")
  SourceType sourceType;

  @Schema(description = "目標資料類型")
  String targetType;

  @Schema(description = "資料總筆數")
  Integer total;

  @Schema(description = "來源資料")
  List<Liaroc2PolicyUploadDataListRequest> dataList;

}
