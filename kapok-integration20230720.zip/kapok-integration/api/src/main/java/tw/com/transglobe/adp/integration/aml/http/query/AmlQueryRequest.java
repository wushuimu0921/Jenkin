package tw.com.transglobe.adp.integration.aml.http.query;

import java.util.List;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;
import tw.com.transglobe.adp.integration.aml.enums.AmlAppCode;
import tw.com.transglobe.adp.integration.aml.enums.AmlCallType;
import tw.com.transglobe.adp.integration.aml.enums.AmlCalculateType;

@Schema(description = "AML 查詢")
@Data
@Builder
public class AmlQueryRequest {

  @NotNull
  @Schema(description = "來源應用系統別, GRP, TA, CLM")
  AmlAppCode appCode;

  @NotEmpty
  @Schema(description = "登入使用者來源部門, ex: 4R")
  String unit;

  @NotNull
  @Schema(description = "調用類型, ex: CIFC -公司客戶, CIFI - 個人客戶")
  AmlCallType callType;

  @NotEmpty
  @Schema(description = "登入使用者的 AD 帳號")
  String loginAccount;

  @NotNull
  @Schema(description = "是否實時計算風險和名單檢測, 0.不計算但進行名單檢測, 1.計算且進行名單檢測, 2.計算但不進行名單檢測, 3.不計算且不進行名單檢測 , ex: 1")
  AmlCalculateType calcType;

  @NotNull
  @Schema(description = "主要客戶資訊")
  AmlCifDataDto cif;

  @Schema(description = "關聯客戶資訊")
  List<AmlRelDataDto> rels;

  @Schema(description = "帳戶資訊")
  List<AmlAccDataDto> acc;

  @Schema(description = "客戶資料是否完整")
  boolean isFull;

}
