package tw.com.transglobe.adp.integration.addrfmt.http;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.SpringQueryMap;
import org.springframework.web.bind.annotation.GetMapping;
import tw.com.transglobe.adp.integration.addrfmt.http.query.AddrFmtItemDto;
import tw.com.transglobe.adp.integration.addrfmt.http.query.AddrFmtQueryRequest;

@Tag(name = "AddrFmtApi", description = "AddrFmt API")
public interface AddrFmtApi {
  @Operation(summary = "AddrFmt API", description = "輸入地址進行地址正規化")
  @GetMapping("/addrFmt")
  AddrFmtItemDto getAddrFmt(@SpringQueryMap AddrFmtQueryRequest request);
}

@FeignClient(name = "addr-fmt-application", url = "${transglobe.adp.integration.api-client.url}")
interface AddrFmtApplicationClient extends AddrFmtApi {

}
