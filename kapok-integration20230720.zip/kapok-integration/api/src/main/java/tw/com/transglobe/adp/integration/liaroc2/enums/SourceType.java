package tw.com.transglobe.adp.integration.liaroc2.enums;

public enum SourceType {

  XML,
  JSON,
  CSV;

}
