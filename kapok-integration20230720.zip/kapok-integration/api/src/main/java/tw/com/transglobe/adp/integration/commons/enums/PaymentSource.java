package tw.com.transglobe.adp.integration.commons.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum PaymentSource {

  PAYMENT_SOURCE_0(0), //個險
  PAYMENT_SOURCE_2(2), //外勤薪資
  PAYMENT_SOURCE_3(3), //經代佣金
  PAYMENT_SOURCE_4(4), //團險
  PAYMENT_SOURCE_5(5), //旅平險
  PAYMENT_SOURCE_11(11),//團履險理賠
  ;

  Integer value;

}
