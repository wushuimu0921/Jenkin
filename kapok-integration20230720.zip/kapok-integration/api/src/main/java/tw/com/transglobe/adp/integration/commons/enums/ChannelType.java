package tw.com.transglobe.adp.integration.commons.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ChannelType {
  AGY1(1L, "業務一部"),
  AC(2L, "直營通路"),
  BR(5L, "經代事業部"),
  HO(4L, "內勤"),
  FID(6L, "金融通路事業部"),
  EC(9L, "電子商務"),
  DIRECT(3L, "直接戶");

  private final Long order;
  private final String channelName;

}
