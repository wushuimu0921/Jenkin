package tw.com.transglobe.adp.integration.liaroc2.enums;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * 保險存摺 主附約
 */
@RequiredArgsConstructor
public enum BasicInfoConvenantType {

  @Schema(description = "主約/顯示於主頁")
  MAIN_WITH_DISPLAY("1"),

  @Schema(description = "主約/不顯示於主頁")
  MAIN_WITHOUT_DISPLAY("2"),

  @Schema(description = "附約")
  ADDITIONAL("3");

  @Getter
  final String cmdValue;
}
