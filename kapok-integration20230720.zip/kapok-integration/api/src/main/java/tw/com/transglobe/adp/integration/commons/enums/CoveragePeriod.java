package tw.com.transglobe.adp.integration.commons.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum CoveragePeriod { //保障類型

  COVERAGE_PERIOD_0("0"), //無關
  COVERAGE_PERIOD_1("1"), //保終身
  COVERAGE_PERIOD_2("2"), //按年限保
  COVERAGE_PERIOD_3("3"), //保至某確定年齡
  COVERAGE_PERIOD_4("4")//按月保
  ;

  @Getter
  final private String value;

}
