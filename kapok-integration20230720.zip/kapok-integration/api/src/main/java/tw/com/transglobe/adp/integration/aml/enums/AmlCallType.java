package tw.com.transglobe.adp.integration.aml.enums;

public enum AmlCallType {

  CIFC, // 公司
  CIFI // 個人

}
