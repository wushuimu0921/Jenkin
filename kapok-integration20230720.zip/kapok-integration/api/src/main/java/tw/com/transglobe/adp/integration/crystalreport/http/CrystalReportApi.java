package tw.com.transglobe.adp.integration.crystalreport.http;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import tw.com.transglobe.adp.integration.crystalreport.http.dto.CrystalReportDto;
import tw.com.transglobe.adp.integration.crystalreport.http.query.CrystalReportRequest;

@Deprecated
@Tag(name = "CrystalReportApi", description = "CrystalReport API")
public interface CrystalReportApi {

  @Deprecated
  @Operation(summary = "CrystalReport API", description = "取得 PDF")
  @PostMapping("/crystalReport")
  CrystalReportDto getCrystalReport(@RequestBody CrystalReportRequest request);
}

@FeignClient(name = "crystal-report-api", url = "${transglobe.adp.integration.api-client.url}")
interface CrystalReportApiClient extends CrystalReportApi {

}
