package tw.com.transglobe.adp.integration.finance.http.dto.chequeInfo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import tw.com.transglobe.adp.integration.commons.enums.EbaoChequeStatus;
import tw.com.transglobe.adp.integration.commons.enums.YesNo;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ChequeDto {
  @Schema(description = "支票代碼")
  Long chequeId;

  @Schema(description = "銀行名稱")
  String bankName;

  @Schema(description = "支票號碼")
  String chequeNo;

  @Schema(description = "受款人證號類型")
  String payeeCertiType;

  @Schema(description = "受款人證號")
  String payeeCertiCode;

  @Schema(description = "支票票面金額")
  String feeAmount;

  @Schema(description = "支票狀態")
  EbaoChequeStatus chequeStatus;

  @Schema(description = "支票狀態名稱")
  String chequeStatusName;

  @Schema(description = "支票列印時間")
  LocalDate printTime;

  @Schema(description = "支票取消時間")
  LocalDate cancelTime;

  @Schema(description = "支票預計兌現日")
  LocalDate chequeDueDate;

  @Schema(description = "支票帳號")
  String chequeAccount;

  @Schema(description = "發票人")
  String chequeHolder;

  @Schema(description = "支票付款行")
  String chequeBank;

  @Schema(description = "票據來源")
  Integer chequeSource;

  @Schema(description = "狀態異動日期")
  LocalDate changeDate;

  @Schema(description = "兌現日期")
  LocalDate cashChequeDate;

  @Schema(description = "取消劃線註記")
  YesNo cancelScoreIndi;

  @Schema(description = "取消禁背註記")
  YesNo cancelEndorsementIndi;

  @Schema(description = "支票關係人中文")
  String chequeRelationName;

  @Schema(description = "系統別  (1. ADP)")
  Integer systemId;

  @Schema(description = "系統別名稱")
  String systemName;

  @Schema(description = "次系統別")
  Integer subSystemId;

  @Schema(description = "次系統名稱")
  String subSystemName;

  @Schema(description = "業務類型設定代碼")
  Integer businessTypeId;

  @Schema(description = "業務類型設定名稱")
  String businessTypeName;

  @Schema(description = "支票異動歷程")
  List<ChequeHistDto> chequeHist;

  @Schema(description = "開立支票時間")
  LocalDate openChequeTime;

  @Schema(description = "開立支票人員名")
  String openChequeUserName;

}
