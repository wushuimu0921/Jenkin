package tw.com.transglobe.adp.integration.commons.enums;

public enum Status {

  SUCCESS,
  FAIL

}
