package tw.com.transglobe.adp.integration.liaroc2.enums;

/**
 * 查詢類型
 * All：收件+承保+理賠，EbaoAll：收件+承保
 * InsActRv：收件，InsAct：承保，InsActCl：理賠，InsDead：身故
 * （SFTP傳送時不可指定:EbaoAll, InsActRv, InsAct, InsActCl）
 */
public enum LoadingType {

  EbaoAll,
  InsActRv,
  InsAct,
  InsActCl,
  InsDead;
}
