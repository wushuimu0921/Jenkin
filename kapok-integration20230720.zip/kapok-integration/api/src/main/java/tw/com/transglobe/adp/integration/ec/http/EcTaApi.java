package tw.com.transglobe.adp.integration.ec.http;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.RequestBody;
import tw.com.transglobe.adp.integration.ec.http.dto.EcTaPolicyPrintReplyRequest;
import tw.com.transglobe.adp.integration.ec.http.dto.EcTaResultDto;

@Tag(name = "EcTaApi", description = "旅平險 EC API")
public interface EcTaApi {

  //  @PostMapping("/ec/notice-policy-decision")
  //  public EcResultDto noticePolicyDecision(EcTaPolicyDecisionRequest request);

  @Operation(summary = "INT-EC-500", description = "新旅平險簽核狀態通知")
  @PostMapping("/ec/policy-print-reply")
  EcTaResultDto policyPrintReply(@RequestBody EcTaPolicyPrintReplyRequest request);

}

@FeignClient(name = "ec-ta", url = "${transglobe.adp.integration.api-client.url}")
interface EcTaApiClient extends EcTaApi {

}
