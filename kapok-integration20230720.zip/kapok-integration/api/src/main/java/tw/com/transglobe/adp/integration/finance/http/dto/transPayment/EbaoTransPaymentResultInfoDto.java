package tw.com.transglobe.adp.integration.finance.http.dto.transPayment;

import lombok.Builder;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;
import io.swagger.v3.oas.annotations.media.Schema;

@Data
@Builder
@Schema(description = "付款結果查詢結果資料")
public class EbaoTransPaymentResultInfoDto {

  @Schema(description = "總筆數")
  Integer totalCount;

  @Schema(description = "失敗筆數")
  Integer failCount;

  @Schema(description = "成功筆數")
  Integer successCount;

  @Schema(description = "未執行筆數")
  Integer unpaidCount;

  @Schema(description = "付款結果查詢結果明細資料")
  @Builder.Default
  List<EbaoTransPaymentFailResultDto> paymentFailResults = new ArrayList<EbaoTransPaymentFailResultDto>();
}
