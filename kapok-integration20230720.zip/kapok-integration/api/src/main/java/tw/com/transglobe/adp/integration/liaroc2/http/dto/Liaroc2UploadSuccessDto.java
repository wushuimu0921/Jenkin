package tw.com.transglobe.adp.integration.liaroc2.http.dto;

import lombok.Data;

@Data
public class Liaroc2UploadSuccessDto {

  String code;
  String message;

}
