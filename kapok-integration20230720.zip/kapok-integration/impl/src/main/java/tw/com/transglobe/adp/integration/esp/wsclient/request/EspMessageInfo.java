package tw.com.transglobe.adp.integration.esp.wsclient.request;

import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.util.List;

/**
 *
 * 訊息資訊
 *
 * @author Default User
 *
 */
@Data
@Builder
public class EspMessageInfo {

  @NotEmpty
  String referenceId;
  String subject;
  String msgData;

  @NotEmpty
  String fromAddress;
  @NotEmpty
  String fromName;
  List<String> toAddress;

  EspAttachInfo attachInfo;

}
