
package tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRs;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * paymentResult complex type 的 Java 類別.
 *
 * <p>
 * 下列綱要片段會指定此類別中包含的預期內容.
 *
 * <pre>
 * &lt;complexType name="paymentResult"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ResultCode" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="ResultDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ResultEbaoDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="RefId" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "paymentResult", propOrder = {
    "resultCode",
    "resultDesc",
    "resultEbaoDesc",
    "refId"
})
public class PaymentResult {

  @XmlElement(name = "ResultCode", required = true)
  protected String resultCode;
  @XmlElement(name = "ResultDesc")
  protected String resultDesc;
  @XmlElement(name = "ResultEbaoDesc")
  protected String resultEbaoDesc;
  @XmlElement(name = "RefId", required = true)
  protected String refId;

  /**
   * 取得 resultCode 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getResultCode() {
    return resultCode;
  }

  /**
   * 設定 resultCode 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setResultCode(String value) {
    this.resultCode = value;
  }

  /**
   * 取得 resultDesc 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getResultDesc() {
    return resultDesc;
  }

  /**
   * 設定 resultDesc 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setResultDesc(String value) {
    this.resultDesc = value;
  }

  /**
   * 取得 resultEbaoDesc 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getResultEbaoDesc() {
    return resultEbaoDesc;
  }

  /**
   * 設定 resultEbaoDesc 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setResultEbaoDesc(String value) {
    this.resultEbaoDesc = value;
  }

  /**
   * 取得 refId 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getRefId() {
    return refId;
  }

  /**
   * 設定 refId 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setRefId(String value) {
    this.refId = value;
  }

}
