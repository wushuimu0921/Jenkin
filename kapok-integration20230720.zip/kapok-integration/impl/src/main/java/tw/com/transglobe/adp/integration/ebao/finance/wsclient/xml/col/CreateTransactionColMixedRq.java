//
// ���ɮ׬O�� JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.3.0 �Ҳ���
// �аѾ\ <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a>
// �@�����s�sĶ�ӷ����n, �惡�ɮשҰ�������קﳣ�N�|��.
// ���ͮɶ�: 2022.05.28 �� 10:58:49 AM CST
//

package tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.col;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * createTransactionColMixedRq complex type �� Java ���O.
 *
 * <p>
 * �U�C���n���q�|���w�����O���]�t���w�����e.
 *
 * <pre>
 * &lt;complexType name="createTransactionColMixedRq"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="TransColMixedInfos" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="TransColMixedInfo" type="{}transactionColMixedInfo" maxOccurs="unbounded"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createTransactionColMixedRq", propOrder = {
    "transColMixedInfos"
})
@XmlRootElement(name = "GlTransColMixedRq")
public class CreateTransactionColMixedRq {

  @XmlElement(name = "TransColMixedInfos")
  protected CreateTransactionColMixedRq.TransColMixedInfos transColMixedInfos;

  /**
   * ���o transColMixedInfos �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link CreateTransactionColMixedRq.TransColMixedInfos }
   *
   */
  public CreateTransactionColMixedRq.TransColMixedInfos getTransColMixedInfos() {
    return transColMixedInfos;
  }

  /**
   * �]�w transColMixedInfos �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link CreateTransactionColMixedRq.TransColMixedInfos }
   *
   */
  public void setTransColMixedInfos(CreateTransactionColMixedRq.TransColMixedInfos value) {
    this.transColMixedInfos = value;
  }

  /**
   * <p>
   * anonymous complex type �� Java ���O.
   *
   * <p>
   * �U�C���n���q�|���w�����O���]�t���w�����e.
   *
   * <pre>
   * &lt;complexType&gt;
   *   &lt;complexContent&gt;
   *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
   *       &lt;sequence&gt;
   *         &lt;element name="TransColMixedInfo" type="{}transactionColMixedInfo" maxOccurs="unbounded"/&gt;
   *       &lt;/sequence&gt;
   *     &lt;/restriction&gt;
   *   &lt;/complexContent&gt;
   * &lt;/complexType&gt;
   * </pre>
   *
   *
   */
  @XmlAccessorType(XmlAccessType.FIELD)
  @XmlType(name = "", propOrder = {
      "transColMixedInfo"
  })
  public static class TransColMixedInfos {

    @XmlElement(name = "TransColMixedInfo", required = true)
    protected List<TransactionColMixedInfo> transColMixedInfo;

    /**
     * Gets the value of the transColMixedInfo property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the transColMixedInfo property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     *
     * <pre>
     * getTransColMixedInfo().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TransactionColMixedInfo }
     *
     *
     */
    public List<TransactionColMixedInfo> getTransColMixedInfo() {
      if (transColMixedInfo == null) {
        transColMixedInfo = new ArrayList<TransactionColMixedInfo>();
      }
      return this.transColMixedInfo;
    }

  }

}
