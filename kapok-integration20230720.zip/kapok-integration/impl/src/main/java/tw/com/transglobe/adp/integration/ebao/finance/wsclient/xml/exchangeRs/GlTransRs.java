package tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.exchangeRs;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "glTransRs", propOrder = {
    "responseObj",
    "responseCode",
    "responseDesc"
})
@XmlRootElement(name = "GlTransRs")
public class GlTransRs {

  @XmlElement(name = "ResponseObj")
  protected ResponseObj responseObj;

  // XML執行結果
  @XmlElement(name = "ResponseCode")
  protected String responseCode;

  // XML執行結果說明
  @XmlElement(name = "ResponseDesc")
  protected String responseDesc;

  //  @XmlElementWrapper(name = "TransMsgs")
  //  @XmlElement(name = "TransMsg")
  //  protected List<TransMsg> transMsgs;

  public ResponseObj getResponseObj() {
    return responseObj;
  }

  public void setResponseObj(ResponseObj responseObj) {
    this.responseObj = responseObj;
  }

  public String getResponseCode() {
    return responseCode;
  }

  public void setResponseCode(String responseCode) {
    this.responseCode = responseCode;
  }

  public String getResponseDesc() {
    return responseDesc;
  }

  public void setResponseDesc(String responseDesc) {
    this.responseDesc = responseDesc;
  }

  //  public List<TransMsg> getTransMsgs() {
  //    return transMsgs;
  //  }
  //
  //  public void setTransMsgs(List<TransMsg> transMsgs) {
  //    this.transMsgs = transMsgs;
  //  }

}
