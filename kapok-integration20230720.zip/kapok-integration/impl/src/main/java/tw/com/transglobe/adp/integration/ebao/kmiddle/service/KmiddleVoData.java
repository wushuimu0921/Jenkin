package tw.com.transglobe.adp.integration.ebao.kmiddle.service;

import lombok.Builder;
import lombok.Data;

import javax.xml.datatype.XMLGregorianCalendar;

@Data
@Builder
public class KmiddleVoData {

  protected String caseNo;
  protected XMLGregorianCalendar approveDate;
  protected String status;
  protected String insuredId;
  protected String insuredName;
  protected XMLGregorianCalendar accidentDate;
  protected String accidentReason;
  protected String diagnosisName;
  protected String remark;
  protected KmiddleClaimPolicyDataList claimPolicyDataList;
  protected KmiddleClaimSurgeryDataList claimSurgeryDataList;
  protected KmiddleClaimBillDataList claimBillDataList;
}
