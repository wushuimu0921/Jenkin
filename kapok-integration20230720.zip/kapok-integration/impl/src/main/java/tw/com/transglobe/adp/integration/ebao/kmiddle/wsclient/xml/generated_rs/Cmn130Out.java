//
// ���ɮ׬O�� JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.8-b130911.1802 �Ҳ���
// �аѾ\ <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a>
// �@�����s�sĶ�ӷ����n, �惡�ɮשҰ�������קﳣ�N�|��.
// ���ͮɶ�: 2022.10.05 �� 12:31:29 PM CST
//

package tw.com.transglobe.adp.integration.ebao.kmiddle.wsclient.xml.generated_rs;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.*;

/**
 * <p>
 * cmn130Out complex type �� Java ���O.
 *
 * <p>
 * �U�C���n���q�|���w�����O���]�t���w�����e.
 *
 * <pre>
 * &lt;complexType name="cmn130Out">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ClaimDataList" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element ref="{}ClaimData" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "cmn130Out", propOrder = {
    "claimDataList"
})
@XmlRootElement(name = "GroupClaimRecordQueryRs")
public class Cmn130Out {

  @XmlElement(name = "ClaimDataList")
  protected Cmn130Out.ClaimDataList claimDataList;

  /**
   * ���o claimDataList �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link Cmn130Out.ClaimDataList }
   *
   */
  public Cmn130Out.ClaimDataList getClaimDataList() {
    return claimDataList;
  }

  /**
   * �]�w claimDataList �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link Cmn130Out.ClaimDataList }
   *
   */
  public void setClaimDataList(Cmn130Out.ClaimDataList value) {
    this.claimDataList = value;
  }

  /**
   * <p>
   * anonymous complex type �� Java ���O.
   *
   * <p>
   * �U�C���n���q�|���w�����O���]�t���w�����e.
   *
   * <pre>
   * &lt;complexType>
   *   &lt;complexContent>
   *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
   *       &lt;sequence>
   *         &lt;element ref="{}ClaimData" maxOccurs="unbounded" minOccurs="0"/>
   *       &lt;/sequence>
   *     &lt;/restriction>
   *   &lt;/complexContent>
   * &lt;/complexType>
   * </pre>
   *
   *
   */
  @XmlAccessorType(XmlAccessType.FIELD)
  @XmlType(name = "", propOrder = {
      "claimData"
  })
  public static class ClaimDataList {

    @XmlElement(name = "ClaimData")
    protected List<Cmn130OutC1> claimData;

    /**
     * Gets the value of the claimData property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the claimData property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     *
     * <pre>
     * getClaimData().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Cmn130OutC1 }
     *
     *
     */
    public List<Cmn130OutC1> getClaimData() {
      if (claimData == null) {
        claimData = new ArrayList<Cmn130OutC1>();
      }
      return this.claimData;
    }

  }

}
