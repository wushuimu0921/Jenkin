package tw.com.transglobe.adp.integration.esp.service.cmd;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;
import tw.com.transglobe.adp.integration.commons.enums.ProductGroupType;

import javax.validation.constraints.NotEmpty;
import java.util.List;

@Data
@Builder
public class EspMailCmd {

  @Schema(description = "險別")
  @NotEmpty
  ProductGroupType productGroupType;

  @Schema(description = "來源系統 功能類型 id") //ESP 紀錄用，方便查詢問題，Ex: member
  String contactSysOperatorId;

  @Schema(description = "來源系統 功能類型中文敘述") //ESP 紀錄用，方便查詢問題，Ex: 會員專區
  String contactSysOperatorName;

  @Schema(description = "訊息類型 id") //ESP 紀錄用，方便查詢問題，Ex: LOGON
  String functionCategory;

  @Schema(description = "訊息類型 名稱") //ESP 紀錄用，方便查詢問題，Ex: 全球人壽保戶專區會員登入通知
  String functionName;

  @Schema(description = "保單ID")
  @NotEmpty
  Long policyId;

  @Schema(description = "保單號碼")
  @NotEmpty
  String policyNo;

  @Schema(description = "要保人證號")
  String proposerId;

  @Schema(description = "被保人證號")
  String insuredId;

  @Schema(description = "受益人證號")
  String beneficiaryId;

  @Schema(description = "寄件人EMAIL")
  @NotEmpty
  String senderEmail;

  @Schema(description = "寄件人姓名")
  @NotEmpty
  String senderName;

  @Schema(description = "收件人EMAIL")
  List<String> contactEmails;

  @Schema(description = "信件主旨")
  @NotEmpty
  String mailSubject;

  @Schema(description = "信件內容")
  @NotEmpty
  String mailContent;

  @Schema(description = "附加檔案")
  List<EspAttachFileCmd> attachFiles;

  @Schema(description = "是否壓縮附加檔案")
  boolean doZip;

  @Schema(description = "壓縮附加檔案檔名")
  String zipFileName;

  @Schema(description = "附加檔案解壓縮密碼")
  String zipCert;

  @Schema(description = "事件ID")
  @NotEmpty
  String eventId;

}
