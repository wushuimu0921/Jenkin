package tw.com.transglobe.adp.integration.ebao.finance.wsclient;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;
import org.mapstruct.NullValueCheckStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import tw.com.transglobe.adp.integration.commons.enums.ChannelType;
import tw.com.transglobe.adp.integration.commons.enums.ChargePeriod;
import tw.com.transglobe.adp.integration.commons.enums.ChargeType;
import tw.com.transglobe.adp.integration.commons.enums.CheckSource;
import tw.com.transglobe.adp.integration.commons.enums.CoveragePeriod;
import tw.com.transglobe.adp.integration.commons.enums.EbaoChequeStatus;
import tw.com.transglobe.adp.integration.commons.enums.FeeStatus;
import tw.com.transglobe.adp.integration.commons.enums.FeeType;
import tw.com.transglobe.adp.integration.commons.enums.MoneyId;
import tw.com.transglobe.adp.integration.commons.enums.PayMode;
import tw.com.transglobe.adp.integration.commons.enums.PaySource;
import tw.com.transglobe.adp.integration.commons.enums.PhCertiType;
import tw.com.transglobe.adp.integration.commons.enums.ProdContract;
import tw.com.transglobe.adp.integration.commons.enums.WithdrawType;
import tw.com.transglobe.adp.integration.ebao.finance.service.chequeInfo.EbaoChequeInfoVo;
import tw.com.transglobe.adp.integration.ebao.finance.service.chequeInfo.EbaoChequeVo;
import tw.com.transglobe.adp.integration.ebao.finance.service.cmd.EbaoFinanceAparCreateCmd;
import tw.com.transglobe.adp.integration.ebao.finance.service.cmd.EbaoFinanceCollectCreateCmd;
import tw.com.transglobe.adp.integration.ebao.finance.service.cmd.EbaoFinanceGetPaymentCmd;
import tw.com.transglobe.adp.integration.ebao.finance.service.cmd.EbaoFinancePayCreateCmd;
import tw.com.transglobe.adp.integration.ebao.finance.service.cmd.EbaoFinanceQueryChequeCmd;
import tw.com.transglobe.adp.integration.ebao.finance.service.cmd.EbaoFinanceTransPostingCmd;
import tw.com.transglobe.adp.integration.ebao.finance.service.exchange.EbaoExchangeResponseVo;
import tw.com.transglobe.adp.integration.ebao.finance.service.transPayment.EbaoTransPaymentInfoVo;
import tw.com.transglobe.adp.integration.ebao.finance.service.transPosting.EbaoTransPostingInfoVo;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.col.CollectionInfo;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.col.TransactionColArapInfo;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.exchangeRs.GlTransRs;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.pay.PaymentInfo;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.pay.TransactionPayArapInfo;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRq.QueryChequeInfoRq;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRq.TransPaymentInfoRq;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRq.TransPostingInfoRq;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRs.TransCheckInfoRs;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRs.TransPaymentInfoRs;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRs.TransPostingInfoRs;

@Mapper(nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
public interface EbaoFinanceWsMapper {

  Logger log = LoggerFactory.getLogger(EbaoFinanceWsMapper.class);

  EbaoExchangeResponseVo toExchangeVo(GlTransRs rs);

  EbaoChequeInfoVo toChequeInfoVo(TransCheckInfoRs rs);

  @Mapping(target = "chequeStatus", ignore = true)
  EbaoChequeVo toEbaoChequeVo(TransCheckInfoRs.Cheque rs);

  @AfterMapping
  default void afterTotoEbaoChequeVo(TransCheckInfoRs.Cheque cheque,
      @MappingTarget EbaoChequeVo.EbaoChequeVoBuilder vo) {
    vo.chequeStatus(EbaoChequeStatus.toEbaoChequeStatus(cheque.getChequeStatus()));
  }

  EbaoTransPaymentInfoVo toPaymentInfoVo(TransPaymentInfoRs rs);

  EbaoTransPostingInfoVo toPostingInfoVo(TransPostingInfoRs rs);

  @Mapping(target = "agentChannelTypeCode", source = "agentChannelType")
  @Mapping(target = "issueChannelTypeCode", source = "issueChannelType")
  @Mapping(target = "prodContractName", source = "prodContract", qualifiedByName = "prodContractToLocalName")
  TransactionColArapInfo toColArapInfo(EbaoFinanceAparCreateCmd cmd);

  @Mapping(target = "creditCardExpireDate", ignore = true)
  @Mapping(target = "agentChannelTypeCode", source = "agentChannelType")
  CollectionInfo toColInfo(EbaoFinanceCollectCreateCmd cmd);

  @AfterMapping
  default void afterToColInfo(EbaoFinanceCollectCreateCmd cmd, @MappingTarget CollectionInfo collect) {
    log.info("信用卡截止日:{}", cmd.getCreditCardExpireDate());
    if (StringUtils.length(cmd.getCreditCardExpireDate()) >= 6) {
      int expireDateYear = NumberUtils.toInt(cmd.getCreditCardExpireDate().substring(0, 4));
      int expireDateMonth = NumberUtils.toInt(cmd.getCreditCardExpireDate().substring(4, 6));
      collect.setCreditCardExpireDate(LocalDate.of(expireDateYear, expireDateMonth, 1));
    }
  }

  // feeAmount 跟 payAmount 都傳給eBao 正值
  @Mapping(target = "agentChannelTypeCode", source = "agentChannelType")
  @Mapping(target = "issueChannelTypeCode", source = "issueChannelType")
  @Mapping(target = "feeAmount", expression = "java(cmd.getFeeAmount() != null ? cmd.getFeeAmount().abs() : null)")
  @Mapping(target = "payAmount", expression = "java(cmd.getPayAmount() != null ? cmd.getPayAmount().abs() : null)")
  @Mapping(target = "prodContractName", source = "prodContract", qualifiedByName = "prodContractToLocalName")
  TransactionPayArapInfo toPayArapInfo(EbaoFinanceAparCreateCmd cmd);

  @Mapping(target = "creditCardExpireDate", ignore = true)
  PaymentInfo toPayInfo(EbaoFinancePayCreateCmd cmd);

  @AfterMapping
  default void afterToPayInfo(EbaoFinancePayCreateCmd cmd, @MappingTarget PaymentInfo pay) {
    log.info("信用卡截止日:{}", cmd.getCreditCardExpireDate());
    if (StringUtils.length(cmd.getCreditCardExpireDate()) >= 6) {
      int expireDateYear = NumberUtils.toInt(cmd.getCreditCardExpireDate().substring(0, 4));
      int expireDateMonth = NumberUtils.toInt(cmd.getCreditCardExpireDate().substring(4, 6));
      pay.setCreditCardExpireDate(LocalDate.of(expireDateYear, expireDateMonth, 1));
    }
  }

  QueryChequeInfoRq toQueryChequeInfoRq(EbaoFinanceQueryChequeCmd cmd);

  TransPaymentInfoRq toTransPaymentInfo(EbaoFinanceGetPaymentCmd cmd);

  TransPostingInfoRq toTransPostingInfo(EbaoFinanceTransPostingCmd cmd);

  default String dateToStr(LocalDate date) {
    return date.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
  }

  default Integer feeTypeToInt(FeeType fee) {
    return fee.getValue();
  }

  default int payModeToInt(PayMode pay) {
    return pay.getValue();
  }

  default int feeStatusToInt(FeeStatus status) {
    return status.getValue();
  }

  default int MoneyIdToInt(MoneyId id) {
    return id.getValue();
  }

  default Integer paySourceToInt(PaySource source) {
    return source.getValue();
  }

  default String phCertiTypeToString(PhCertiType phCertiType) {
    return phCertiType.getValue();
  }

  default Long channelTypeToLong(ChannelType channelType) {
    return channelType.getOrder();
  }

  default String chargeTypeToInteger(ChargeType chargeType) {
    return chargeType.getValue();
  }

  default String chargePeriodToInteger(ChargePeriod chargePeriod) {
    return chargePeriod.getValue();
  }

  default String coveragePeriodToString(CoveragePeriod coveragePeriod) {
    return coveragePeriod.getValue();
  }

  @Named("prodContractToLocalName")
  default String prodContractToLocalName(ProdContract prodContract) {
    return prodContract.getValue();
  }

  default String withdrawTypeToString(WithdrawType withdrawType) {
    return withdrawType.getValue();
  }

  default Integer checkSourceToInteger(CheckSource checkSource) {
    return checkSource.getValue();
  }

  @Named("expireDateChange")
  default String expireDateChange(String expDate) {
    String month = expDate.substring(0, 2);
    String year = expDate.substring(2, 4);
    return "20" + year + "/" + month + "/" + "01";
  }

  default LocalDate stringToDate(String date) {
    return LocalDate.parse(date, DateTimeFormatter.ofPattern("yyyy/MM/dd"));
  }
}
