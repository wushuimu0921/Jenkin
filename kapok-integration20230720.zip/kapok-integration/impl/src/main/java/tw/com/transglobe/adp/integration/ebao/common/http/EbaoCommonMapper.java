package tw.com.transglobe.adp.integration.ebao.common.http;

import org.mapstruct.Mapper;
import tw.com.transglobe.adp.integration.ebao.common.http.dto.EbaoCommonRequest;
import tw.com.transglobe.adp.integration.ebao.common.http.dto.EbaoCommonResponse;
import tw.com.transglobe.adp.integration.ebao.common.service.vo.EbaoCommonRequestVo;
import tw.com.transglobe.adp.integration.ebao.common.service.vo.EbaoCommonResponseVo;

@Mapper
interface EbaoCommonMapper {
  EbaoCommonRequestVo toRequest(EbaoCommonRequest request);

  EbaoCommonResponse toResponse(EbaoCommonResponseVo vo);
}
