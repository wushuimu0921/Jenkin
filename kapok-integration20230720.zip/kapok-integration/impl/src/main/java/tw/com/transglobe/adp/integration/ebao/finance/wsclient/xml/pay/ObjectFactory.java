//
// ���ɮ׬O�� JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.3.0 �Ҳ���
// �аѾ\ <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a>
// �@�����s�sĶ�ӷ����n, �惡�ɮשҰ�������קﳣ�N�|��.
// ���ͮɶ�: 2022.05.28 �� 10:58:57 AM CST
//

package tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.pay;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the tw.com.transglobe.kapok.integration.ebao.wsclient.xml.pay package.
 * <p>
 * An ObjectFactory allows you to programatically
 * construct new instances of the Java representation
 * for XML content. The Java representation of XML
 * content can consist of schema derived interfaces
 * and classes representing the binding of schema
 * type definitions, element declarations and model
 * groups. Factory methods for each of these are
 * provided in this class.
 *
 */
@XmlRegistry
public class ObjectFactory {

  private final static QName _GlTransPayRq_QNAME = new QName("", "GlTransPayRq");
  private final static QName _PaymentInfo_QNAME = new QName("", "PaymentInfo");
  private final static QName _TransArapInfo_QNAME = new QName("", "TransArapInfo");
  private final static QName _TransPayInfo_QNAME = new QName("", "TransPayInfo");

  /**
   * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package:
   * tw.com.transglobe.kapok.integration.ebao.wsclient.xml.pay
   *
   */
  public ObjectFactory() {
  }

  /**
   * Create an instance of {@link TransactionPayMixedInfo }
   *
   */
  public TransactionPayMixedInfo createTransactionPayMixedInfo() {
    return new TransactionPayMixedInfo();
  }

  /**
   * Create an instance of {@link CreateTransactionPayMixedRq }
   *
   */
  public CreateTransactionPayMixedRq createCreateTransactionPayMixedRq() {
    return new CreateTransactionPayMixedRq();
  }

  /**
   * Create an instance of {@link PaymentInfo }
   *
   */
  public PaymentInfo createPaymentInfo() {
    return new PaymentInfo();
  }

  /**
   * Create an instance of {@link TransactionPayArapInfo }
   *
   */
  public TransactionPayArapInfo createTransactionPayArapInfo() {
    return new TransactionPayArapInfo();
  }

  /**
   * Create an instance of {@link AbstractArapInfo }
   *
   */
  public AbstractArapInfo createAbstractArapInfo() {
    return new AbstractArapInfo();
  }

  /**
   * Create an instance of {@link TransactionPayMixedInfo.PaymentInfos }
   *
   */
  public TransactionPayMixedInfo.PaymentInfos createTransactionPayMixedInfoPaymentInfos() {
    return new TransactionPayMixedInfo.PaymentInfos();
  }

  /**
   * Create an instance of {@link TransactionPayMixedInfo.PayableInfos }
   *
   */
  public TransactionPayMixedInfo.PayableInfos createTransactionPayMixedInfoPayableInfos() {
    return new TransactionPayMixedInfo.PayableInfos();
  }

  /**
   * Create an instance of {@link CreateTransactionPayMixedRq.TransPayMixedInfos }
   *
   */
  public CreateTransactionPayMixedRq.TransPayMixedInfos createCreateTransactionPayMixedRqTransPayMixedInfos() {
    return new CreateTransactionPayMixedRq.TransPayMixedInfos();
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link CreateTransactionPayMixedRq }{@code >}
   *
   * @param value
   *        Java instance representing xml element's value.
   * @return
   *         the new instance of {@link JAXBElement }{@code <}{@link CreateTransactionPayMixedRq }{@code >}
   */
  @XmlElementDecl(namespace = "", name = "GlTransPayRq")
  public JAXBElement<CreateTransactionPayMixedRq> createGlTransPayRq(CreateTransactionPayMixedRq value) {
    return new JAXBElement<CreateTransactionPayMixedRq>(_GlTransPayRq_QNAME, CreateTransactionPayMixedRq.class, null, value);
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link PaymentInfo }{@code >}
   *
   * @param value
   *        Java instance representing xml element's value.
   * @return
   *         the new instance of {@link JAXBElement }{@code <}{@link PaymentInfo }{@code >}
   */
  @XmlElementDecl(namespace = "", name = "PaymentInfo")
  public JAXBElement<PaymentInfo> createPaymentInfo(PaymentInfo value) {
    return new JAXBElement<PaymentInfo>(_PaymentInfo_QNAME, PaymentInfo.class, null, value);
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link Object }{@code >}
   *
   * @param value
   *        Java instance representing xml element's value.
   * @return
   *         the new instance of {@link JAXBElement }{@code <}{@link Object }{@code >}
   */
  @XmlElementDecl(namespace = "", name = "TransArapInfo")
  public JAXBElement<Object> createTransArapInfo(Object value) {
    return new JAXBElement<Object>(_TransArapInfo_QNAME, Object.class, null, value);
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link TransactionPayMixedInfo }{@code >}
   *
   * @param value
   *        Java instance representing xml element's value.
   * @return
   *         the new instance of {@link JAXBElement }{@code <}{@link TransactionPayMixedInfo }{@code >}
   */
  @XmlElementDecl(namespace = "", name = "TransPayInfo")
  public JAXBElement<TransactionPayMixedInfo> createTransPayInfo(TransactionPayMixedInfo value) {
    return new JAXBElement<TransactionPayMixedInfo>(_TransPayInfo_QNAME, TransactionPayMixedInfo.class, null, value);
  }

}
