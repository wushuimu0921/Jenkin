package tw.com.transglobe.adp.integration.ebao.finance.service.cmd;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;
import tw.com.transglobe.adp.integration.commons.enums.YesNo;

import java.time.LocalDate;

@Data
@Builder
public class EbaoFinanceTransPostingCmd {

  @Schema(description = "過帳日期")
  LocalDate postingDate;

  @Schema(description = "資料進來日期")
  LocalDate dataDate;

  @Schema(description = "保單號碼")
  String policyCode;

  @Schema(description = "團旅險RefId")
  String refId;

  @Schema(description = "是否當下過帳的資料")
  YesNo isPresent;
}