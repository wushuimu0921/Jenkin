package tw.com.transglobe.adp.integration.crystalreport.wsclient;

import lombok.extern.slf4j.Slf4j;
import tw.com.transglobe.adp.integration.crystalreport.service.CrystalReportWebServiceClient;
import tw.com.transglobe.adp.integration.crystalreport.service.CrystalGenCmd;

@Slf4j
class CrystalReportWebServiceClientMock implements CrystalReportWebServiceClient {

  @Override
  public byte[] getCrystalreport(CrystalGenCmd request) {
    return new byte[] { 0x01, 0x02, 0x03 };
  }

}
