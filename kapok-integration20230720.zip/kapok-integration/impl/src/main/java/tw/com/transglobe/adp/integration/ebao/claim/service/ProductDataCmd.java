package tw.com.transglobe.adp.integration.ebao.claim.service;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;

@Data
@Builder
public class ProductDataCmd {

  String internalId;

  String productName;

  BigDecimal payAmount;
}
