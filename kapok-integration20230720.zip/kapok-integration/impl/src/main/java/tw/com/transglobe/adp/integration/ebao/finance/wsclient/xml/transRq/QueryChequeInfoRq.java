package tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRq;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.xml.bind.annotation.*;
import java.util.List;

@Getter
@Setter
@ToString
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "QueryChequeInfoRq", propOrder = {
    "chequeIds",
})
@XmlRootElement(name = "QueryChequeRq")
public class QueryChequeInfoRq {

  @XmlElementWrapper(name = "ChequeIds")
  @XmlElement(name = "ChequeId", required = true)
  protected List<Long> chequeIds;

}
