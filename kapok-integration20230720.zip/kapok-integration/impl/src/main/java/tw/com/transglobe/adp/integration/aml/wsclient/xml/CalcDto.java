package tw.com.transglobe.adp.integration.aml.wsclient.xml;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
@XmlRootElement(name = "calc")
@XmlAccessorType(XmlAccessType.FIELD)
public class CalcDto {
  @XmlElement(name = "Date", required = true)
  protected String date;
  @XmlElement(name = "Score", required = true)
  protected String score;
  @XmlElement(name = "Level", required = true)
  protected String level;
  @XmlElement(name = "Review", required = true)
  protected String review;
  @XmlElement(name = "RiskLevel", required = true)
  protected String riskLevel;
  @XmlElement(name = "DecDate", required = true)
  protected String decDate;
  @XmlElement(name = "DecBy", required = true)
  protected String decBy;
  @XmlElement(name = "LastComment", required = true)
  protected String lastComment;

}
