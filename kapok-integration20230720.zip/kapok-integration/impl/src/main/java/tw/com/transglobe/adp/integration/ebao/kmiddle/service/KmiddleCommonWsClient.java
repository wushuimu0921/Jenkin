package tw.com.transglobe.adp.integration.ebao.kmiddle.service;

import java.util.List;
import tw.com.transglobe.adp.integration.commons.enums.ProductGroupType;

public interface KmiddleCommonWsClient {

  /**
   * 查詢理賠記錄查詢 : cmn130
   *
   * @param type -
   *        1. 事故者ID
   *        2. 團險保單號碼
   *        3. 旅平險保單號碼
   */
  KmiddleClaimVo cmn130(ProductGroupType productGroupType, String type, String data);

  List<KmiddlePolicyVo> cmn150(ProductGroupType productGroupType, String idno);
}
