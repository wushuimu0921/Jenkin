@javax.xml.bind.annotation.XmlSchema(xmlns = {
    @javax.xml.bind.annotation.XmlNs(prefix = "ws", namespaceURI = "http://tgl.com/common/ws/"),
    //@javax.xml.bind.annotation.XmlNs(prefix = "soapenv", namespaceURI = "http://schemas.xmlsoap.org/soap/envelope/")
})

package tw.com.transglobe.adp.integration.ebao.common.wsclient;
