package tw.com.transglobe.adp.integration.ebao.kmiddle.service;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class KmiddleClaimSurgeryData {

  /** 調查案號 */
  String surgeryNo;
}
