package tw.com.transglobe.adp.integration.ebao.claim.wsclient.xml;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.xml.bind.annotation.*;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClaimRecordQuery071Rs")
@XmlRootElement(name = "ClaimRecordQuery071Rs")
@Getter
@Setter
@ToString
public class ClaimRecordQuery071Rs {

  @XmlElementWrapper(name = "ClaimStatusList")
  @XmlElement(required = true, name = "ClaimStatus")
  protected List<ClaimStatusVO> claimStatusList;

}
