package tw.com.transglobe.adp.integration.crystalreport.service;

public interface CrystalReportWebServiceClient {
  byte[] getCrystalreport(CrystalGenCmd request);
}
