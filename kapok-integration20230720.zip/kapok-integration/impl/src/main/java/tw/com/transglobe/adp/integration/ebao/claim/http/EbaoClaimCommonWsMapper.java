package tw.com.transglobe.adp.integration.ebao.claim.http;

import org.mapstruct.Mapper;
import org.mapstruct.NullValueCheckStrategy;
import tw.com.transglobe.adp.integration.claim.http.dto.EbaoClaimQueryDto;
import tw.com.transglobe.adp.integration.claim.http.dto.EbaoClaimQueryRequest;
import tw.com.transglobe.adp.integration.ebao.claim.service.ClaimRecordQuery071RqCmd;
import tw.com.transglobe.adp.integration.ebao.claim.service.ClaimRecordQuery071RsCmd;

@Mapper(nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
interface EbaoClaimCommonWsMapper {

  ClaimRecordQuery071RqCmd fromRequest(EbaoClaimQueryRequest request);

  EbaoClaimQueryDto fromVo(ClaimRecordQuery071RsCmd vo);
}
