package tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRq;

import lombok.Getter;
import lombok.Setter;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRs.PaymentSuccessInfo;

import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "transPaymentInfoRq", propOrder = {
    "ChequeNos",
})
@Getter
@Setter
@XmlRootElement(name = "ChequeNos")
public class QueryChequeInfo {

  @XmlElement(name = "ChequeNo", required = true)
  protected String chequeNo;

  @XmlElement(name = "PaymentSuccessResults")
  protected PaymentSuccessInfo.PaymentSuccessResults paymentSuccessResults;

}
