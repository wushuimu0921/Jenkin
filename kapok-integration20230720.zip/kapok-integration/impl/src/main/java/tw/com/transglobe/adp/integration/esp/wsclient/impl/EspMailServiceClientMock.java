package tw.com.transglobe.adp.integration.esp.wsclient.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import tw.com.transglobe.adp.integration.config.AdpIntegrationProperties;
import tw.com.transglobe.adp.integration.esp.service.cmd.EspMailCmd;
import tw.com.transglobe.adp.integration.esp.service.client.EspMailWebServiceClient;

@Slf4j
@RequiredArgsConstructor
public class EspMailServiceClientMock implements EspMailWebServiceClient {

  final AdpIntegrationProperties properties;

  @Override
  public String sendMail(EspMailCmd cmd) {
    log.info("Mock sendMail, contactEmails:{}, mailSubject:{}, url:{}", cmd.getContactEmails(),
        cmd.getMailSubject(), properties.getEspEmailAttach().getUrl());
    return "0000";
  }

}
