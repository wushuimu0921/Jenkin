package tw.com.transglobe.adp.integration.addrfmt.http;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RestController;
import tw.com.transglobe.adp.integration.addrfmt.http.query.AddrFmtItemDto;
import tw.com.transglobe.adp.integration.addrfmt.http.query.AddrFmtQueryRequest;
import tw.com.transglobe.adp.integration.addrfmt.service.AddressFormatService;

@Slf4j
@RestController
@RequiredArgsConstructor
class AddrFmtController implements AddrFmtApi {

  final AddressFormatService service;

  final AddrFmtItemDtoMapper mapper;

  @Override
  public AddrFmtItemDto getAddrFmt(AddrFmtQueryRequest request) {
    var addrFmtItem = service.getAddressFormat(request.getAddress());
    log.info("地址正規化回來的結果:{}", addrFmtItem);
    return mapper.toAddrFmtItem(addrFmtItem);
  }

}
