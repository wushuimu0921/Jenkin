package tw.com.transglobe.adp.integration.esp.service.cmd;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EspAttachFileCmd {

  String fileName;

  String extName;

  byte[] bytes;
}
