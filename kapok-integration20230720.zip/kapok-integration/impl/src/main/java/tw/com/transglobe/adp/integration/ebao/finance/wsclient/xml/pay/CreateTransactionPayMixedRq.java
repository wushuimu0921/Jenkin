//
// ���ɮ׬O�� JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.3.0 �Ҳ���
// �аѾ\ <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a>
// �@�����s�sĶ�ӷ����n, �惡�ɮשҰ�������קﳣ�N�|��.
// ���ͮɶ�: 2022.05.28 �� 10:58:57 AM CST
//

package tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.pay;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.*;

/**
 * <p>
 * createTransactionPayMixedRq complex type �� Java ���O.
 *
 * <p>
 * �U�C���n���q�|���w�����O���]�t���w�����e.
 *
 * <pre>
 * &lt;complexType name="createTransactionPayMixedRq"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="TransPayMixedInfos" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="TransPayMixedInfo" type="{}transactionPayMixedInfo" maxOccurs="unbounded"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createTransactionPayMixedRq", propOrder = {
    "transPayMixedInfos"
})
@XmlRootElement(name = "GlTransPayMixedRq")
public class CreateTransactionPayMixedRq {

  @XmlElement(name = "TransPayMixedInfos")
  protected CreateTransactionPayMixedRq.TransPayMixedInfos transPayMixedInfos;

  /**
   * ���o transPayMixedInfos �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link CreateTransactionPayMixedRq.TransPayMixedInfos }
   *
   */
  public CreateTransactionPayMixedRq.TransPayMixedInfos getTransPayMixedInfos() {
    return transPayMixedInfos;
  }

  /**
   * �]�w transPayMixedInfos �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link CreateTransactionPayMixedRq.TransPayMixedInfos }
   *
   */
  public void setTransPayMixedInfos(CreateTransactionPayMixedRq.TransPayMixedInfos value) {
    this.transPayMixedInfos = value;
  }

  /**
   * <p>
   * anonymous complex type �� Java ���O.
   *
   * <p>
   * �U�C���n���q�|���w�����O���]�t���w�����e.
   *
   * <pre>
   * &lt;complexType&gt;
   *   &lt;complexContent&gt;
   *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
   *       &lt;sequence&gt;
   *         &lt;element name="TransPayMixedInfo" type="{}transactionPayMixedInfo" maxOccurs="unbounded"/&gt;
   *       &lt;/sequence&gt;
   *     &lt;/restriction&gt;
   *   &lt;/complexContent&gt;
   * &lt;/complexType&gt;
   * </pre>
   *
   *
   */
  @XmlAccessorType(XmlAccessType.FIELD)
  @XmlType(name = "", propOrder = {
      "transPayMixedInfo"
  })
  public static class TransPayMixedInfos {

    @XmlElement(name = "TransPayMixedInfo", required = true)
    protected List<TransactionPayMixedInfo> transPayMixedInfo;

    /**
     * Gets the value of the transPayMixedInfo property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the transPayMixedInfo property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     *
     * <pre>
     * getTransPayMixedInfo().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TransactionPayMixedInfo }
     *
     *
     */
    public List<TransactionPayMixedInfo> getTransPayMixedInfo() {
      if (transPayMixedInfo == null) {
        transPayMixedInfo = new ArrayList<TransactionPayMixedInfo>();
      }
      return this.transPayMixedInfo;
    }

  }

}
