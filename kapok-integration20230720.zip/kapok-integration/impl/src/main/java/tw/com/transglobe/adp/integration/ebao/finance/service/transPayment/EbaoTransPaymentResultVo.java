package tw.com.transglobe.adp.integration.ebao.finance.service.transPayment;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EbaoTransPaymentResultVo {

  String resultCode; //回傳代碼
  String resultDesc; //銀行失敗訊息
  String resultEbaoDesc; //易保失敗訊息
  String refId;

}
