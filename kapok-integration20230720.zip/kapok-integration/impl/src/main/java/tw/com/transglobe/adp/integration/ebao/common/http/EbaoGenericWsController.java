package tw.com.transglobe.adp.integration.ebao.common.http;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RestController;
import tw.com.transglobe.adp.integration.ebao.common.http.dto.EbaoCommonRequest;
import tw.com.transglobe.adp.integration.ebao.common.http.dto.EbaoCommonResponse;
import tw.com.transglobe.adp.integration.ebao.common.service.EbaoCommonWsClient;

@RestController
@RequiredArgsConstructor
class EbaoGenericWsController implements EbaoGenericWsApi {
  final EbaoCommonWsClient service;
  final EbaoCommonMapper mapper;

  @Override
  public EbaoCommonResponse commonWs(EbaoCommonRequest request) {
    var vo = service.exchange(mapper.toRequest(request));
    return mapper.toResponse(vo);
  }
}
