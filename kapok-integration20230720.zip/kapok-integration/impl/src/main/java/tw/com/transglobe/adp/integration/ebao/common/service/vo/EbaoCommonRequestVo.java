package tw.com.transglobe.adp.integration.ebao.common.service.vo;

import lombok.Data;

@Data
public class EbaoCommonRequestVo {
  String systemCode;
  String serviceName;
  String rqBody;
}
