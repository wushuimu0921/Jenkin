package tw.com.transglobe.adp.integration.aml.wsclient.xml;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@XmlRootElement(name = "acc")
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
public class AccForXmlDto {

  @XmlElement(name = "CINO")
  String cino;
  @XmlElement(name = "TYPE")
  String type;
  @XmlElement(name = "FIELD")
  List<FieldDto> fieldDto;

}
