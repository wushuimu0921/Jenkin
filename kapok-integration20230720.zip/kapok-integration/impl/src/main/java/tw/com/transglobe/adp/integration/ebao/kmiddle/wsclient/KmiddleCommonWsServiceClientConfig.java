package tw.com.transglobe.adp.integration.ebao.kmiddle.wsclient;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tw.com.transglobe.adp.integration.config.AdpIntegrationProperties;
import tw.com.transglobe.adp.integration.ebao.kmiddle.service.KmiddleCommonWsClient;

@Slf4j
@Configuration
class KmiddleCommonWsServiceClientConfig {

  @Bean
  @ConditionalOnMissingBean
  @ConditionalOnProperty(value = "kmiddle-common-ws-client.enabled", havingValue = "false")
  public KmiddleCommonWsClient kmiddleCommonWsClientOfMock() {
    return new KmiddleCommonWsClientMock();
  }

  @Bean
  @ConditionalOnProperty(value = "kmiddle-common-ws-client.enabled", havingValue = "true")
  public KmiddleCommonWsClient kmiddleCommonWsClient(AdpIntegrationProperties properties, KmiddleMapper mapper) {
    return new KmiddleCommonWsClientImpl(properties, mapper);
  }
}
