package tw.com.transglobe.adp.integration.aml.service;

public class LyodsWebServiceException extends RuntimeException {

  private static final long serialVersionUID = 7596564919439638636L;

  public LyodsWebServiceException(String message, Throwable cause) {
    super(message, cause);
  }

}
