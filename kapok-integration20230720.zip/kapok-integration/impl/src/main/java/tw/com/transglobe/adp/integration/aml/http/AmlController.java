package tw.com.transglobe.adp.integration.aml.http;

import org.springframework.web.bind.annotation.RestController;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import tw.com.transglobe.adp.integration.aml.http.dto.AmlCifResponse;
import tw.com.transglobe.adp.integration.aml.http.query.AmlQueryRequest;
import tw.com.transglobe.adp.integration.aml.service.AmlService;

@Slf4j
@RestController
@RequiredArgsConstructor
class AmlController implements AmlApi {

  final AmlService service;
  final AmlDtoMapper mapper;

  @Override
  public AmlCifResponse checkAml(AmlQueryRequest request) {
    return mapper.fromVo(service.getAml(mapper.toCriteria(request)));
  }
}
