package tw.com.transglobe.adp.integration.ebao.kmiddle.service;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class KmiddleClaimPolicyDataList {

  List<KmiddleClaimPolicyData> claimPolicyData;
}
