package tw.com.transglobe.adp.integration.ebao.finance.http;

import org.mapstruct.*;
import tw.com.transglobe.adp.integration.ebao.finance.service.EbaoCommonResponseVo;
import tw.com.transglobe.adp.integration.ebao.finance.service.chequeInfo.EbaoChequeInfoVo;
import tw.com.transglobe.adp.integration.ebao.finance.service.cmd.*;
import tw.com.transglobe.adp.integration.ebao.finance.service.exchange.EbaoExchangeResponseVo;
import tw.com.transglobe.adp.integration.ebao.finance.service.transPayment.EbaoTransPaymentInfoVo;
import tw.com.transglobe.adp.integration.ebao.finance.service.transPosting.EbaoTransPostingInfoVo;
import tw.com.transglobe.adp.integration.finance.http.dto.EbaoStandardResponse;
import tw.com.transglobe.adp.integration.finance.http.dto.exchangeRs.EbaoExchangeRsDto;
import tw.com.transglobe.adp.integration.finance.http.dto.transPayment.EbaoFinanceQueryChequeDto;
import tw.com.transglobe.adp.integration.finance.http.dto.transPayment.EbaoFinancePaymentResultDto;
import tw.com.transglobe.adp.integration.finance.http.dto.transPosting.EbaoTransPostingResponseDto;
import tw.com.transglobe.adp.integration.finance.http.req.*;

import java.util.List;

@Mapper(nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
interface EbaoFinanceDtoMapper {

  @Mapping(target = "arapSeq", source = "seqNo")
  @Mapping(target = "adpPolNo", source = "policyNo")
  @Mapping(target = "phCertiCode", source = "applicantIdno")
  @Mapping(target = "phCertiType", source = "applicantIdnoType")
  @Mapping(target = "phName", source = "applicantLocalName")
  @Mapping(target = "phNational", source = "applicantNation")
  @Mapping(target = "phPostCode", source = "applicantZipCode")
  @Mapping(target = "internalId", source = "mainCode")
  @Mapping(target = "cashierName", source = "cashierLocalName")
  @Mapping(target = "cashierDeptName", source = "cashierDeptLocalName")
  @Mapping(target = "agentRegisterCode", source = "agentNo")
  @Mapping(target = "prodContract", source = "prodContract")
  EbaoFinanceAparCreateCmd toAparCreateCmd(EbaoFinanceAparRequest aparRequest);

  List<EbaoFinanceAparCreateCmd> toAparCreateCmd(List<EbaoFinanceAparRequest> aparRequest);

  @Mapping(target = "adpPolNo", source = "policyNo")
  @Mapping(target = "phCertiCode", source = "applicantIdno")
  @Mapping(target = "phName", source = "applicantLocalName")
  @Mapping(target = "postTransNo", source = "evidenceVoucherSeqNo")
  @Mapping(target = "cashSeq", source = "seqNo")
  @Mapping(target = "cashierDeptName", source = "cashierDeptLocalName")
  @Mapping(target = "cashierName", source = "cashierLocalName")
  @Mapping(target = "creditCardNum", source = "creditCardNo")
  @Mapping(target = "creditCardAuth", source = "creditCardApproveCode")
  @Mapping(target = "creditCardExpireDate", source = "creditCardExpDate")
  @Mapping(target = "chequeNo", source = "checkNo")
  @Mapping(target = "chequeAmount", source = "checkAmount")
  @Mapping(target = "chequeAccount", source = "checkAccount")
  @Mapping(target = "chequeDueDate", source = "checkDueDate")
  @Mapping(target = "chequeBank", source = "checkBankCode")
  @Mapping(target = "chequePhCertiCode", source = "checkHolderIdno")
  @Mapping(target = "chequePhName", source = "checkHolderLocalName")
  @Mapping(target = "agentRegisterCode", source = "agentNo")
  @Mapping(target = "chequeSource", source = "checkSource")
  @Mapping(target = "chequePhCertiType", source = "checkHolderIdnoType")
  EbaoFinanceCollectCreateCmd toColCreateCmd(EbaoFinanceCollectionRequest request);

  List<EbaoFinanceCollectCreateCmd> toColCreateCmd(List<EbaoFinanceCollectionRequest> colRequest);

  @Mapping(target = "cashSeq", source = "seqNo")
  @Mapping(target = "adpPolNo", source = "policyNo")
  @Mapping(target = "phCertiCode", source = "applicantIdno")
  @Mapping(target = "phCertiType", source = "applicantIdnoType")
  @Mapping(target = "phName", source = "applicantLocalName")
  @Mapping(target = "payeeName", source = "payeeLocalName")
  @Mapping(target = "payeeCertiCode", source = "payeeIdno")
  @Mapping(target = "dueTime", source = "dueDate")
  @Mapping(target = "approveUserName", source = "approverLocalName")
  @Mapping(target = "approveUserJobNo", source = "approverJobNo")
  @Mapping(target = "approveUserDeptCode", source = "approverDeptCode")
  @Mapping(target = "approveUserDeptName", source = "approverDeptName")
  @Mapping(target = "approveUserId", source = "approverId")
  @Mapping(target = "cashierDeptName", source = "cashierDeptLocalName")
  @Mapping(target = "cashierName", source = "cashierLocalName")
  @Mapping(target = "creditCardNum", source = "creditCardNo")
  @Mapping(target = "creditCardAuth", source = "creditCardApproveCode")
  @Mapping(target = "creditCardExpireDate", source = "creditCardExpDate")
  @Mapping(target = "cancelEndorsementIndi", source = "cancelEndorsement")
  @Mapping(target = "cancelScoreIndi", source = "cancelScore")
  @Mapping(target = "chequeSendType", source = "checkSendType")
  @Mapping(target = "agentRegisterCode", source = "agentNo")
  @Mapping(target = "paymentSource", ignore = true)
  EbaoFinancePayCreateCmd toPayCreateCmd(EbaoFinancePaymentRequest request);

  @AfterMapping
  default void afterToPayCreateCmd(EbaoFinancePaymentRequest request,
      @MappingTarget EbaoFinancePayCreateCmd.EbaoFinancePayCreateCmdBuilder cmd) {
    cmd.paymentSource(request.getPaymentSource().getValue());
  }

  List<EbaoFinancePayCreateCmd> toPayCreateCmd(List<EbaoFinancePaymentRequest> request);

  @Mapping(target = "policyCode", source = "policyNo")
  EbaoFinanceGetPaymentCmd toGetPaymentResultCmd(EbaoGetPaymentResultRequest request);

  //  EbaoStandardResponse fromVo(EbaoCommonResponseVo vo);

  EbaoExchangeRsDto fromVo(EbaoExchangeResponseVo vo);

  EbaoFinancePaymentResultDto fromVo(EbaoTransPaymentInfoVo vo);

  EbaoTransPostingResponseDto fromVo(EbaoTransPostingInfoVo vo);

  EbaoFinanceQueryChequeCmd toQueryChequeCmd(EbaoFinanceQueryCheckRequest request);

  EbaoFinanceTransPostingCmd toTransPostingCmd(EbaoFinanceTransPostingRequest request);

  EbaoFinanceQueryChequeDto fromVo(EbaoChequeInfoVo vo);

}
