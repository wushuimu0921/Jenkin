package tw.com.transglobe.adp.integration.aml.wsclient;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tw.com.transglobe.adp.integration.config.AdpIntegrationProperties;
import tw.com.transglobe.adp.integration.aml.service.LyodsWebServiceClient;

@RequiredArgsConstructor
@Configuration
@Slf4j
public class LyodsWebServiceClientConfig {

  @Bean
  @ConditionalOnMissingBean
  @ConditionalOnProperty(value = "lyods-webService-client.enabled", havingValue = "false")
  public LyodsWebServiceClient lyodsWebServiceClientOfMock() {
    log.info("Creating mock lyodsWebServiceClient.");
    return new LyodsWebServiceClientMock();
  }

  @Bean
  @ConditionalOnProperty(value = "lyods-webService-client.enabled", havingValue = "true")
  public LyodsWebServiceClient lyodsWebServiceClient(AdpIntegrationProperties properties) {
    log.info("Creating dev lyodsWebServiceClient.");
    return new LyodsWebServiceClientImpl(properties);
  }
}
