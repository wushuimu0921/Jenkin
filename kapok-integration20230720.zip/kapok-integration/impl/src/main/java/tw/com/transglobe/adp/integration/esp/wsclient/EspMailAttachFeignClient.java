package tw.com.transglobe.adp.integration.esp.wsclient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import tw.com.transglobe.adp.integration.esp.wsclient.request.EspMailAttachFileWsRequest;

@FeignClient(name = "esp-mail", url = "${transglobe.integration.esp-mail-attach.url}")
public interface EspMailAttachFeignClient {

  @PostMapping
  String sendMailAttach(EspMailAttachFileWsRequest request);

}
