package tw.com.transglobe.adp.integration;

import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;
import tw.com.transglobe.framework.core.TransGlobeApplication;
import tw.com.transglobe.framework.core.TransGlobeBootstrap;

@EnableJpaRepositories
@TransGlobeBootstrap
@EnableFeignClients
@EnableScheduling
public class AdpIntegrationApplication {
  public static void main(String[] args) {
    TransGlobeApplication.run(AdpIntegrationApplication.class, args);
  }
}
