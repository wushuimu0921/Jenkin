package tw.com.transglobe.adp.integration.ebao.finance.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tw.com.softleader.data.security.guardium.annotation.Safeguard;
import tw.com.transglobe.adp.integration.ebao.finance.service.chequeInfo.EbaoChequeInfoVo;
import tw.com.transglobe.adp.integration.ebao.finance.service.cmd.EbaoFinanceAparCreateCmd;
import tw.com.transglobe.adp.integration.ebao.finance.service.cmd.EbaoFinanceCollectCreateCmd;
import tw.com.transglobe.adp.integration.ebao.finance.service.cmd.EbaoFinanceGetPaymentCmd;
import tw.com.transglobe.adp.integration.ebao.finance.service.cmd.EbaoFinancePayCreateCmd;
import tw.com.transglobe.adp.integration.ebao.finance.service.cmd.EbaoFinanceQueryChequeCmd;
import tw.com.transglobe.adp.integration.ebao.finance.service.cmd.EbaoFinanceTransPostingCmd;
import tw.com.transglobe.adp.integration.ebao.finance.service.exchange.EbaoExchangeResponseVo;
import tw.com.transglobe.adp.integration.ebao.finance.service.transPayment.EbaoTransPaymentInfoVo;
import tw.com.transglobe.adp.integration.ebao.finance.service.transPosting.EbaoTransPostingInfoVo;

import java.util.List;

@Slf4j
@Transactional
@Service
@RequiredArgsConstructor
@Safeguard
public class EbaoCommonService {

  final EbaoCommonWsClient client;

  final EbaoFinanceVoMapper mapper;

  public EbaoExchangeResponseVo createReceivable(String policyNo,
      List<EbaoFinanceAparCreateCmd> aparCreateCmds, List<EbaoFinanceCollectCreateCmd> colCreateCmds) {
    return client.exchangeReceivable("GL", policyNo, aparCreateCmds, colCreateCmds);

  }

  public EbaoExchangeResponseVo createPayable(String policyNo,
      List<EbaoFinanceAparCreateCmd> aparCreateCmds, List<EbaoFinancePayCreateCmd> paidCreatCmds) {
    return client.exchangePayable("GL", policyNo, aparCreateCmds, paidCreatCmds);
  }

  public EbaoChequeInfoVo getChequeInfo(EbaoFinanceQueryChequeCmd cmd) {
    return client.getChequeInfo("GL", cmd);
  }

  public EbaoTransPaymentInfoVo getPaymentResult(EbaoFinanceGetPaymentCmd cmd) {
    return client.getPaymentResult("GL", cmd);
  }

  public EbaoTransPostingInfoVo getTransPostingInfo(EbaoFinanceTransPostingCmd cmd) {
    return client.getTransPostingInfo("GL", cmd);
  }

}
