package tw.com.transglobe.adp.integration.ebao.rest.wsclient;

import com.google.common.collect.Lists;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Date;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import tw.com.transglobe.adp.integration.ebao.rest.enums.QmlistType;
import tw.com.transglobe.adp.integration.ebao.rest.service.EbaoRestQmlistCriteria;
import tw.com.transglobe.adp.integration.ebao.rest.service.EbaoRestQmlistVo;
import tw.com.transglobe.adp.integration.ebao.rest.service.EbaoRestServiceClient;

@Slf4j
@RequiredArgsConstructor
public class EbaoRestServiceClientImpl implements EbaoRestServiceClient {

  final EbaoRestQmlistFeignClient qmlistClient;

  @Override
  public List<EbaoRestQmlistVo> getQmlist(EbaoRestQmlistCriteria criteria) {
    EbaoRestQmlistRequest request = EbaoRestQmlistRequest.builder()
        .qualityType(criteria.getType().getEbaoCode())
        .certiCode(criteria.getIdno())
        .registerCode(StringUtils.trimToEmpty(criteria.getAgentNo()))
        .source(criteria.getSource())
        .checkDate(criteria.getCheckDate())
        .build();
    log.info("EbaoRestServiceClientImpl getQmlist request:{}", request);
    List<EbaoRestQmlistResponse> responses = qmlistClient.getQmlist(request);
    log.info("EbaoRestServiceClientImpl getQmlist responses:{}", responses);

    return toVoList(responses);
  }

  private Long localDateTimeToDateTime(final LocalDateTime inputTime) {
    Instant instant = inputTime.toInstant(ZoneOffset.UTC);
    Date date = Date.from(instant);
    return date.getTime();
  }

  private List<EbaoRestQmlistVo> toVoList(List<EbaoRestQmlistResponse> responses) {
    List<EbaoRestQmlistVo> voList = Lists.newArrayList();

    if (responses != null) {
      for (EbaoRestQmlistResponse response : responses) {
        log.debug("{}", response);
        EbaoRestQmlistVo vo = new EbaoRestQmlistVo();
        vo.setType(QmlistType.getByEbaoCode(response.getQualityManageType()));
        vo.setIdno(response.getCertiCode());
        vo.setIdnoType(response.getCertiType());
        vo.setAgentNo(response.getRegisterCode());
        vo.setChannelCode(response.getDevCode());
        vo.setChannelName(response.devName);
        vo.setLocalName(response.getName());
        vo.setBirthday(response.getBirthdate());
        vo.setCause(response.getCause());
        vo.setCauseDescription(response.getCauseDesc());
        vo.setSource(response.getSource());
        vo.setSourceDescription(response.getSourceDescs());
        vo.setEffDate(response.getStartDate());
        vo.setExpDate(response.getEndDate());
        vo.setRemark(response.getMeno());
        vo.setSourceListId(response.sourceListId);
        voList.add(vo);
      }
    }
    return voList;
  }

}
