package tw.com.transglobe.adp.integration.esp.http;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RestController;
import tw.com.transglobe.adp.integration.esp.http.req.EspMailAttachFileRequest;
import tw.com.transglobe.adp.integration.esp.http.req.EspMailRequest;
import tw.com.transglobe.adp.integration.esp.service.EspMailService;

@Slf4j
@RestController
@RequiredArgsConstructor
class EspMailController implements EspMailApi {

  final EspMailService service;
  final EspMailDtoMapper mapper;

  @Override
  public String sendMailWithAttachFile(EspMailAttachFileRequest request) {
    return service.sendMailAttach(mapper.toAttachCmd(request));
  }

  @Override
  public String sendMail(EspMailRequest request) {
    return service.sendMail(mapper.toCmd(request));
  }

}
