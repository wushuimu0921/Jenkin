package tw.com.transglobe.adp.integration.ebao.kmiddle.http;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RestController;
import tw.com.transglobe.adp.integration.claim.http.dto.EbaoClaimQueryDto;
import tw.com.transglobe.adp.integration.commons.enums.ProductGroupType;
import tw.com.transglobe.adp.integration.ebao.kmiddle.service.KmiddleCommonService;
import tw.com.transglobe.adp.integration.kmiddle.http.KmiddleCommonWsApi;
import tw.com.transglobe.adp.integration.kmiddle.http.dto.KmiddlePolicyDto;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
class KmiddleCommonWsController implements KmiddleCommonWsApi {

  final KmiddleCommonService service;

  final KmiddleCommonWsMapper mapper;

  @Override
  public EbaoClaimQueryDto queryClaimByIdno(ProductGroupType productGroupType, String idno) {
    return mapper.fromVo(service.queryClaim(productGroupType, "1", idno).getClaimDataList());
  }

  @Override
  public EbaoClaimQueryDto queryClaimByPolicyNo(ProductGroupType productGroupType, String policyNo) {
    if (ProductGroupType.GI == productGroupType) {
      return mapper.fromVo(service.queryClaim(ProductGroupType.CSIS, "2", policyNo).getClaimDataList());
    } else if (ProductGroupType.TA == productGroupType) {
      // deal with null
      var kmiddleClaimVo = service.queryClaim(ProductGroupType.CSIS, "3", policyNo);
      if (kmiddleClaimVo != null) {
        return mapper.fromVo(kmiddleClaimVo.getClaimDataList());
      }
      throw new IllegalArgumentException("Some Error happened when calling Kmiddle WS");
    } else {
      throw new IllegalArgumentException("ProductGroupType Not Found");
    }
  }

  @Override
  public List<KmiddlePolicyDto> queryPolicyByIdno(ProductGroupType productGroupType, String idno) {
    return mapper.fromPolicyVo(service.queryPolicy(productGroupType, idno));
  }

}
