package tw.com.transglobe.adp.integration.ebao.kmiddle.service;

import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import tw.com.softleader.data.security.guardium.annotation.Safeguard;
import tw.com.transglobe.adp.integration.commons.enums.ProductGroupType;

@Slf4j
@Transactional
@Service
@RequiredArgsConstructor
@Safeguard
public class KmiddleCommonService {

  final KmiddleCommonWsClient client;

  public KmiddleClaimVo queryClaim(ProductGroupType productGroupType, String type, String data) {
    return client.cmn130(productGroupType, type, data);
  }

  public List<KmiddlePolicyVo> queryPolicy(ProductGroupType productGroupType, String idno) {
    return client.cmn150(productGroupType, idno);
  }
}
