package tw.com.transglobe.adp.integration.esp.wsclient.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import tw.com.transglobe.adp.integration.config.AdpIntegrationProperties;
import tw.com.transglobe.adp.integration.esp.service.cmd.EspSmsMessageCmd;
import tw.com.transglobe.adp.integration.esp.service.client.EspSmsMessageWebServiceClient;

@Slf4j
@RequiredArgsConstructor
public class EspSmsMessageWebServiceClientMock implements EspSmsMessageWebServiceClient {

  final AdpIntegrationProperties properties;

  @Override
  public String sendSmsMessage(EspSmsMessageCmd cmd) {
    log.info("Mock sendMessage, phone:{}, message:{}, url:{}", cmd.getDestPhoneNo(), cmd.getMsgData(),
        properties.getEspSmsMessage().getUrl());
    return "0000";
  }
}
