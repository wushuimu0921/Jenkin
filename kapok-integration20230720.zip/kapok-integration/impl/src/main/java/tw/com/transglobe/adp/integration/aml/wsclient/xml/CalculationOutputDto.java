package tw.com.transglobe.adp.integration.aml.wsclient.xml;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
@XmlRootElement(name = "CalculationOutput")
@JsonIgnoreProperties(ignoreUnknown = true)
public class CalculationOutputDto {
  @XmlElement(name = "Firco")
  private FircoDto fircoDto;

}
