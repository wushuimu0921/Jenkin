package tw.com.transglobe.adp.integration.ebao.policy.service;

import lombok.Builder;
import lombok.Data;
import java.time.LocalDate;

@Data
@Builder
public class EbaoPolicyCommonVo {
  String policyNo;
  String localName;
  LocalDate birthday;
}
