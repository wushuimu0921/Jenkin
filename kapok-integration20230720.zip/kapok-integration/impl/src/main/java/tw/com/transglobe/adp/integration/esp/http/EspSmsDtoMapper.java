package tw.com.transglobe.adp.integration.esp.http;

import org.mapstruct.Mapper;
import tw.com.transglobe.adp.integration.esp.http.req.EspSmsMessageRequest;
import tw.com.transglobe.adp.integration.esp.service.cmd.EspSmsMessageCmd;

@Mapper
interface EspSmsDtoMapper {

  EspSmsMessageCmd toCmd(EspSmsMessageRequest request);

}
