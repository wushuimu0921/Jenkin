package tw.com.transglobe.adp.integration.ebao.claim.service;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
@Builder
public class ClaimStatusCmd {

  String policySource;

  String caseNo;

  LocalDate acceptTime;

  String certCode;

  String accidentName;

  LocalDate accidentBirthday;

  LocalDate accidentTime;

  LocalDate approveTime;

  String auditorId;

  String auditorName;

  String auditorOrgan;

  String auditorTel;

  String auditorExt;

  String auditorEmail;

  String caseStatusCode;

  String caseStatusDesc;

  String isSurvey;

  String generalComm;

  String rptrNo;

  String rptrName;

  List<DiagnosisCmd> diagnosisList;

  List<MedicalBillCmd> medicalBillList;

  List<PolicyDataCmd> policyDataList;

  String checkFlag;

  Integer claimType;

  Integer claimNature;
}
