package tw.com.transglobe.adp.integration.ebao.kmiddle.http;

import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;
import tw.com.transglobe.adp.integration.claim.http.dto.EbaoClaimDiagnosisDto;
import tw.com.transglobe.adp.integration.claim.http.dto.EbaoClaimMedicalBillDto;
import tw.com.transglobe.adp.integration.claim.http.dto.EbaoClaimPolicyDataDto;
import tw.com.transglobe.adp.integration.claim.http.dto.EbaoClaimProductDataDto;
import tw.com.transglobe.adp.integration.claim.http.dto.EbaoClaimQueryDto;
import tw.com.transglobe.adp.integration.claim.http.dto.EbaoClaimStatusDto;
import tw.com.transglobe.adp.integration.ebao.kmiddle.service.KmiddleClaimBillData;
import tw.com.transglobe.adp.integration.ebao.kmiddle.service.KmiddleClaimData;
import tw.com.transglobe.adp.integration.ebao.kmiddle.service.KmiddleClaimDataList;
import tw.com.transglobe.adp.integration.ebao.kmiddle.service.KmiddleClaimPolicyData;
import tw.com.transglobe.adp.integration.ebao.kmiddle.service.KmiddlePolicyVo;
import tw.com.transglobe.adp.integration.kmiddle.http.dto.KmiddlePolicyDto;

@Mapper(nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
interface KmiddleCommonWsMapper {

  Logger log = LoggerFactory.getLogger(KmiddleCommonWsMapper.class.getName());

  EbaoClaimQueryDto fromVo(KmiddleClaimDataList vo);

  @AfterMapping
  default void extractFromVo(KmiddleClaimDataList vo, @MappingTarget EbaoClaimQueryDto.EbaoClaimQueryDtoBuilder dto) {
    log.info("vo:{}", vo);
    log.info("dto:{}", dto);
    dto.claimStatusList(fromVos(vo.getClaimData()));
    log.info("after vo:{}", vo);
    log.info("after dto:{}", dto);
  }

  @Mapping(target = "certCode", source = "insuredId")
  @Mapping(target = "accidentName", source = "insuredName")
  @Mapping(target = "accidentTime", source = "accidentDate")
  @Mapping(target = "approveTime", source = "approveDate")
  @Mapping(target = "caseStatusDesc", source = "status")
  @Mapping(target = "generalComm", source = "remark")
  @Mapping(target = "medicalBillList", source = "claimBillDataList.claimBillData")
  @Mapping(target = "policyDataList", source = "claimPolicyDataList.claimPolicyData")
  EbaoClaimStatusDto fromVo(KmiddleClaimData vo);

  List<EbaoClaimStatusDto> fromVos(List<KmiddleClaimData> vos);

  @AfterMapping
  default void afterFromVo(KmiddleClaimData vo, @MappingTarget EbaoClaimStatusDto dto) {
    // Kmiddle來源的給"K"
    dto.setPolicySource("K");
    // K的調查list有資料 -> isServey = "Y"
    if (vo.getClaimSurgeryDataList() != null && !CollectionUtils.isEmpty(vo.getClaimSurgeryDataList().getClaimSurgeryData())
        && !StringUtils.isBlank(vo.getClaimSurgeryDataList().getClaimSurgeryData().get(0).getSurgeryNo())) {
      dto.setIsSurvey("Y");
    }
    // target = "diagnosisList[0].diagnosisName", source = "diagnosisName"
    var diag = new EbaoClaimDiagnosisDto();
    diag.setDiagnosisName(vo.getDiagnosisName());
    dto.setDiagnosisList(List.of(diag));
    // target = "medicalBillList", source = "claimBillDataList.claimBillData"
    //    if (vo.getClaimBillDataList() != null && !CollectionUtils.isEmpty(vo.getClaimBillDataList().getClaimBillData())) {
    //      dto.setMedicalBillList(billFromVos(vo.getClaimBillDataList().getClaimBillData()));
    //    }
    // target = "productDataList[0].internalId", source = "publicCode"
    if (vo.getClaimPolicyDataList() != null && !CollectionUtils.isEmpty(vo.getClaimPolicyDataList().getClaimPolicyData())
        && !StringUtils.isBlank(vo.getClaimPolicyDataList().getClaimPolicyData().get(0).getPublicCode())) {
      dto.setIsSurvey("Y");
    }
  }

  @Mapping(target = "billStartDate", source = "startDate")
  @Mapping(target = "billEndDate", source = "endDate")
  EbaoClaimMedicalBillDto billFromVo(KmiddleClaimBillData vo);

  List<EbaoClaimMedicalBillDto> billFromVos(List<KmiddleClaimBillData> vos);

  @Mapping(target = "relation", source = "insuredRelation")
  @Mapping(target = "policyPayAmount", source = "payAmount")
  EbaoClaimPolicyDataDto policyFromVo(KmiddleClaimPolicyData vo);

  List<EbaoClaimPolicyDataDto> policyFromVos(List<KmiddleClaimPolicyData> vos);

  @AfterMapping
  default void afterPolicyFromVo(KmiddleClaimPolicyData vo,
      @MappingTarget EbaoClaimPolicyDataDto.EbaoClaimPolicyDataDtoBuilder dto) {
    // target = "productDataList[0].internalId", source = "publicCode"
    if (!StringUtils.isBlank(vo.getPublicCode())) {
      dto.productDataList(
          List.of(EbaoClaimProductDataDto.builder().internalId(vo.getPublicCode()).payAmount(vo.getPayAmount()).build()));
    }
  }

  List<KmiddlePolicyDto> fromPolicyVo(List<KmiddlePolicyVo> vos);

}
