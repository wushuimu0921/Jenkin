package tw.com.transglobe.adp.integration.ebao.claim.http;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RestController;
import tw.com.transglobe.adp.integration.claim.http.EbaoClaimCommonWsApi;
import tw.com.transglobe.adp.integration.claim.http.dto.EbaoClaimQueryDto;
import tw.com.transglobe.adp.integration.claim.http.dto.EbaoClaimQueryRequest;
import tw.com.transglobe.adp.integration.commons.enums.ProductGroupType;
import tw.com.transglobe.adp.integration.ebao.claim.service.EbaoClaimCommonService;

@Slf4j
@RestController
@RequiredArgsConstructor
class EbaoClaimCommonWsController implements EbaoClaimCommonWsApi {

  final EbaoClaimCommonService service;

  final EbaoClaimCommonWsMapper mapper;

  @Override
  public EbaoClaimQueryDto queryClaim(ProductGroupType productGroupType, EbaoClaimQueryRequest request) {

    if (ProductGroupType.GI == productGroupType || ProductGroupType.TA == productGroupType) {
      productGroupType = ProductGroupType.CSIS;

      return mapper.fromVo(service.queryClaim(productGroupType, mapper.fromRequest(request)));
    } else {
      throw new IllegalArgumentException("ProductGroupType Not Found");
    }
  }
}
