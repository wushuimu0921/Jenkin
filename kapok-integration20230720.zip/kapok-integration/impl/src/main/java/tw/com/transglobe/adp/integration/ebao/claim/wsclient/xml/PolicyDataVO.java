package tw.com.transglobe.adp.integration.ebao.claim.wsclient.xml;

import lombok.Getter;
import lombok.Setter;

import javax.xml.bind.annotation.*;
import java.math.BigDecimal;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "policyDataVO")
@Getter
@Setter
public class PolicyDataVO {

  @XmlElement(required = true)
  protected String policyCode;

  @XmlElement(required = true)
  protected String policyAddress;

  @XmlElement(required = true)
  protected String relation;

  @XmlElement(required = true)
  protected BigDecimal policyPayAmount;

  @XmlElementWrapper(name = "ProductDataList")
  @XmlElement(required = true, name = "ProductData")
  protected List<ProductDataVO> productDataList;

}
