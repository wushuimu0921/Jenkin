package tw.com.transglobe.adp.integration.ebao.finance.service.chequeInfo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EbaoChequeInfoVo {

  List<EbaoChequeVo> cheques;

}
