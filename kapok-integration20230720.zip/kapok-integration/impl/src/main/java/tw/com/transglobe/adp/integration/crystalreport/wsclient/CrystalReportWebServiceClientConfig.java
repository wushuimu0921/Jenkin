package tw.com.transglobe.adp.integration.crystalreport.wsclient;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tw.com.transglobe.adp.integration.config.AdpIntegrationProperties;
import tw.com.transglobe.adp.integration.crystalreport.service.CrystalReportWebServiceClient;

@RequiredArgsConstructor
@Configuration
@Slf4j
class CrystalReportWebServiceClientConfig {

  @Bean
  @ConditionalOnMissingBean
  @ConditionalOnProperty(value = "crystal-report-webService-client.enabled", havingValue = "false")
  public CrystalReportWebServiceClient crystalReportWebServiceClientOfMock() {
    log.info("Creating mock crystalReportWebServiceClient.");
    return new CrystalReportWebServiceClientMock();
  }

  @Bean
  @ConditionalOnProperty(value = "crystal-report-webService-client.enabled", havingValue = "true")
  public CrystalReportWebServiceClient crystalReportWebServiceClient(CrystalReportFeignClient client,
      AdpIntegrationProperties properties) {
    log.info("Creating dev crystalReportWebServiceClient.");
    return new CrystalReportWebServiceClientImpl(client, properties);
  }
}
