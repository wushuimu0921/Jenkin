//
// ���ɮ׬O�� JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.3.0 �Ҳ���
// �аѾ\ <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a>
// �@�����s�sĶ�ӷ����n, �惡�ɮשҰ�������קﳣ�N�|��.
// ���ͮɶ�: 2022.05.28 �� 10:58:49 AM CST
//

package tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.col;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import tw.com.transglobe.adp.integration.ebao.common.wsclient.SlashLocalDateAdapter;
import tw.com.transglobe.adp.integration.ebao.common.wsclient.SlashLocalDateTimeAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "collectionInfo", propOrder = {
    "dataDate",
    "cashSeq",
    "systemId",
    "subSystemId",
    "businessTypeId",
    "refId",
    "adpPolNo",
    "adpNonPolicyCode",
    "divideIndi",
    "phCertiCode",
    "phName",
    "feeType",
    "payMode",
    "paySource",
    "moneyId",
    "feeAmount",
    "payMoneyId",
    "payAmount",
    "exchangeDate",
    "exchangeRate",
    "checkEnterTime",
    "finishTime",
    "cashierDeptCode",
    "cashierDeptName",
    "cashierId",
    "cashierName",
    "cashierJobNo",
    "cashierTime",
    "agentChannelType",
    "agentChannelCode",
    "agentRegisterCode",
    "internalAccount",
    "voucherNo",
    "voucherDate",
    "voucherAmount",
    "postTransNo",
    "creditCardNum",
    "creditCardAuth",
    "creditCardExpireDate",
    "creditCardAcquirerId",
    "chequeNo",
    "chequeSource",
    "chequeAmount",
    "chequeBank",
    "chequeAccount",
    "chequeDueDate",
    "chequePhCertiCode",
    "chequePhCertiType",
    "chequePhName",
    "accountingDate",
    "productCategory",
    "agentChannelName",
    "agentChannelTypeCode",
    "overPaymentType",
    "overPaymentAmount",
    "relatedId",
    "validateDate"
})
public class CollectionInfo {

  @XmlElement(name = "DataDate", required = true)
  @XmlJavaTypeAdapter(SlashLocalDateTimeAdapter.class)
  protected LocalDateTime dataDate;

  @XmlElement(name = "CashSeq")
  protected int cashSeq;
  @XmlElement(name = "SystemId")
  protected int systemId;
  @XmlElement(name = "SubSystemId")
  protected int subSystemId;
  @XmlElement(name = "BusinessTypeId")
  protected int businessTypeId;
  @XmlElement(name = "RefId", required = true)
  protected String refId;
  @XmlElement(name = "AdpPolNo")
  protected String adpPolNo;
  @XmlElement(name = "AdpNonPolicyCode")
  protected String adpNonPolicyCode;
  @XmlElement(name = "DivideIndi")
  protected String divideIndi;
  @XmlElement(name = "PhCertiCode")
  protected String phCertiCode;
  @XmlElement(name = "PhName")
  protected String phName;
  @XmlElement(name = "FeeType")
  protected int feeType;
  @XmlElement(name = "PayMode")
  protected int payMode;
  @XmlElement(name = "PaySource")
  protected Integer paySource;
  @XmlElement(name = "MoneyId")
  protected int moneyId;
  @XmlElement(name = "FeeAmount", required = true)
  protected BigDecimal feeAmount;
  @XmlElement(name = "PayMoneyId")
  protected int payMoneyId;
  @XmlElement(name = "PayAmount", required = true)
  protected BigDecimal payAmount;

  @XmlElement(name = "ExchangeDate")
  @XmlJavaTypeAdapter(SlashLocalDateAdapter.class)
  protected LocalDate exchangeDate;

  @XmlElement(name = "ExchangeRate")
  protected BigDecimal exchangeRate;

  @XmlElement(name = "CheckEnterTime", required = true)
  @XmlJavaTypeAdapter(SlashLocalDateAdapter.class)
  protected LocalDate checkEnterTime;

  @XmlElement(name = "FinishTime", required = true)
  @XmlJavaTypeAdapter(SlashLocalDateAdapter.class)
  protected LocalDate finishTime;

  @XmlElement(name = "CashierDeptCode", required = true)
  protected String cashierDeptCode;
  @XmlElement(name = "CashierDeptName", required = true)
  protected String cashierDeptName;
  @XmlElement(name = "CashierId")
  protected String cashierId;
  @XmlElement(name = "CashierName", required = true)
  protected String cashierName;

  @XmlElement(name = "CashierJobNo", required = true)
  protected String cashierJobNo;

  @XmlElement(name = "CashierTime", required = true)
  @XmlJavaTypeAdapter(SlashLocalDateTimeAdapter.class)
  LocalDateTime cashierTime;

  @XmlElement(name = "AgentChannelType")
  protected Long agentChannelType;
  @XmlElement(name = "AgentChannelCode")
  protected String agentChannelCode;
  @XmlElement(name = "AgentRegisterCode")
  protected String agentRegisterCode;
  @XmlElement(name = "InternalAccount")
  protected Long internalAccount;
  @XmlElement(name = "VoucherNo")
  protected String voucherNo;

  @XmlElement(name = "VoucherDate")
  @XmlJavaTypeAdapter(SlashLocalDateAdapter.class)
  protected LocalDate voucherDate;

  @XmlElement(name = "VoucherAmount")
  protected BigDecimal voucherAmount;
  @XmlElement(name = "PostTransNo")
  protected String postTransNo;
  @XmlElement(name = "CreditCardNum")
  protected String creditCardNum;
  @XmlElement(name = "CreditCardAuth")
  protected String creditCardAuth;

  @XmlElement(name = "CreditCardExpireDate")
  @XmlJavaTypeAdapter(SlashLocalDateAdapter.class)
  protected LocalDate creditCardExpireDate;

  @XmlElement(name = "CreditCardAcquirerId")
  protected Long creditCardAcquirerId;
  @XmlElement(name = "ChequeNo")
  protected String chequeNo;
  @XmlElement(name = "ChequeSource")
  protected Integer chequeSource;
  @XmlElement(name = "ChequeAmount")
  protected BigDecimal chequeAmount;
  @XmlElement(name = "ChequeBank")
  protected String chequeBank;
  @XmlElement(name = "ChequeAccount")
  protected String chequeAccount;
  @XmlElement(name = "ChequeDueDate")
  protected String chequeDueDate;
  @XmlElement(name = "ChequePhCertiCode")
  protected String chequePhCertiCode;
  @XmlElement(name = "ChequePhCertiType")
  protected String chequePhCertiType;
  @XmlElement(name = "ChequePhName")
  protected String chequePhName;

  @XmlElement(name = "AccountingDate", required = true)
  @XmlJavaTypeAdapter(SlashLocalDateAdapter.class)
  protected LocalDate accountingDate;

  @XmlElement(name = "ProductCategory")
  protected String productCategory;
  @XmlElement(name = "AgentChannelName")
  protected String agentChannelName;
  @XmlElement(name = "AgentChannelTypeCode")
  protected String agentChannelTypeCode;

  @XmlElement(name = "OverPaymentType")
  protected int overPaymentType;
  @XmlElement(name = "OverPaymentAmount")
  protected BigDecimal overPaymentAmount;
  @XmlElement(name = "RelatedId")
  protected Long relatedId;

  @XmlElement(name = "ValidateDate", required = true)
  @XmlJavaTypeAdapter(SlashLocalDateAdapter.class)
  protected LocalDate validateDate;

  /**
   * ���o dataDate �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public LocalDateTime getDataDate() {
    return dataDate;
  }

  /**
   * �]�w dataDate �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setDataDate(LocalDateTime value) {
    this.dataDate = value;
  }

  /**
   * ���o cashSeq �S�ʪ���.
   *
   */
  public int getCashSeq() {
    return cashSeq;
  }

  /**
   * �]�w cashSeq �S�ʪ���.
   *
   */
  public void setCashSeq(int value) {
    this.cashSeq = value;
  }

  /**
   * ���o systemId �S�ʪ���.
   *
   */
  public int getSystemId() {
    return systemId;
  }

  /**
   * �]�w systemId �S�ʪ���.
   *
   */
  public void setSystemId(int value) {
    this.systemId = value;
  }

  /**
   * ���o subSystemId �S�ʪ���.
   *
   */
  public int getSubSystemId() {
    return subSystemId;
  }

  /**
   * �]�w subSystemId �S�ʪ���.
   *
   */
  public void setSubSystemId(int value) {
    this.subSystemId = value;
  }

  /**
   * ���o businessTypeId �S�ʪ���.
   *
   */
  public int getBusinessTypeId() {
    return businessTypeId;
  }

  /**
   * �]�w businessTypeId �S�ʪ���.
   *
   */
  public void setBusinessTypeId(int value) {
    this.businessTypeId = value;
  }

  /**
   * ���o refId �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getRefId() {
    return refId;
  }

  /**
   * �]�w refId �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setRefId(String value) {
    this.refId = value;
  }

  /**
   * ���o adpPolNo �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getAdpPolNo() {
    return adpPolNo;
  }

  /**
   * �]�w adpPolNo �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setAdpPolNo(String value) {
    this.adpPolNo = value;
  }

  /**
   * ���o adpNonPolicyCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getAdpNonPolicyCode() {
    return adpNonPolicyCode;
  }

  /**
   * �]�w adpNonPolicyCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setAdpNonPolicyCode(String value) {
    this.adpNonPolicyCode = value;
  }

  /**
   * ���o divideIndi �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getDivideIndi() {
    return divideIndi;
  }

  /**
   * �]�w divideIndi �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setDivideIndi(String value) {
    this.divideIndi = value;
  }

  /**
   * ���o phCertiCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getPhCertiCode() {
    return phCertiCode;
  }

  /**
   * �]�w phCertiCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setPhCertiCode(String value) {
    this.phCertiCode = value;
  }

  /**
   * ���o phName �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getPhName() {
    return phName;
  }

  /**
   * �]�w phName �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setPhName(String value) {
    this.phName = value;
  }

  /**
   * ���o feeType �S�ʪ���.
   *
   */
  public int getFeeType() {
    return feeType;
  }

  /**
   * �]�w feeType �S�ʪ���.
   *
   */
  public void setFeeType(int value) {
    this.feeType = value;
  }

  /**
   * ���o payMode �S�ʪ���.
   *
   */
  public int getPayMode() {
    return payMode;
  }

  /**
   * �]�w payMode �S�ʪ���.
   *
   */
  public void setPayMode(int value) {
    this.payMode = value;
  }

  /**
   * ���o paySource �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link Integer }
   *
   */
  public Integer getPaySource() {
    return paySource;
  }

  /**
   * �]�w paySource �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link Integer }
   *
   */
  public void setPaySource(Integer value) {
    this.paySource = value;
  }

  /**
   * ���o moneyId �S�ʪ���.
   *
   */
  public int getMoneyId() {
    return moneyId;
  }

  /**
   * �]�w moneyId �S�ʪ���.
   *
   */
  public void setMoneyId(int value) {
    this.moneyId = value;
  }

  /**
   * ���o feeAmount �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link BigDecimal }
   *
   */
  public BigDecimal getFeeAmount() {
    return feeAmount;
  }

  /**
   * �]�w feeAmount �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link BigDecimal }
   *
   */
  public void setFeeAmount(BigDecimal value) {
    this.feeAmount = value;
  }

  /**
   * ���o payMoneyId �S�ʪ���.
   *
   */
  public int getPayMoneyId() {
    return payMoneyId;
  }

  /**
   * �]�w payMoneyId �S�ʪ���.
   *
   */
  public void setPayMoneyId(int value) {
    this.payMoneyId = value;
  }

  /**
   * ���o payAmount �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link BigDecimal }
   *
   */
  public BigDecimal getPayAmount() {
    return payAmount;
  }

  /**
   * �]�w payAmount �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link BigDecimal }
   *
   */
  public void setPayAmount(BigDecimal value) {
    this.payAmount = value;
  }

  /**
   * ���o exchangeDate �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public LocalDate getExchangeDate() {
    return exchangeDate;
  }

  /**
   * �]�w exchangeDate �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setExchangeDate(LocalDate value) {
    this.exchangeDate = value;
  }

  /**
   * ���o exchangeRate �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link BigDecimal }
   *
   */
  public BigDecimal getExchangeRate() {
    return exchangeRate;
  }

  /**
   * �]�w exchangeRate �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link BigDecimal }
   *
   */
  public void setExchangeRate(BigDecimal value) {
    this.exchangeRate = value;
  }

  /**
   * ���o checkEnterTime �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public LocalDate getCheckEnterTime() {
    return checkEnterTime;
  }

  /**
   * �]�w checkEnterTime �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCheckEnterTime(LocalDate value) {
    this.checkEnterTime = value;
  }

  /**
   * ���o finishTime �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public LocalDate getFinishTime() {
    return finishTime;
  }

  /**
   * �]�w finishTime �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setFinishTime(LocalDate value) {
    this.finishTime = value;
  }

  /**
   * ���o cashierDeptCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getCashierDeptCode() {
    return cashierDeptCode;
  }

  /**
   * �]�w cashierDeptCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCashierDeptCode(String value) {
    this.cashierDeptCode = value;
  }

  /**
   * ���o cashierDeptName �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getCashierDeptName() {
    return cashierDeptName;
  }

  /**
   * �]�w cashierDeptName �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCashierDeptName(String value) {
    this.cashierDeptName = value;
  }

  /**
   * ���o cashierId �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getCashierId() {
    return cashierId;
  }

  /**
   * �]�w cashierId �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCashierId(String value) {
    this.cashierId = value;
  }

  /**
   * ���o cashierName �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getCashierName() {
    return cashierName;
  }

  /**
   * �]�w cashierName �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCashierName(String value) {
    this.cashierName = value;
  }

  /**
   * ���o agentChannelType �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link Long }
   *
   */
  public Long getAgentChannelType() {
    return agentChannelType;
  }

  /**
   * �]�w agentChannelType �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link Long }
   *
   */
  public void setAgentChannelType(Long value) {
    this.agentChannelType = value;
  }

  /**
   * ���o agentChannelCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getAgentChannelCode() {
    return agentChannelCode;
  }

  /**
   * �]�w agentChannelCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setAgentChannelCode(String value) {
    this.agentChannelCode = value;
  }

  /**
   * ���o agentRegisterCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getAgentRegisterCode() {
    return agentRegisterCode;
  }

  /**
   * �]�w agentRegisterCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setAgentRegisterCode(String value) {
    this.agentRegisterCode = value;
  }

  /**
   * ���o internalAccount �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link Long }
   *
   */
  public Long getInternalAccount() {
    return internalAccount;
  }

  /**
   * �]�w internalAccount �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link Long }
   *
   */
  public void setInternalAccount(Long value) {
    this.internalAccount = value;
  }

  /**
   * ���o voucherNo �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getVoucherNo() {
    return voucherNo;
  }

  /**
   * �]�w voucherNo �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setVoucherNo(String value) {
    this.voucherNo = value;
  }

  /**
   * ���o voucherDate �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public LocalDate getVoucherDate() {
    return voucherDate;
  }

  /**
   * �]�w voucherDate �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setVoucherDate(LocalDate value) {
    this.voucherDate = value;
  }

  /**
   * ���o voucherAmount �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link BigDecimal }
   *
   */
  public BigDecimal getVoucherAmount() {
    return voucherAmount;
  }

  /**
   * �]�w voucherAmount �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link BigDecimal }
   *
   */
  public void setVoucherAmount(BigDecimal value) {
    this.voucherAmount = value;
  }

  /**
   * ���o postTransNo �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getPostTransNo() {
    return postTransNo;
  }

  /**
   * �]�w postTransNo �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setPostTransNo(String value) {
    this.postTransNo = value;
  }

  /**
   * ���o creditCardNum �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getCreditCardNum() {
    return creditCardNum;
  }

  /**
   * �]�w creditCardNum �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCreditCardNum(String value) {
    this.creditCardNum = value;
  }

  /**
   * ���o creditCardAuth �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getCreditCardAuth() {
    return creditCardAuth;
  }

  /**
   * �]�w creditCardAuth �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCreditCardAuth(String value) {
    this.creditCardAuth = value;
  }

  /**
   * ���o creditCardExpireDate �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public LocalDate getCreditCardExpireDate() {
    return creditCardExpireDate;
  }

  /**
   * �]�w creditCardExpireDate �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCreditCardExpireDate(LocalDate value) {
    this.creditCardExpireDate = value;
  }

  /**
   * ���o creditCardAcquirerId �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link Long }
   *
   */
  public Long getCreditCardAcquirerId() {
    return creditCardAcquirerId;
  }

  /**
   * �]�w creditCardAcquirerId �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link Long }
   *
   */
  public void setCreditCardAcquirerId(Long value) {
    this.creditCardAcquirerId = value;
  }

  /**
   * ���o chequeNo �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getChequeNo() {
    return chequeNo;
  }

  /**
   * �]�w chequeNo �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setChequeNo(String value) {
    this.chequeNo = value;
  }

  /**
   * ���o chequeSource �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link Integer }
   *
   */
  public Integer getChequeSource() {
    return chequeSource;
  }

  /**
   * �]�w chequeSource �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link Integer }
   *
   */
  public void setChequeSource(Integer value) {
    this.chequeSource = value;
  }

  /**
   * ���o chequeAmount �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link BigDecimal }
   *
   */
  public BigDecimal getChequeAmount() {
    return chequeAmount;
  }

  /**
   * �]�w chequeAmount �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link BigDecimal }
   *
   */
  public void setChequeAmount(BigDecimal value) {
    this.chequeAmount = value;
  }

  /**
   * ���o chequeBank �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getChequeBank() {
    return chequeBank;
  }

  /**
   * �]�w chequeBank �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setChequeBank(String value) {
    this.chequeBank = value;
  }

  /**
   * ���o chequeAccount �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getChequeAccount() {
    return chequeAccount;
  }

  /**
   * �]�w chequeAccount �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setChequeAccount(String value) {
    this.chequeAccount = value;
  }

  /**
   * ���o chequeDueDate �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getChequeDueDate() {
    return chequeDueDate;
  }

  /**
   * �]�w chequeDueDate �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setChequeDueDate(String value) {
    this.chequeDueDate = value;
  }

  /**
   * ���o chequePhCertiCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getChequePhCertiCode() {
    return chequePhCertiCode;
  }

  /**
   * �]�w chequePhCertiCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setChequePhCertiCode(String value) {
    this.chequePhCertiCode = value;
  }

  /**
   * ���o chequePhCertiType �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getChequePhCertiType() {
    return chequePhCertiType;
  }

  /**
   * �]�w chequePhCertiType �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setChequePhCertiType(String value) {
    this.chequePhCertiType = value;
  }

  /**
   * ���o chequePhName �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getChequePhName() {
    return chequePhName;
  }

  /**
   * �]�w chequePhName �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setChequePhName(String value) {
    this.chequePhName = value;
  }

  /**
   * ���o accountingDate �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public LocalDate getAccountingDate() {
    return accountingDate;
  }

  /**
   * �]�w accountingDate �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setAccountingDate(LocalDate value) {
    this.accountingDate = value;
  }

  /**
   * ���o productCategory �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getProductCategory() {
    return productCategory;
  }

  /**
   * �]�w productCategory �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setProductCategory(String value) {
    this.productCategory = value;
  }

  /**
   * ���o agentChannelName �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getAgentChannelName() {
    return agentChannelName;
  }

  /**
   * �]�w agentChannelName �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setAgentChannelName(String value) {
    this.agentChannelName = value;
  }

  /**
   * ���o agentChannelTypeCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getAgentChannelTypeCode() {
    return agentChannelTypeCode;
  }

  /**
   * �]�w agentChannelTypeCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setAgentChannelTypeCode(String value) {
    this.agentChannelTypeCode = value;
  }

  public String getCashierJobNo() {
    return cashierJobNo;
  }

  public void setCashierJobNo(String cashierJobNo) {
    this.cashierJobNo = cashierJobNo;
  }

  public LocalDateTime getCashierTime() {
    return cashierTime;
  }

  public void setCashierTime(LocalDateTime cashierTime) {
    this.cashierTime = cashierTime;
  }

  public int getOverPaymentType() {
    return overPaymentType;
  }

  public void setOverPaymentType(int overPaymentType) {
    this.overPaymentType = overPaymentType;
  }

  public BigDecimal getOverPaymentAmount() {
    return overPaymentAmount;
  }

  public void setOverPaymentAmount(BigDecimal overPaymentAmount) {
    this.overPaymentAmount = overPaymentAmount;
  }

  public Long getRelatedId() {
    return relatedId;
  }

  public void setRelatedId(Long relatedId) {
    this.relatedId = relatedId;
  }

  public LocalDate getValidateDate() {
    return validateDate;
  }

  public void setValidateDate(LocalDate validateDate) {
    this.validateDate = validateDate;
  }
}
