package tw.com.transglobe.adp.integration.ebao.finance.service.transPayment;

import lombok.Builder;
import lombok.Data;
import tw.com.transglobe.adp.integration.ebao.common.wsclient.LocalDateAdapter;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@Builder
public class EbaoTransPaymentFailResultVo {

  String paymentIndi; // S : 付款成功, F : 付款失敗, P : 付款中, NULL : 尚未付款

  /**
   * 匯款、信用卡 :
   * 1 : 產生報盤, 2 : 付款中, 3 : 付款中 (已上傳),
   * 4 : 已回銷 (檔案), 5 : 已取消, 6 : 暫停付款, 7 : 已回銷 (人工)
   * 支票 : NULL
   */
  String paymentStatus;

  String paymentStatusDesc; // 支票 : NULL

  LocalDate paymentDate;

  LocalDate dataDate;

  String batchNo;

  String resultCode; // 支票 : NULL

  String resultDesc; // 支票 : NULL

  String resultEbaoDesc;

  String refId;

  Long feeId;

  String paymentUserName;

  String paymentUserDeptName;

  String chequeNo;

  Long chequeId;

  String chequeStatus;

  String transStatus;

  String transStatusName;

  String rtnRemitReason;

  String rtnRemitReasonName;

  // 7 碼
  String paymentBranchBankCode;

  // 3 碼
  String paymentBankCode;

  String paymentBankAccount;

  String paymentBankName;

  String paymentAbbrName;
}
