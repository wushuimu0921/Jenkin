package tw.com.transglobe.adp.integration.ec.http;

import org.mapstruct.Mapper;
import tw.com.transglobe.adp.integration.ec.http.dto.EcTaPolicyPrintReplyRequest;
import tw.com.transglobe.adp.integration.ec.http.dto.EcTaResultDto;
import tw.com.transglobe.adp.integration.ec.service.cmd.EcTaPolicyPrintReplyCmd;
import tw.com.transglobe.adp.integration.ec.service.EcTaResultVo;

@Mapper
interface EcTaDtoMapper {

  EcTaPolicyPrintReplyCmd toCmd(EcTaPolicyPrintReplyRequest request);

  EcTaResultDto fromVo(EcTaResultVo vo);
}
