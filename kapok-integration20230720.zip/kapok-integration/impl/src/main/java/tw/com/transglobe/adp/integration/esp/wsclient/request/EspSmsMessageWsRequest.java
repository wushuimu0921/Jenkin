package tw.com.transglobe.adp.integration.esp.wsclient.request;

import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
@Builder
public class EspSmsMessageWsRequest {

  @NotNull
  EspHeader header;

  @NotNull
  EspRequesterInfo requesterInfo;

  @NotNull
  EspPolicyHolderInfo policyHolderInfo;

  @NotNull
  EspSmsMessageInfo messageInfo;

  EspTemplateInfo templateInfo;

  EspEventInfo eventInfo;

}
