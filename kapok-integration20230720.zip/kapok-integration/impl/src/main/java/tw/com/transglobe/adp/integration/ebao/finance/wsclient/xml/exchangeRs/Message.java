package tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.exchangeRs;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "message", propOrder = {
    "columnName",
    "systemLength",
    "dataLength",
    "desc"
})
public class Message {

  @XmlElement(name = "ColumnName")
  protected String columnName;

  @XmlElement(name = "SystemLength")
  protected String systemLength;

  @XmlElement(name = "DataLength")
  protected String dataLength;

  @XmlElement(name = "Desc")
  protected String desc;

  public String getColumnName() {
    return columnName;
  }

  public void setColumnName(String columnName) {
    this.columnName = columnName;
  }

  public String getSystemLength() {
    return systemLength;
  }

  public void setSystemLength(String systemLength) {
    this.systemLength = systemLength;
  }

  public String getDataLength() {
    return dataLength;
  }

  public void setDataLength(String dataLength) {
    this.dataLength = dataLength;
  }

  public String getDesc() {
    return desc;
  }

  public void setDesc(String desc) {
    this.desc = desc;
  }

  @Override
  public String toString() {
    return "Message{" +
        "columnName='" + columnName + '\'' +
        ", systemLength='" + systemLength + '\'' +
        ", dataLength='" + dataLength + '\'' +
        ", desc='" + desc + '\'' +
        '}';
  }
}
