package tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRq;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import tw.com.transglobe.adp.integration.commons.enums.YesNo;
import tw.com.transglobe.adp.integration.ebao.common.wsclient.SlashLocalDateAdapter;

import javax.xml.bind.annotation.*;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.time.LocalDate;

@Getter
@Setter
@ToString
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TransPostingIngoRq", propOrder = {
    "postingDate",
    "dataDate",
    "policyCode",
    "refId",
    "isPresent"
})
@XmlRootElement(name = "GlTransPostingInfoRq")
public class TransPostingInfoRq {

  @XmlJavaTypeAdapter(SlashLocalDateAdapter.class)
  @XmlElement(name = "PostingDate")
  protected LocalDate postingDate;

  @XmlJavaTypeAdapter(SlashLocalDateAdapter.class)
  @XmlElement(name = "DataDate")
  protected LocalDate dataDate;

  @XmlElement(name = "PolicyCode")
  protected String policyCode;

  @XmlElement(name = "RefId")
  protected String refId;

  @XmlElement(name = "IsPresent", required = true)
  protected YesNo isPresent;

}
