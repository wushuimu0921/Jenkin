package tw.com.transglobe.adp.integration.ebao.common.wsclient;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * exchange complex type �� Java ���O.
 *
 * <p>
 * �U�C���n���q�|���w�����O���]�t���w�����e.
 *
 * <pre>
 * &lt;complexType name="exchange">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="arg0" type="{http://tgl.com/common/ws/}standardRequest" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "exchange", propOrder = {
    "arg0"
})
public class Exchange {

  protected StandardRequest arg0;

  /**
   * ���o arg0 �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link StandardRequest }
   *
   */
  public StandardRequest getArg0() {
    return arg0;
  }

  /**
   * �]�w arg0 �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link StandardRequest }
   *
   */
  public void setArg0(StandardRequest value) {
    this.arg0 = value;
  }

}
