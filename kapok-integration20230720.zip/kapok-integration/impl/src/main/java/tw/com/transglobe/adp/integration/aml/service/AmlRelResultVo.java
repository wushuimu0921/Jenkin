package tw.com.transglobe.adp.integration.aml.service;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class AmlRelResultVo {

  String idno;

  AmlResultVo result;

  int hitCount;
  String decType;
  String decState;
  LocalDateTime decDate;
  String decBy;
  String decComments;

}
