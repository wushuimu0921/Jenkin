package tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRs;

import lombok.*;
import tw.com.transglobe.adp.integration.commons.enums.YesNo;
import tw.com.transglobe.adp.integration.ebao.common.wsclient.SlashLocalDateAdapter;

import javax.xml.bind.annotation.*;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@ToString
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TransCheckInfoRs", propOrder = {
    "cheques",
})
@XmlRootElement(name = "QueryChequeRs")
public class TransCheckInfoRs {

  @XmlElementWrapper(name = "Cheques")
  @XmlElement(name = "Cheque", required = true)
  protected List<Cheque> cheques;

  @XmlAccessorType(XmlAccessType.FIELD)
  @XmlType(name = "", propOrder = {
      "chequeId", "bankName", "chequeNo", "payeeCertiType", "payeeCertiCode", "feeAmount", "chequeStatus", "chequeStatusName",
      "printTime", "cancelTime", "chequeDueDate", "chequeAccount", "chequeHolder", "chequeBank", "chequeSource",
      "changeDate", "cashChequeDate", "cancelScoreIndi", "cancelEndorsementIndi", "chequeRelationName", "systemId",
      "systemName", "subSystemId", "subSystemName", "businessTypeId", "businessTypeName", "openChequeTime",
      "openChequeUserName",
      "chequeHist"
  })
  @Data
  public static class Cheque {
    @XmlElement(name = "ChequeId", required = true)
    protected Long chequeId;

    @XmlElement(name = "BankName", required = true)
    protected String bankName;

    @XmlElement(name = "ChequeNo", required = true)
    protected String chequeNo;

    @XmlElement(name = "PayeeCertiType", required = true)
    protected String payeeCertiType;

    @XmlElement(name = "PayeeCertiCode", required = true)
    protected String payeeCertiCode;

    @XmlElement(name = "FeeAmount", required = true)
    protected String feeAmount;

    @XmlElement(name = "ChequeStatus", required = true)
    protected String chequeStatus;

    @XmlElement(name = "ChequeStatusName", required = true)
    protected String chequeStatusName;
    @XmlJavaTypeAdapter(SlashLocalDateAdapter.class)
    @XmlElement(name = "PrintTime", required = true)
    protected LocalDate printTime;
    @XmlJavaTypeAdapter(SlashLocalDateAdapter.class)
    @XmlElement(name = "CancelTime", required = true)
    protected LocalDate cancelTime;
    @XmlJavaTypeAdapter(SlashLocalDateAdapter.class)
    @XmlElement(name = "ChequeDueDate", required = true)
    protected LocalDate chequeDueDate;

    @XmlElement(name = "ChequeAccount", required = true)
    protected String chequeAccount;

    @XmlElement(name = "chequeHolder", required = true)
    protected String chequeHolder;

    @XmlElement(name = "ChequeBank", required = true)
    protected String chequeBank;

    @XmlElement(name = "ChequeSource", required = true)
    protected Integer chequeSource;
    @XmlJavaTypeAdapter(SlashLocalDateAdapter.class)
    @XmlElement(name = "ChangeDate", required = true)
    protected LocalDate changeDate;
    @XmlJavaTypeAdapter(SlashLocalDateAdapter.class)
    @XmlElement(name = "CashChequeDate", required = true)
    protected LocalDate cashChequeDate;

    @XmlElement(name = "CancelScoreIndi", required = true)
    protected YesNo cancelScoreIndi;

    @XmlElement(name = "CancelEndorsementIndi", required = true)
    protected YesNo cancelEndorsementIndi;

    @XmlElement(name = "ChequeRelationName", required = true)
    protected String chequeRelationName;

    @XmlElement(name = "SystemId", required = true)
    protected Integer systemId;

    @XmlElement(name = "SystemName", required = true)
    protected String systemName;

    @XmlElement(name = "SubSystemId", required = true)
    protected Integer subSystemId;

    @XmlElement(name = "SubSystemName", required = true)
    protected String subSystemName;

    @XmlElement(name = "BusinessTypeId", required = true)
    protected Integer businessTypeId;

    @XmlElement(name = "BusinessTypeName", required = true)
    protected String businessTypeName;

    @XmlElement(name = "OpenChequeTime", required = true)
    protected String openChequeTime;

    @XmlElement(name = "OpenChequeUserName", required = true)
    protected String openChequeUserName;

    @XmlElementWrapper(name = "ChequeHists")
    @XmlElement(name = "ChequeHist", required = true)
    protected List<ChequeHist> chequeHist;

  }

  @XmlAccessorType(XmlAccessType.FIELD)
  @XmlType(name = "", propOrder = {
      "oriChequeStatus", "oriStatusName", "aftChequeStatus", "aftChequeName", "changeDate", "histCreateUserName", "seq"
  })
  @Data
  public static class ChequeHist {
    @XmlElement(name = "OriChequeStatus", required = true)
    protected String oriChequeStatus;

    @XmlElement(name = "OriStatusName", required = true)
    protected String oriStatusName;

    @XmlElement(name = "AftChequeStatus", required = true)
    protected String aftChequeStatus;

    @XmlElement(name = "AftChequeName", required = true)
    protected String aftChequeName;
    @XmlJavaTypeAdapter(SlashLocalDateAdapter.class)
    @XmlElement(name = "ChangeDate", required = true)
    protected LocalDate changeDate;

    @XmlElement(name = "HistCreateUserName", required = true)
    protected String histCreateUserName;

    @XmlElement(name = "Seq", required = true)
    protected Integer seq;

  }
}
