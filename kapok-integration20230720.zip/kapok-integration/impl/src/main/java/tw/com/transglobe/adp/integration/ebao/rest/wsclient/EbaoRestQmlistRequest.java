package tw.com.transglobe.adp.integration.ebao.rest.wsclient;

import java.time.LocalDate;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EbaoRestQmlistRequest {

  String qualityType;

  String certiCode;

  String registerCode;

  String source;

  LocalDate checkDate;

}
