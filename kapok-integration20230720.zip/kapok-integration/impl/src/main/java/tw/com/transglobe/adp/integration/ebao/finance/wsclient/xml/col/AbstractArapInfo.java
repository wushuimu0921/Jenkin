//
// ���ɮ׬O�� JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.3.0 �Ҳ���
// �аѾ\ <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a>
// �@�����s�sĶ�ӷ����n, �惡�ɮשҰ�������קﳣ�N�|��.
// ���ͮɶ�: 2022.05.28 �� 10:58:49 AM CST
//

package tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.col;

import tw.com.transglobe.adp.integration.ebao.common.wsclient.SlashLocalDateAdapter;
import tw.com.transglobe.adp.integration.ebao.common.wsclient.SlashLocalDateTimeAdapter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "abstractArapInfo", propOrder = {
    "dataDate",
    "arapSeq",
    "systemId",
    "subSystemId",
    "businessTypeId",
    "refId",
    "feeType",
    "payMode",
    "feeAmount",
    "feeStatus",
    "adpPolNo",
    "adpNonPolicyCode",
    "divideIndi",
    "moneyId",
    "payMoneyId",
    "payAmount",
    "checkEnterTime",
    "phCertiCode",
    "phCertiType",
    "phName",
    "phNational",
    "phPostCode",
    "policyYear",
    "premAllocYear",
    "internalId",
    "productName",
    "productCategory",
    "prodContract",
    "prodContractName",
    "isDiscretion",
    "chargeType",
    "chargePeriod",
    "chargeYear",
    "coveragePeriod",
    "coverageYear",
    "agentChannelType",
    "agentChannelCode",
    "agentRegisterCode",
    "agentChannelTypeCode",
    "agentChannelName",
    "issueChannelType",
    "issueChannelCode",
    "issueRegisterCode",
    "issueChannelTypeCode",
    "issueChannelName",
    "dueTime",
    "accountType",
    "dividendOption",
    "glPeriod",
    "glPlanCode",
    "cashierDeptCode",
    "cashierDeptName",
    "cashierId",
    "cashierName",
    "cashierJobNo",
    "cashierTime",
    "accountingDate",
    "giempId",
    "familyId",
    "validateDate",
    "policyPeriod",
    "withdrawType",
    "grTotalIndi",
    "grValidateDate",
    "grEmpPolIndi"
})
@XmlSeeAlso({
    TransactionColArapInfo.class
})
public class AbstractArapInfo {

  @XmlElement(name = "DataDate", required = true)
  @XmlJavaTypeAdapter(SlashLocalDateTimeAdapter.class)
  protected LocalDateTime dataDate;

  @XmlElement(name = "ArapSeq")
  protected int arapSeq;
  @XmlElement(name = "SystemId")
  protected int systemId;
  @XmlElement(name = "SubSystemId")
  protected int subSystemId;
  @XmlElement(name = "BusinessTypeId")
  protected int businessTypeId;
  @XmlElement(name = "RefId", required = true)
  protected String refId;
  @XmlElement(name = "FeeType")
  protected int feeType;
  @XmlElement(name = "PayMode")
  protected int payMode;
  @XmlElement(name = "FeeAmount", required = true)
  protected BigDecimal feeAmount;
  @XmlElement(name = "FeeStatus")
  protected int feeStatus;
  @XmlElement(name = "AdpPolNo")
  protected String adpPolNo;
  @XmlElement(name = "AdpNonPolicyCode")
  protected String adpNonPolicyCode;
  @XmlElement(name = "DivideIndi")
  protected String divideIndi;
  @XmlElement(name = "MoneyId")
  protected int moneyId;
  @XmlElement(name = "PayMoneyId")
  protected int payMoneyId;
  @XmlElement(name = "PayAmount", required = true)
  protected BigDecimal payAmount;

  @XmlElement(name = "CheckEnterTime", required = true)
  @XmlJavaTypeAdapter(SlashLocalDateAdapter.class)
  protected LocalDate checkEnterTime;

  @XmlElement(name = "PhCertiCode")
  protected String phCertiCode;
  @XmlElement(name = "PhCertiType")
  protected String phCertiType;
  @XmlElement(name = "PhName")
  protected String phName;
  @XmlElement(name = "PhNational")
  protected String phNational;
  @XmlElement(name = "PhPostCode")
  protected String phPostCode;
  @XmlElement(name = "PolicyYear")
  protected Integer policyYear;
  @XmlElement(name = "PremAllocYear")
  protected Integer premAllocYear;
  @XmlElement(name = "InternalId", required = true)
  protected String internalId;
  @XmlElement(name = "ProductName")
  protected String productName;
  @XmlElement(name = "ProductCategory")
  protected String productCategory;
  @XmlElement(name = "ProdContract")
  protected String prodContract;
  @XmlElement(name = "ProdContractName")
  protected String prodContractName;
  @XmlElement(name = "IsDiscretion")
  protected String isDiscretion;
  @XmlElement(name = "ChargeType")
  protected String chargeType;
  @XmlElement(name = "ChargePeriod")
  protected String chargePeriod;
  @XmlElement(name = "ChargeYear")
  protected Integer chargeYear;
  @XmlElement(name = "CoveragePeriod")
  protected String coveragePeriod;
  @XmlElement(name = "CoverageYear")
  protected Integer coverageYear;
  @XmlElement(name = "AgentChannelType")
  protected Long agentChannelType;
  @XmlElement(name = "AgentChannelCode")
  protected String agentChannelCode;
  @XmlElement(name = "AgentRegisterCode")
  protected String agentRegisterCode;
  @XmlElement(name = "AgentChannelTypeCode")
  protected String agentChannelTypeCode;
  @XmlElement(name = "AgentChannelName")
  protected String agentChannelName;

  @XmlElement(name = "IssueChannelType")
  protected Integer issueChannelType;
  @XmlElement(name = "IssueChannelCode")
  protected String issueChannelCode;
  @XmlElement(name = "IssueRegisterCode")
  protected String issueRegisterCode;
  @XmlElement(name = "IssueChannelTypeCode")
  protected String issueChannelTypeCode;
  @XmlElement(name = "IssueChannelName")
  protected String issueChannelName;

  @XmlElement(name = "DueTime", required = true)
  @XmlJavaTypeAdapter(SlashLocalDateAdapter.class)
  protected LocalDate dueTime;

  @XmlElement(name = "AccountType")
  protected Integer accountType;
  @XmlElement(name = "DividendOption")
  protected String dividendOption;
  @XmlElement(name = "GlPeriod", required = true)
  protected String glPeriod;
  @XmlElement(name = "GlPlanCode", required = true)
  protected String glPlanCode;
  @XmlElement(name = "CashierDeptCode", required = true)
  protected String cashierDeptCode;
  @XmlElement(name = "CashierDeptName", required = true)
  protected String cashierDeptName;
  @XmlElement(name = "CashierId")
  protected String cashierId;
  @XmlElement(name = "CashierName", required = true)
  protected String cashierName;
  @XmlElement(name = "CashierJobNo", required = true)
  protected String cashierJobNo;

  @XmlElement(name = "CashierTime", required = true)
  @XmlJavaTypeAdapter(SlashLocalDateTimeAdapter.class)
  protected LocalDateTime cashierTime;

  @XmlElement(name = "AccountingDate", required = true)
  @XmlJavaTypeAdapter(SlashLocalDateAdapter.class)
  protected LocalDate accountingDate;

  @XmlElement(name = "GiempId")
  protected Integer giempId;
  @XmlElement(name = "FamilyId")
  protected Integer familyId;

  @XmlElement(name = "ValidateDate")
  @XmlJavaTypeAdapter(SlashLocalDateAdapter.class)
  protected LocalDate validateDate;

  @XmlElement(name = "PolicyPeriod")
  protected Integer policyPeriod;
  @XmlElement(name = "WithdrawType")
  protected String withdrawType;

  @XmlElement(name = "GrTotalIndi")
  protected String grTotalIndi;

  @XmlElement(name = "GrValidateDate")
  @XmlJavaTypeAdapter(SlashLocalDateAdapter.class)
  protected LocalDate grValidateDate;

  @XmlElement(name = "GrEmpPolIndi")
  protected String grEmpPolIndi;

  /**
   * ���o dataDate �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public LocalDateTime getDataDate() {
    return dataDate;
  }

  /**
   * �]�w dataDate �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setDataDate(LocalDateTime value) {
    this.dataDate = value;
  }

  /**
   * ���o arapSeq �S�ʪ���.
   *
   */
  public int getArapSeq() {
    return arapSeq;
  }

  /**
   * �]�w arapSeq �S�ʪ���.
   *
   */
  public void setArapSeq(int value) {
    this.arapSeq = value;
  }

  /**
   * ���o systemId �S�ʪ���.
   *
   */
  public int getSystemId() {
    return systemId;
  }

  /**
   * �]�w systemId �S�ʪ���.
   *
   */
  public void setSystemId(int value) {
    this.systemId = value;
  }

  /**
   * ���o subSystemId �S�ʪ���.
   *
   */
  public int getSubSystemId() {
    return subSystemId;
  }

  /**
   * �]�w subSystemId �S�ʪ���.
   *
   */
  public void setSubSystemId(int value) {
    this.subSystemId = value;
  }

  /**
   * ���o businessTypeId �S�ʪ���.
   *
   */
  public int getBusinessTypeId() {
    return businessTypeId;
  }

  /**
   * �]�w businessTypeId �S�ʪ���.
   *
   */
  public void setBusinessTypeId(int value) {
    this.businessTypeId = value;
  }

  /**
   * ���o refId �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getRefId() {
    return refId;
  }

  /**
   * �]�w refId �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setRefId(String value) {
    this.refId = value;
  }

  /**
   * ���o feeType �S�ʪ���.
   *
   */
  public int getFeeType() {
    return feeType;
  }

  /**
   * �]�w feeType �S�ʪ���.
   *
   */
  public void setFeeType(int value) {
    this.feeType = value;
  }

  /**
   * ���o payMode �S�ʪ���.
   *
   */
  public int getPayMode() {
    return payMode;
  }

  /**
   * �]�w payMode �S�ʪ���.
   *
   */
  public void setPayMode(int value) {
    this.payMode = value;
  }

  /**
   * ���o feeAmount �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link BigDecimal }
   *
   */
  public BigDecimal getFeeAmount() {
    return feeAmount;
  }

  /**
   * �]�w feeAmount �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link BigDecimal }
   *
   */
  public void setFeeAmount(BigDecimal value) {
    this.feeAmount = value;
  }

  /**
   * ���o feeStatus �S�ʪ���.
   *
   */
  public int getFeeStatus() {
    return feeStatus;
  }

  /**
   * �]�w feeStatus �S�ʪ���.
   *
   */
  public void setFeeStatus(int value) {
    this.feeStatus = value;
  }

  /**
   * ���o adpPolNo �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getAdpPolNo() {
    return adpPolNo;
  }

  /**
   * �]�w adpPolNo �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setAdpPolNo(String value) {
    this.adpPolNo = value;
  }

  /**
   * ���o adpNonPolicyCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getAdpNonPolicyCode() {
    return adpNonPolicyCode;
  }

  /**
   * �]�w adpNonPolicyCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setAdpNonPolicyCode(String value) {
    this.adpNonPolicyCode = value;
  }

  /**
   * ���o divideIndi �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getDivideIndi() {
    return divideIndi;
  }

  /**
   * �]�w divideIndi �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setDivideIndi(String value) {
    this.divideIndi = value;
  }

  /**
   * ���o moneyId �S�ʪ���.
   *
   */
  public int getMoneyId() {
    return moneyId;
  }

  /**
   * �]�w moneyId �S�ʪ���.
   *
   */
  public void setMoneyId(int value) {
    this.moneyId = value;
  }

  /**
   * ���o payMoneyId �S�ʪ���.
   *
   */
  public int getPayMoneyId() {
    return payMoneyId;
  }

  /**
   * �]�w payMoneyId �S�ʪ���.
   *
   */
  public void setPayMoneyId(int value) {
    this.payMoneyId = value;
  }

  /**
   * ���o payAmount �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link BigDecimal }
   *
   */
  public BigDecimal getPayAmount() {
    return payAmount;
  }

  /**
   * �]�w payAmount �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link BigDecimal }
   *
   */
  public void setPayAmount(BigDecimal value) {
    this.payAmount = value;
  }

  /**
   * ���o checkEnterTime �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link LocalDate }
   *
   */
  public LocalDate getCheckEnterTime() {
    return checkEnterTime;
  }

  /**
   * �]�w checkEnterTime �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCheckEnterTime(LocalDate value) {
    this.checkEnterTime = value;
  }

  /**
   * ���o phCertiCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getPhCertiCode() {
    return phCertiCode;
  }

  /**
   * �]�w phCertiCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setPhCertiCode(String value) {
    this.phCertiCode = value;
  }

  /**
   * ���o phCertiType �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getPhCertiType() {
    return phCertiType;
  }

  /**
   * �]�w phCertiType �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setPhCertiType(String value) {
    this.phCertiType = value;
  }

  /**
   * ���o phName �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getPhName() {
    return phName;
  }

  /**
   * �]�w phName �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setPhName(String value) {
    this.phName = value;
  }

  /**
   * ���o phNational �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getPhNational() {
    return phNational;
  }

  /**
   * �]�w phNational �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setPhNational(String value) {
    this.phNational = value;
  }

  /**
   * ���o phPostCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getPhPostCode() {
    return phPostCode;
  }

  /**
   * �]�w phPostCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setPhPostCode(String value) {
    this.phPostCode = value;
  }

  /**
   * ���o policyYear �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link Integer }
   *
   */
  public Integer getPolicyYear() {
    return policyYear;
  }

  /**
   * �]�w policyYear �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link Integer }
   *
   */
  public void setPolicyYear(Integer value) {
    this.policyYear = value;
  }

  /**
   * ���o premAllocYear �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link Integer }
   *
   */
  public Integer getPremAllocYear() {
    return premAllocYear;
  }

  /**
   * �]�w premAllocYear �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link Integer }
   *
   */
  public void setPremAllocYear(Integer value) {
    this.premAllocYear = value;
  }

  /**
   * ���o internalId �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getInternalId() {
    return internalId;
  }

  /**
   * �]�w internalId �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setInternalId(String value) {
    this.internalId = value;
  }

  /**
   * ���o productName �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getProductName() {
    return productName;
  }

  /**
   * �]�w productName �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setProductName(String value) {
    this.productName = value;
  }

  /**
   * ���o productCategory �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getProductCategory() {
    return productCategory;
  }

  /**
   * �]�w productCategory �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setProductCategory(String value) {
    this.productCategory = value;
  }

  /**
   * ���o prodContract �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getProdContract() {
    return prodContract;
  }

  /**
   * �]�w prodContract �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setProdContract(String value) {
    this.prodContract = value;
  }

  /**
   * ���o prodContractName �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getProdContractName() {
    return prodContractName;
  }

  /**
   * �]�w prodContractName �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setProdContractName(String value) {
    this.prodContractName = value;
  }

  /**
   * ���o isDiscretion �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getIsDiscretion() {
    return isDiscretion;
  }

  /**
   * �]�w isDiscretion �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setIsDiscretion(String value) {
    this.isDiscretion = value;
  }

  /**
   * ���o chargeType �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getChargeType() {
    return chargeType;
  }

  /**
   * �]�w chargeType �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setChargeType(String value) {
    this.chargeType = value;
  }

  /**
   * ���o chargePeriod �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getChargePeriod() {
    return chargePeriod;
  }

  /**
   * �]�w chargePeriod �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setChargePeriod(String value) {
    this.chargePeriod = value;
  }

  /**
   * ���o chargeYear �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link Integer }
   *
   */
  public Integer getChargeYear() {
    return chargeYear;
  }

  /**
   * �]�w chargeYear �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link Integer }
   *
   */
  public void setChargeYear(Integer value) {
    this.chargeYear = value;
  }

  /**
   * ���o coveragePeriod �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getCoveragePeriod() {
    return coveragePeriod;
  }

  /**
   * �]�w coveragePeriod �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCoveragePeriod(String value) {
    this.coveragePeriod = value;
  }

  /**
   * ���o coverageYear �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link Integer }
   *
   */
  public Integer getCoverageYear() {
    return coverageYear;
  }

  /**
   * �]�w coverageYear �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link Integer }
   *
   */
  public void setCoverageYear(Integer value) {
    this.coverageYear = value;
  }

  /**
   * ���o agentChannelType �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link Long }
   *
   */
  public Long getAgentChannelType() {
    return agentChannelType;
  }

  /**
   * �]�w agentChannelType �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link Long }
   *
   */
  public void setAgentChannelType(Long value) {
    this.agentChannelType = value;
  }

  /**
   * ���o agentChannelCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getAgentChannelCode() {
    return agentChannelCode;
  }

  /**
   * �]�w agentChannelCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setAgentChannelCode(String value) {
    this.agentChannelCode = value;
  }

  /**
   * ���o agentRegisterCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getAgentRegisterCode() {
    return agentRegisterCode;
  }

  /**
   * �]�w agentRegisterCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setAgentRegisterCode(String value) {
    this.agentRegisterCode = value;
  }

  /**
   * ���o agentChannelTypeCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getAgentChannelTypeCode() {
    return agentChannelTypeCode;
  }

  /**
   * �]�w agentChannelTypeCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setAgentChannelTypeCode(String value) {
    this.agentChannelTypeCode = value;
  }

  /**
   * ���o agentChannelName �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getAgentChannelName() {
    return agentChannelName;
  }

  /**
   * �]�w agentChannelName �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setAgentChannelName(String value) {
    this.agentChannelName = value;
  }

  /**
   * ���o issueChannelType �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link Integer }
   *
   */
  public Integer getIssueChannelType() {
    return issueChannelType;
  }

  /**
   * �]�w issueChannelType �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link Integer }
   *
   */
  public void setIssueChannelType(Integer value) {
    this.issueChannelType = value;
  }

  /**
   * ���o issueChannelCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getIssueChannelCode() {
    return issueChannelCode;
  }

  /**
   * �]�w issueChannelCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setIssueChannelCode(String value) {
    this.issueChannelCode = value;
  }

  /**
   * ���o issueRegisterCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getIssueRegisterCode() {
    return issueRegisterCode;
  }

  /**
   * �]�w issueRegisterCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setIssueRegisterCode(String value) {
    this.issueRegisterCode = value;
  }

  /**
   * ���o issueChannelTypeCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getIssueChannelTypeCode() {
    return issueChannelTypeCode;
  }

  /**
   * �]�w issueChannelTypeCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setIssueChannelTypeCode(String value) {
    this.issueChannelTypeCode = value;
  }

  /**
   * ���o issueChannelName �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getIssueChannelName() {
    return issueChannelName;
  }

  /**
   * �]�w issueChannelName �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setIssueChannelName(String value) {
    this.issueChannelName = value;
  }

  /**
   * ���o dueTime �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public LocalDate getDueTime() {
    return dueTime;
  }

  /**
   * �]�w dueTime �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setDueTime(LocalDate value) {
    this.dueTime = value;
  }

  /**
   * ���o accountType �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link Integer }
   *
   */
  public Integer getAccountType() {
    return accountType;
  }

  /**
   * �]�w accountType �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link Integer }
   *
   */
  public void setAccountType(Integer value) {
    this.accountType = value;
  }

  /**
   * ���o dividendOption �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getDividendOption() {
    return dividendOption;
  }

  /**
   * �]�w dividendOption �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setDividendOption(String value) {
    this.dividendOption = value;
  }

  /**
   * ���o glPeriod �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getGlPeriod() {
    return glPeriod;
  }

  /**
   * �]�w glPeriod �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setGlPeriod(String value) {
    this.glPeriod = value;
  }

  /**
   * ���o glPlanCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getGlPlanCode() {
    return glPlanCode;
  }

  /**
   * �]�w glPlanCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setGlPlanCode(String value) {
    this.glPlanCode = value;
  }

  /**
   * ���o cashierDeptCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getCashierDeptCode() {
    return cashierDeptCode;
  }

  /**
   * �]�w cashierDeptCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCashierDeptCode(String value) {
    this.cashierDeptCode = value;
  }

  /**
   * ���o cashierDeptName �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getCashierDeptName() {
    return cashierDeptName;
  }

  /**
   * �]�w cashierDeptName �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCashierDeptName(String value) {
    this.cashierDeptName = value;
  }

  /**
   * ���o cashierId �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getCashierId() {
    return cashierId;
  }

  /**
   * �]�w cashierId �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCashierId(String value) {
    this.cashierId = value;
  }

  /**
   * ���o cashierName �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getCashierName() {
    return cashierName;
  }

  /**
   * �]�w cashierName �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCashierName(String value) {
    this.cashierName = value;
  }

  /**
   * ���o accountingDate �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public LocalDate getAccountingDate() {
    return accountingDate;
  }

  /**
   * �]�w accountingDate �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link LocalDate }
   *
   */
  public void setAccountingDate(LocalDate value) {
    this.accountingDate = value;
  }

  /**
   * ���o giempId �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link Integer }
   *
   */
  public Integer getGiempId() {
    return giempId;
  }

  /**
   * �]�w giempId �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link Integer }
   *
   */
  public void setGiempId(Integer value) {
    this.giempId = value;
  }

  /**
   * ���o familyId �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link Integer }
   *
   */
  public Integer getFamilyId() {
    return familyId;
  }

  /**
   * �]�w familyId �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link Integer }
   *
   */
  public void setFamilyId(Integer value) {
    this.familyId = value;
  }

  /**
   * ���o validateDate �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link LocalDate }
   *
   */
  public LocalDate getValidateDate() {
    return validateDate;
  }

  /**
   * �]�w validateDate �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link LocalDate }
   *
   */
  public void setValidateDate(LocalDate value) {
    this.validateDate = value;
  }

  /**
   * ���o policyPeriod �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link Integer }
   *
   */
  public Integer getPolicyPeriod() {
    return policyPeriod;
  }

  /**
   * �]�w policyPeriod �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link Integer }
   *
   */
  public void setPolicyPeriod(Integer value) {
    this.policyPeriod = value;
  }

  /**
   * ���o withdrawType �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getWithdrawType() {
    return withdrawType;
  }

  /**
   * �]�w withdrawType �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setWithdrawType(String value) {
    this.withdrawType = value;
  }

  public String getGrTotalIndi() {
    return grTotalIndi;
  }

  public void setGrTotalIndi(String grTotalIndi) {
    this.grTotalIndi = grTotalIndi;
  }

  public LocalDate getGrValidateDate() {
    return grValidateDate;
  }

  public void setGrValidateDate(LocalDate grValidateDate) {
    this.grValidateDate = grValidateDate;
  }

  public String getGrEmpPolIndi() {
    return grEmpPolIndi;
  }

  public void setGrEmpPolIndi(String grEmpPolIndi) {
    this.grEmpPolIndi = grEmpPolIndi;
  }

  public String getCashierJobNo() {
    return cashierJobNo;
  }

  public void setCashierJobNo(String cashierJobNo) {
    this.cashierJobNo = cashierJobNo;
  }

  public LocalDateTime getCashierTime() {
    return cashierTime;
  }

  public void setCashierTime(LocalDateTime cashierTime) {
    this.cashierTime = cashierTime;
  }

}
