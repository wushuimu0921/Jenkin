package tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.exchangeRs;

import javax.xml.bind.annotation.*;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "transMsg", propOrder = {
    "transSeq",
    "cashDataMsgs",
    "arapDataMsgs"
})
public class TransMsg {

  @XmlElement(name = "TransSeq")
  protected Integer transSeq; // 交易流水號

  @XmlElementWrapper(name = "CashDataMsgs")
  @XmlElement(name = "CashDataMsg")
  protected List<CashDataMsg> cashDataMsgs;

  @XmlElementWrapper(name = "ArapDataMsgs")
  @XmlElement(name = "ArapDataMsg")
  protected List<ArapDataMsg> arapDataMsgs;

  public Integer getTransSeq() {
    return transSeq;
  }

  public void setTransSeq(Integer transSeq) {
    this.transSeq = transSeq;
  }

  public List<CashDataMsg> getCashDataMsgs() {
    return cashDataMsgs;
  }

  public void setCashDataMsgs(List<CashDataMsg> cashDataMsgs) {
    this.cashDataMsgs = cashDataMsgs;
  }

  public List<ArapDataMsg> getArapDataMsgs() {
    return arapDataMsgs;
  }

  public void setArapDataMsgs(List<ArapDataMsg> arapDataMsgs) {
    this.arapDataMsgs = arapDataMsgs;
  }

  @Override
  public String toString() {
    return "TransMsg{" +
        "transSeq=" + transSeq +
        ", cashDataMsgs=" + cashDataMsgs +
        ", arapDataMsgs=" + arapDataMsgs +
        '}';
  }
}
