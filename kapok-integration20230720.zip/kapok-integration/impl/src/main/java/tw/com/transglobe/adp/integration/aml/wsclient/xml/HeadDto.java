package tw.com.transglobe.adp.integration.aml.wsclient.xml;

import lombok.Data;

import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
//@XmlType(name = "head", propOrder = {
//    "appCode",
//    "unit",
//    "callType",
//    "category",
//    "messageID",
//    "fmt",
//    "usercode",
//    "userdata"
//})
@XmlRootElement(name = "head")
@Data
public class HeadDto {

  @XmlElement(name = "AppCode", required = true)
  protected String appCode;
  @XmlElement(name = "Unit", required = true)
  protected String unit;
  @XmlElement(name = "CallType", required = true)
  protected String callType;
  @XmlElement(name = "MessageID")
  protected String messageID;
  @XmlElement(name = "Fmt", required = true)
  protected String fmt;
  @XmlElement(name = "Usercode")
  protected String usercode;
  @XmlElement(name = "Userdata")
  protected String userdata;
  @XmlElement(name = "Calc")
  protected String calc;
  @XmlElement(name = "IsFull")
  protected String isFull;
  @XmlElement(name = "SendTime")
  protected String sendTime;
  @XmlElement(name = "RetCode")
  protected String retCode;
  @XmlElement(name = "ErrMsg")
  protected String errMsg;

}
