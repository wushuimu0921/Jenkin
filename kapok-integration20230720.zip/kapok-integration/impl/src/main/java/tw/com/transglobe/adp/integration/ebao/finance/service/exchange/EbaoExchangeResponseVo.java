package tw.com.transglobe.adp.integration.ebao.finance.service.exchange;

import java.util.List;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EbaoExchangeResponseVo {

  EbaoExchangeResponseObj responseObj;

  String responseCode; // XML執行結果

  String responseDesc; // XML執行結果說明

  //  List<EbaoExchangeTransMsg> transMsgs;
}
