package tw.com.transglobe.adp.integration.ebao.common.service;

import tw.com.transglobe.adp.integration.ebao.common.service.vo.EbaoCommonRequestVo;
import tw.com.transglobe.adp.integration.ebao.common.service.vo.EbaoCommonResponseVo;

public interface EbaoCommonWsClient {
  EbaoCommonResponseVo exchange(EbaoCommonRequestVo request);
}
