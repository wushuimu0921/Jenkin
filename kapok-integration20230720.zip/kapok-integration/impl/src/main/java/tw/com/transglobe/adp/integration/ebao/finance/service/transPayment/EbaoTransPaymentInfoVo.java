package tw.com.transglobe.adp.integration.ebao.finance.service.transPayment;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import tw.com.transglobe.adp.integration.commons.enums.EbaoChequeStatus;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRs.TransCheckInfoRs;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRs.TransPaymentInfoRs;

import javax.xml.bind.annotation.XmlElement;
import java.time.LocalDate;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EbaoTransPaymentInfoVo {
  LocalDate paymentDate;
  String policyCode;
  EbaoTransPaymentResultInfoVo paymentResultInfo;
}
