package tw.com.transglobe.adp.integration.aml.service;

import ciben.data.converter.Converter;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import tw.com.softleader.data.security.guardium.annotation.Safeguard;
import tw.com.transglobe.adp.integration.config.AdpIntegrationProperties;

@Slf4j
@Service
@RequiredArgsConstructor
@Safeguard
public class AmlService {

  final LyodsWebServiceClient lyodsWebServiceClient;

  final AdpIntegrationProperties properties;

  public AmlCifResultVo getAml(AmlCriteria criteria) {

    log.debug("{}", criteria);

    try {
      try {
        Converter cibenCv = new Converter(properties.getCiben().getFilePath());
        // 難字轉換為UTF8
        cifConverterNameToUTF8(cibenCv, criteria.getCif());
        relsConverterNameToUTF8(cibenCv, criteria.getRels());
        accConverterNameToUTF8(cibenCv, criteria.getAcc());
      } catch (Exception e) {
        log.error("讀取難字檔錯誤", e);
      }
      accConverterCurrency(criteria.getAcc());

      var response = lyodsWebServiceClient.fofExecCif(
          LyodsWebServiceCmd.builder().appCode(criteria.getAppCode().toString())
              .unit(criteria.getUnit())
              .callType(criteria.getCallType().toString())
              .userdata(criteria.getLoginAccount())
              .calc(criteria.getCalcType().getNumCode())
              .isFull(String.valueOf(criteria.isFull))
              .cif(criteria.getCif())
              .rels(criteria.getRels())
              .acc(criteria.getAcc())
              .build());

      log.debug("{}", response);

      return response;

    } catch (Exception ex) {
      throw new LyodsWebServiceException("ERROR : Call LyodsWebService", ex);
    }

  }

  /**
   * 中文、羅馬拼音難字轉換 (由於不設限羅馬拼音欄位僅可輸入英文，需一併處理轉換)
   *
   * @param cv
   * @param cif
   */
  private void cifConverterNameToUTF8(final Converter cv, final AmlCifData cif) {
    if (cv == null || cif == null) {
      return;
    }
    final Map<String, String> fields = cif.fields();
    Optional.ofNullable(fields.get("name"))
        .ifPresent(d -> fields.put("name", cv.cvrtB2U(d)));
    Optional.ofNullable(fields.get("enName"))
        .ifPresent(d -> fields.put("enName", cv.cvrtB2U(d)));
  }

  /**
   * 中文、羅馬拼音難字轉換 (由於不設限羅馬拼音欄位僅可輸入英文，需一併處理轉換)
   *
   * @param cv
   * @param rels
   */
  private void relsConverterNameToUTF8(final Converter cv, final List<AmlRelData> rels) {
    if (cv == null || CollectionUtils.isEmpty(rels)) {
      return;
    }
    rels.forEach(amlRelData -> {
      final Map<String, String> fields = amlRelData.fields();
      Optional.ofNullable(fields.get("name"))
          .ifPresent(d -> fields.put("name", cv.cvrtB2U(d)));
      Optional.ofNullable(fields.get("enName"))
          .ifPresent(d -> fields.put("enName", cv.cvrtB2U(d)));
    });
  }

  /**
   * 中文、羅馬拼音難字轉換 (由於不設限羅馬拼音欄位僅可輸入英文，需一併處理轉換)
   *
   * @param cv
   * @param accs
   */
  private void accConverterNameToUTF8(final Converter cv, final List<AmlAccData> accs) {
    if (cv == null || CollectionUtils.isEmpty(accs)) {
      return;
    }
    accs.forEach(amlAccData -> {
      final Map<String, String> fields = amlAccData.fields();
      Optional.ofNullable(fields.get("name"))
          .ifPresent(d -> fields.put("name", cv.cvrtB2U(d)));
      Optional.ofNullable(fields.get("enName"))
          .ifPresent(d -> fields.put("enName", cv.cvrtB2U(d)));
    });
  }

  /**
   * 轉換 eBao 幣別 (TWD押 8) 若有其他幣別需要再詢問
   * 
   * @param accs
   */
  private void accConverterCurrency(final List<AmlAccData> accs) {
    if (CollectionUtils.isEmpty(accs)) {
      return;
    }
    accs.forEach(amlAccData -> {
      final Map<String, String> fields = amlAccData.fields();
      Optional.ofNullable(fields.get("currency"))
          .ifPresent(d -> {
            if ("TWD".equals(d)) {
              fields.put("currency", "8");
            }
          });
    });
  }

}
