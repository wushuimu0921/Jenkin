package tw.com.transglobe.adp.integration.ebao.finance.service.cmd;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class EbaoFinanceQueryChequeCmd {

  @Schema(description = "支票Id")
  List<Long> chequeIds;

}
