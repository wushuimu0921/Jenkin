package tw.com.transglobe.adp.integration.ebao.finance.service.exchange;

import lombok.Builder;
import lombok.Data;
import java.util.List;

@Data
@Builder
public class EbaoExchangeEventMsg {

  String detectTypeName;

  List<EbaoExchangeMessage> messages;
}
