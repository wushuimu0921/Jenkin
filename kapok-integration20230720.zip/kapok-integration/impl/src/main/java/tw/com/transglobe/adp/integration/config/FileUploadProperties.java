package tw.com.transglobe.adp.integration.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Data
@ConfigurationProperties(prefix = "transglobe.integration.esp-mail-attach")
public class FileUploadProperties {

  String url;

  String path;
}
