package tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.exchangeRs;

import javax.xml.bind.annotation.*;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "responseObj", propOrder = {
    "transMsgs"
})
public class ResponseObj {

  @XmlElementWrapper(name = "TransMsgs")
  @XmlElement(name = "TransMsg")
  protected List<TransMsg> transMsgs;

  public List<TransMsg> getTransMsgs() {
    return transMsgs;
  }

  public void setTransMsgs(List<TransMsg> transMsgs) {
    this.transMsgs = transMsgs;
  }

  @Override
  public String toString() {
    return "ResponseObj{" +
        "transMsgs=" + transMsgs +
        '}';
  }
}
