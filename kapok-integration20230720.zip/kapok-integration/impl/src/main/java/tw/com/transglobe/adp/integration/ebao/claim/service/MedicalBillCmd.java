package tw.com.transglobe.adp.integration.ebao.claim.service;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

@Data
@Builder
public class MedicalBillCmd {

  String hospitalName;

  LocalDate billStartDate;

  LocalDate billEndDate;

  String receiptTypeCode;

  Integer limitIndicator;

  String auditDecision;

  String auditDecisionDesc;
}
