package tw.com.transglobe.adp.integration.aml.service;

import java.time.LocalDateTime;
import java.util.List;
import lombok.Data;

@Data
public class AmlCifResultVo {

  String idno;
  AmlResultVo result;

  int hitCount;
  String decType;
  String decState;
  LocalDateTime decDate;
  String decBy;
  String decComments;

  // calculate
  LocalDateTime calculateDate;
  Integer calculateScore;
  String calculateLevel;
  Integer calculateReview;

  List<AmlRelResultVo> rels;

}
