package tw.com.transglobe.adp.integration.esp.service.client;

import tw.com.transglobe.adp.integration.esp.service.cmd.EspMailCmd;

public interface EspMailWebServiceClient {

  String sendMail(EspMailCmd cmd);

}
