package tw.com.transglobe.adp.integration.aml.wsclient.xml;

import javax.xml.bind.annotation.adapters.XmlAdapter;

public class AdaptorCDATADto extends XmlAdapter<String, String> {

  @Override
  public String marshal(String arg0) throws Exception {
    return "<![CDATA[" + arg0 + "]]>";
  }

  @Override
  public String unmarshal(String arg0) throws Exception {

    return arg0;
  }

}
