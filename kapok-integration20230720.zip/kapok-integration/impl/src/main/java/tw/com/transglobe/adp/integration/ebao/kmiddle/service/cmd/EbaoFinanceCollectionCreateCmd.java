package tw.com.transglobe.adp.integration.ebao.kmiddle.service.cmd;

import lombok.Builder;
import lombok.Data;
import tw.com.transglobe.adp.integration.commons.enums.*;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@Builder
public class EbaoFinanceCollectionCreateCmd {
  LocalDate dataDate; //資料日期
  Integer cashSeq; //流水號
  Integer systemId; //系統代碼(1=>團旅險)
  Integer subSystemId;
  Integer businessTypeId;
  String refId; // REF ID, 取得 Record.id
  String adpPolNo; // 保單號碼, 非必填
  PayMode payMode; // 付款方式
  PaySource paySource; // 付款來源
  FeeType feeType; // 費用類型
  BigDecimal feeAmount; // 費用金額
  FeeStatus feeStatus; // 費用狀態 , default 0
  String divideIndi; // 區隔標記 ?? default T
  String phCertiCode; //要保人證號
  String phName; //要保人姓名
  MoneyId moneyId; // 保單幣別
  MoneyId payMoneyId; // 交易幣別
  BigDecimal payAmount; // 交易幣金額
  LocalDate checkEnterTime; // 交易日期
  LocalDate finishTime; // 公司入帳日

  ChannelType agentChannelType;
  String agentChannelCode;
  String agentRegisterCode;
  String agentChannelName;

  String cashierDeptCode;
  String cashierDeptName;
  String cashierName;
  LocalDate accountingDate;
  String creditCardNum;
  String creditCardAuth;
  String creditCardExpireDate;
  Long creditCardAcquirerId;
  String chequeNo;
  CheckSource chequeSource;
  BigDecimal chequeAmount;
  String chequeBank;
  LocalDate chequeDueDate;
  String chequePhCertiCode;
  PhCertiType chequePhCertiType;
  String chequePhName;
  Long internalAccount;
  String voucherNo;
  LocalDate voucherDate;
  BigDecimal voucherAmount;
  String postTransNo;
  ProductCategory productCategory;
}
