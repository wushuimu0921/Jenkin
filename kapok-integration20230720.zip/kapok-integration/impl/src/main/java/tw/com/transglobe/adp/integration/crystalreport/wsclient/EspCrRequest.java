package tw.com.transglobe.adp.integration.crystalreport.wsclient;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
class EspCrRequest {

  String requestSystem;
  String moduleName;
  String reportId;
  String fileFormat;
  String p_userid;
  List<EspCrParameter> parameterList;

}
