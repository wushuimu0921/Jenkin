package tw.com.transglobe.adp.integration.esp.service;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class UploadFileVo {

  String fileName;

  String extName;

  String pvcFileKey;

  List<String> pvcPaths;

}
