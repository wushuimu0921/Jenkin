package tw.com.transglobe.adp.integration.ebao.finance.service.exchange;

import lombok.Builder;
import lombok.Data;
import java.util.List;

@Data
@Builder
public class EbaoExchangeTransMsg {

  Integer transSeq; // 交易流水號
  List<EbaoExchangeCashDataMsg> cashDataMsgs;
  List<EbaoExchangeArapDataMsg> arapDataMsgs;
}
