package tw.com.transglobe.adp.integration.ebao.rest.wsclient;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import tw.com.transglobe.adp.integration.ebao.rest.service.EbaoRestQmlistCriteria;
import tw.com.transglobe.adp.integration.ebao.rest.service.EbaoRestQmlistVo;
import tw.com.transglobe.adp.integration.ebao.rest.service.EbaoRestServiceClient;

import java.util.List;

@Slf4j
@RequiredArgsConstructor
public class EbaoRestServiceClientMock implements EbaoRestServiceClient {

  @Override
  public List<EbaoRestQmlistVo> getQmlist(EbaoRestQmlistCriteria criteria) {
    return List.of();
  }

}
