//
// ���ɮ׬O�� JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.8-b130911.1802 �Ҳ���
// �аѾ\ <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a>
// �@�����s�sĶ�ӷ����n, �惡�ɮשҰ�������קﳣ�N�|��.
// ���ͮɶ�: 2022.10.05 �� 12:31:29 PM CST
//

package tw.com.transglobe.adp.integration.ebao.kmiddle.wsclient.xml.generated_rs;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the generated package.
 * <p>
 * An ObjectFactory allows you to programatically
 * construct new instances of the Java representation
 * for XML content. The Java representation of XML
 * content can consist of schema derived interfaces
 * and classes representing the binding of schema
 * type definitions, element declarations and model
 * groups. Factory methods for each of these are
 * provided in this class.
 *
 */
@XmlRegistry
public class ObjectFactory {

  private final static QName _GroupClaimRecordQueryRs_QNAME = new QName("", "GroupClaimRecordQueryRs");
  private final static QName _ClaimData_QNAME = new QName("", "ClaimData");
  private final static QName _ClaimSurgeryData_QNAME = new QName("", "ClaimSurgeryData");
  private final static QName _ClaimBillData_QNAME = new QName("", "ClaimBillData");
  private final static QName _ClaimPolicyData_QNAME = new QName("", "ClaimPolicyData");

  /**
   * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: generated
   *
   */
  public ObjectFactory() {
  }

  /**
   * Create an instance of {@link Cmn130OutC1 }
   *
   */
  public Cmn130OutC1 createCmn130OutC1() {
    return new Cmn130OutC1();
  }

  /**
   * Create an instance of {@link Cmn130Out }
   *
   */
  public Cmn130Out createCmn130Out() {
    return new Cmn130Out();
  }

  /**
   * Create an instance of {@link Cmn130OutC1C2 }
   *
   */
  public Cmn130OutC1C2 createCmn130OutC1C2() {
    return new Cmn130OutC1C2();
  }

  /**
   * Create an instance of {@link Cmn130OutC1C3 }
   *
   */
  public Cmn130OutC1C3 createCmn130OutC1C3() {
    return new Cmn130OutC1C3();
  }

  /**
   * Create an instance of {@link Cmn130OutC1C1 }
   *
   */
  public Cmn130OutC1C1 createCmn130OutC1C1() {
    return new Cmn130OutC1C1();
  }

  /**
   * Create an instance of {@link Cmn130OutC1 .ClaimPolicyDataList }
   *
   */
  public Cmn130OutC1.ClaimPolicyDataList createCmn130OutC1ClaimPolicyDataList() {
    return new Cmn130OutC1.ClaimPolicyDataList();
  }

  /**
   * Create an instance of {@link Cmn130OutC1 .ClaimSurgeryDataList }
   *
   */
  public Cmn130OutC1.ClaimSurgeryDataList createCmn130OutC1ClaimSurgeryDataList() {
    return new Cmn130OutC1.ClaimSurgeryDataList();
  }

  /**
   * Create an instance of {@link Cmn130OutC1 .ClaimBillDataList }
   *
   */
  public Cmn130OutC1.ClaimBillDataList createCmn130OutC1ClaimBillDataList() {
    return new Cmn130OutC1.ClaimBillDataList();
  }

  /**
   * Create an instance of {@link Cmn130Out.ClaimDataList }
   *
   */
  public Cmn130Out.ClaimDataList createCmn130OutClaimDataList() {
    return new Cmn130Out.ClaimDataList();
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link Cmn130Out }{@code >}}
   *
   */
  @XmlElementDecl(namespace = "", name = "GroupClaimRecordQueryRs")
  public JAXBElement<Cmn130Out> createGroupClaimRecordQueryRs(Cmn130Out value) {
    return new JAXBElement<Cmn130Out>(_GroupClaimRecordQueryRs_QNAME, Cmn130Out.class, null, value);
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link Cmn130OutC1 }{@code >}}
   *
   */
  @XmlElementDecl(namespace = "", name = "ClaimData")
  public JAXBElement<Cmn130OutC1> createClaimData(Cmn130OutC1 value) {
    return new JAXBElement<Cmn130OutC1>(_ClaimData_QNAME, Cmn130OutC1.class, null, value);
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link Cmn130OutC1C2 }{@code >}}
   *
   */
  @XmlElementDecl(namespace = "", name = "ClaimSurgeryData")
  public JAXBElement<Cmn130OutC1C2> createClaimSurgeryData(Cmn130OutC1C2 value) {
    return new JAXBElement<Cmn130OutC1C2>(_ClaimSurgeryData_QNAME, Cmn130OutC1C2.class, null, value);
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link Cmn130OutC1C3 }{@code >}}
   *
   */
  @XmlElementDecl(namespace = "", name = "ClaimBillData")
  public JAXBElement<Cmn130OutC1C3> createClaimBillData(Cmn130OutC1C3 value) {
    return new JAXBElement<Cmn130OutC1C3>(_ClaimBillData_QNAME, Cmn130OutC1C3.class, null, value);
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link Cmn130OutC1C1 }{@code >}}
   *
   */
  @XmlElementDecl(namespace = "", name = "ClaimPolicyData")
  public JAXBElement<Cmn130OutC1C1> createClaimPolicyData(Cmn130OutC1C1 value) {
    return new JAXBElement<Cmn130OutC1C1>(_ClaimPolicyData_QNAME, Cmn130OutC1C1.class, null, value);
  }

}
