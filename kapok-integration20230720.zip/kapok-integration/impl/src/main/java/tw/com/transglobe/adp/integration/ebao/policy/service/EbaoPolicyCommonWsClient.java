package tw.com.transglobe.adp.integration.ebao.policy.service;

import java.util.List;
import tw.com.transglobe.adp.integration.commons.enums.ProductGroupType;

public interface EbaoPolicyCommonWsClient {
  public List<EbaoPolicyCommonVo> getPolicy(ProductGroupType productGroupType, String idno);
}
