package tw.com.transglobe.adp.integration.ebao.rest.service;

import java.time.LocalDate;
import lombok.Builder;
import lombok.Data;
import tw.com.transglobe.adp.integration.ebao.rest.enums.QmlistType;

@Data
@Builder
public class EbaoRestQmlistCriteria {

  QmlistType type;

  String idno;

  String agentNo;

  String source;

  LocalDate checkDate;

}
