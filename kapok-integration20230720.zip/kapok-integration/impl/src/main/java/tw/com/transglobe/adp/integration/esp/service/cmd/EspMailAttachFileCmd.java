package tw.com.transglobe.adp.integration.esp.service.cmd;

import lombok.Builder;
import lombok.Data;
import tw.com.transglobe.adp.integration.esp.service.UploadFileVo;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@Builder
public class EspMailAttachFileCmd {

  @NotNull
  Long policyId;

  String quotationNo;

  String policyNo;

  @NotEmpty
  String applicantIdno;

  @NotEmpty
  String senderEmail;

  @NotEmpty
  String senderName;

  @NotEmpty
  String contactEmail;

  String mailSubject;

  String mailContent;

  String filePassword;

  String eventCode;

  List<UploadFileVo> files; // 附加檔案路徑
}
