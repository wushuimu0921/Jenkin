package tw.com.transglobe.adp.integration.esp.wsclient.impl;

import com.google.common.collect.Lists;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;
import tw.com.transglobe.adp.integration.esp.service.cmd.EspAttachFileCmd;
import tw.com.transglobe.adp.integration.esp.service.cmd.EspMailCmd;
import tw.com.transglobe.adp.integration.esp.service.client.EspMailWebServiceClient;
import tw.com.transglobe.adp.integration.esp.wsclient.EspMailAttachFeignClient;
import tw.com.transglobe.adp.integration.esp.wsclient.request.EspAttachFileInfo;
import tw.com.transglobe.adp.integration.esp.wsclient.request.EspAttachInfo;
import tw.com.transglobe.adp.integration.esp.wsclient.request.EspEventInfo;
import tw.com.transglobe.adp.integration.esp.wsclient.request.EspHeader;
import tw.com.transglobe.adp.integration.esp.wsclient.request.EspMailAttachFileWsRequest;
import tw.com.transglobe.adp.integration.esp.wsclient.request.EspMessageInfo;
import tw.com.transglobe.adp.integration.esp.wsclient.request.EspPolicyHolderInfo;
import tw.com.transglobe.adp.integration.esp.wsclient.request.EspRequesterInfo;

import java.util.Base64;
import java.util.List;
import java.util.Optional;

@Slf4j
@RequiredArgsConstructor
public class EspMailServiceClientImpl implements EspMailWebServiceClient {

  final EspMailAttachFeignClient feignClient;

  @SneakyThrows
  @Override
  public String sendMail(EspMailCmd cmd) {
    log.debug("SendEmail cmd = {}", cmd);

    // 從PV下載附件resource
    EspMailAttachFileWsRequest wsRequest = EspMailAttachFileWsRequest.builder()
        .header(getHeader(cmd))
        .requesterInfo(getRequesterInfo(cmd))
        .policyHolderInfo(getPolicyHolderInfo(cmd))
        .messageInfo(getMessageInfo(cmd))
        //        .templateInfo(getTemplateInfo(cmd))
        .eventInfo(getEventInfo(cmd))
        .build();
    log.debug("SendEmail wsRequest = {}", wsRequest);
    String result = feignClient.sendMailAttach(wsRequest);
    log.debug("SendEmail result = {}", result);

    return result;
  }

  private EspHeader getHeader(EspMailCmd cmd) {
    return EspHeader.builder()
        .requesterSystem("ADP")
        .requesterID(cmd.getProductGroupType().name())
        //        .requesterPwd(null)
        .build();
  }

  private EspRequesterInfo getRequesterInfo(EspMailCmd cmd) {
    return EspRequesterInfo.builder()
        .contactSysId("ADP-" + cmd.getProductGroupType().name())
        .contactSysOperatorId(cmd.getContactSysOperatorId())
        .contactSysOperatorName(cmd.getContactSysOperatorName())
        .functionCategory(cmd.getFunctionCategory())
        .functionName(cmd.getFunctionName())
        .build();
  }

  /**
   * 保單號碼、要保人ID、被保人ID、受益人ID
   * 部分欄位必入，但EMAIL不一定是單一保單，先塞 -
   */
  private EspPolicyHolderInfo getPolicyHolderInfo(EspMailCmd cmd) {
    return EspPolicyHolderInfo.builder()
        .policyNo(StringUtils.isBlank(cmd.getPolicyNo()) ? "0" : cmd.getPolicyNo())
        .proposerId(StringUtils.isBlank(cmd.getProposerId()) ? "0" : cmd.getProposerId())
        .insuredId(StringUtils.isBlank(cmd.getInsuredId()) ? "0" : cmd.getInsuredId())
        .beneficiaryId(StringUtils.isBlank(cmd.getBeneficiaryId()) ? "0" : cmd.getBeneficiaryId())
        .build();
  }

  private EspMessageInfo getMessageInfo(EspMailCmd cmd) {
    EspMessageInfo messageInfo = EspMessageInfo.builder()
        .referenceId(String.valueOf(cmd.getPolicyId()))
        .subject(cmd.getMailSubject())
        .msgData(cmd.getMailContent())
        .fromAddress(cmd.getSenderEmail())
        .fromName(cmd.getSenderName())
        .toAddress(cmd.getContactEmails())
        .build();

    if (!CollectionUtils.isEmpty(cmd.getAttachFiles())) {
      List<EspAttachFileInfo> fileInfos = Lists.newArrayList();
      for (EspAttachFileCmd file : cmd.getAttachFiles()) {
        log.info("SendEmail 附加檔案:{}, byte.length:{}", file.getFileName() + "." + file.getExtName(), file.getBytes().length);
        EspAttachFileInfo fileInfo = EspAttachFileInfo.builder()
            .attachFileName(file.getFileName())
            .attachFileNameExt(file.getExtName())
            .attachFileContent(Base64.getEncoder().encodeToString(file.getBytes()))
            //          .attachFileCert(file.getPassword())
            .build();
        fileInfos.add(fileInfo);
      }

      String zipFileName = "";
      if (cmd.isDoZip()) {
        zipFileName = Optional.ofNullable(cmd.getZipFileName()).orElse("file");
      }

      EspAttachInfo attachInfo = EspAttachInfo.builder()
          .doZip(cmd.isDoZip())
          .zipFileName(zipFileName)
          .zipCert(cmd.getZipCert())
          .attachFileInfos(fileInfos)
          .build();
      messageInfo.setAttachInfo(attachInfo);
    }

    return messageInfo;
  }

  //  private EspTemplateInfo getTemplateInfo(EspMailCmd cmd) {
  //    return EspTemplateInfo.builder()
  //        .templateId(null)
  //        .templateXmlVar(null)
  //        .build();
  //  }

  private EspEventInfo getEventInfo(EspMailCmd cmd) {
    return EspEventInfo.builder()
        .eventId(cmd.getEventId())
        .build();
  }

}
