package tw.com.transglobe.adp.integration.ebao.kmiddle.service;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

@Data
@Builder
public class KmiddleClaimBillData {

  /**
   * 單據類型
   * 1:門診單據
   * 2:住院單據
   */
  long billType;

  /** 就醫區間起日 格式為yyyy-MM-dd */
  LocalDate startDate;

  /** 就醫區間迄日 格式為yyyy-MM-dd */
  LocalDate endDate;

  /** 診療院所 */
  String hospitalName;
}
