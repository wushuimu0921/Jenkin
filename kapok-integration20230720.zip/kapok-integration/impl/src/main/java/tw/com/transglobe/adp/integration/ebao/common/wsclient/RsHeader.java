package tw.com.transglobe.adp.integration.ebao.common.wsclient;

import lombok.ToString;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * <p>
 * rsHeader complex type �� Java ���O.
 *
 * <p>
 * �U�C���n���q�|���w�����O���]�t���w�����e.
 *
 * <pre>
 * &lt;complexType name="rsHeader">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="returnCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="returnMsg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="rqUID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="rsTimestamp" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@ToString
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "rsHeader", propOrder = {
    "returnCode",
    "returnMsg",
    "rqUID",
    "rsTimestamp"
})
public class RsHeader {

  protected String returnCode;
  protected String returnMsg;
  protected String rqUID;
  @XmlSchemaType(name = "dateTime")
  protected XMLGregorianCalendar rsTimestamp;

  /**
   * ���o returnCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getReturnCode() {
    return returnCode;
  }

  /**
   * �]�w returnCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setReturnCode(String value) {
    this.returnCode = value;
  }

  /**
   * ���o returnMsg �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getReturnMsg() {
    return returnMsg;
  }

  /**
   * �]�w returnMsg �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setReturnMsg(String value) {
    this.returnMsg = value;
  }

  /**
   * ���o rqUID �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getRqUID() {
    return rqUID;
  }

  /**
   * �]�w rqUID �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setRqUID(String value) {
    this.rqUID = value;
  }

  /**
   * ���o rsTimestamp �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link XMLGregorianCalendar }
   *
   */
  public XMLGregorianCalendar getRsTimestamp() {
    return rsTimestamp;
  }

  /**
   * �]�w rsTimestamp �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link XMLGregorianCalendar }
   *
   */
  public void setRsTimestamp(XMLGregorianCalendar value) {
    this.rsTimestamp = value;
  }

}
