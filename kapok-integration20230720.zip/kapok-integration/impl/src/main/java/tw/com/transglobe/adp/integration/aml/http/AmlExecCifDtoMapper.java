package tw.com.transglobe.adp.integration.aml.http;

import static org.mapstruct.CollectionMappingStrategy.TARGET_IMMUTABLE;
import static org.mapstruct.NullValueMappingStrategy.RETURN_DEFAULT;

import org.mapstruct.Mapper;

//@Mapper(componentModel = "spring", collectionMappingStrategy = TARGET_IMMUTABLE, nullValueMappingStrategy = RETURN_DEFAULT)
interface AmlExecCifDtoMapper {

  //  @Mapping(target = "xml", source = "dto", qualifiedByName = "changeCifXml")
  //  ExecCifCmd fromDto(AmlExecCifDto dto);
  //
  //  @Named("changeCifXml")
  //  default ExecCifForXml changeCifXml(AmlExecCifDto dto) {
  //    var execCifForXml = new ExecCifForXml();
  //    var cifForXml = new CifForXml();
  //    List<FIELD> fields = new ArrayList<>();
  //    var xml = dto.getXml();
  //    fields.add(setFields("status", xml.getStatus()));
  //    fields.add(setFields("appDate", xml.getAppDate()));
  //    fields.add(setFields("openDate", xml.getOpenDate()));
  //    fields.add(setFields("name", xml.getName()));
  //    fields.add(setFields("enName", xml.getEnName()));
  //    fields.add(setFields("usage", xml.getUsage()));
  //    fields.add(setFields("updatedDate", xml.getUpdatedDate()));
  //    fields.add(setFields("EXT_USER_AD", xml.getExtUserAd()));
  //
  //    cifForXml.setCino(dto.getMessageId());
  //    cifForXml.setField(fields);
  //    execCifForXml.setCifForXml(cifForXml);
  //
  //    if (Optional.ofNullable(xml.getRelList()).isPresent() && xml.getRelList().size() > 0) {
  //      var relForXmls = new ArrayList<RelForXml>();
  //      int idx = 1;
  //      xml.getRelList().forEach(rel -> {
  //        var relForXml = new RelForXml();
  //        relForXml.setCino(cifForXml.getCino() + "_1");
  //        List<FIELD> relfields = new ArrayList<>();
  //        relfields.add(setFields("status", rel.getStatus()));
  //        fields.add(setFields("openDate", rel.getOpenDate()));
  //        fields.add(setFields("name", rel.getName()));
  //        fields.add(setFields("enName", rel.getEnName()));
  //        fields.add(setFields("gender", rel.getGender()));
  //        fields.add(setFields("bierhdate", rel.getBirthday()));
  //        fields.add(setFields("ctrOfHome", rel.getCtrOfHome()));
  //        fields.add(setFields("primNat", rel.getPrimNat()));
  //        fields.add(setFields("relShip", rel.getRelShip()));
  //        fields.add(setFields("updatedDate", rel.getUpdatedDate()));
  //        fields.add(setFields("EXT_USER_AD", rel.getExtUserAD()));
  //
  //        relForXml.setField(relfields);
  //        relForXmls.add(relForXml);
  //
  //      });
  //
  //    }
  //    ;
  //
  //    if (Optional.ofNullable(xml.getAccList()).isPresent() && xml.getAccList().size() > 0) {
  //
  //    }
  //
  //    return execCifForXml;
  //  }
  //
  //  default FIELD setFields(String name, String value) {
  //    var field = new FIELD();
  //    field.setName(name);
  //    field.setDescription(value);
  //
  //    return field;
  //  }

}
