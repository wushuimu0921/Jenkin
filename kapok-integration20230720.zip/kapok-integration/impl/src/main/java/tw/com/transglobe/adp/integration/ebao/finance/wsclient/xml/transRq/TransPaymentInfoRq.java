
package tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRq;

import lombok.Getter;
import lombok.Setter;

import javax.xml.bind.annotation.*;
import java.time.LocalDate;

/**
 * <p>
 * transPaymentInfoRq complex type 的 Java 類別.
 *
 * <p>
 * 下列綱要片段會指定此類別中包含的預期內容.
 *
 * <pre>
 * &lt;complexType name="transPaymentInfoRq"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PaymentDate" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="PolicyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "transPaymentInfoRq", propOrder = {
    "paymentDate",
    "policyCode"
})
@Getter
@Setter
@XmlRootElement(name = "GITransPaymentInfoRq")
public class TransPaymentInfoRq {

  @XmlElement(name = "PaymentDate", required = true)
  protected String paymentDate;
  @XmlElement(name = "PolicyCode")
  protected String policyCode;

}
