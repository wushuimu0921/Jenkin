package tw.com.transglobe.adp.integration.ebao.policy.wsclient;

import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.NullValueCheckStrategy;
import tw.com.transglobe.adp.integration.ebao.policy.service.EbaoPolicyCommonVo;
import tw.com.transglobe.adp.integration.ebao.policy.wsclient.xml.EffectPolicyDataVO;

@Mapper(nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
public interface EbaoPolicyWsMapper {

  @Mapping(target = "policyNo", source = "policyCode")
  @Mapping(target = "birthday", source = "birthdate")
  @Mapping(target = "localName", source = "name")
  EbaoPolicyCommonVo toPolicyVo(EffectPolicyDataVO policyDataVo);

  List<EbaoPolicyCommonVo> toPolicyVoList(List<EffectPolicyDataVO> policyDataList);

}
