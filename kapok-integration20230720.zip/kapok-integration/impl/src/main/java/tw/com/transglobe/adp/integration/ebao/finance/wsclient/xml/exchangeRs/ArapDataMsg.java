package tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.exchangeRs;

import javax.xml.bind.annotation.*;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "arapDataMsg", propOrder = {
    "dataSeq",
    "dataMsgCode",
    "dataMsg",
    "ebaoFeeId",
    "refId",
    "eventMsgs"
})
public class ArapDataMsg {

  @XmlElement(name = "DataSeq")
  protected Integer dataSeq; // Arap的流水號

  @XmlElement(name = "DataMsgCode")
  protected String dataMsgCode; // Arap資料執行結果

  @XmlElement(name = "DataMsg")
  protected String dataMsg; // Cash資料執行結果說明

  @XmlElement(name = "EbaoFeeId")
  protected Long ebaoFeeId; // 儲存後的eBao流水號

  @XmlElement(name = "RefId")
  protected String refId; // 團旅險提供的資料

  @XmlElementWrapper(name = "EventMsgs")
  @XmlElement(name = "EventMsg")
  protected List<EventMsg> eventMsgs; // 檢核或錯誤事件主檔

  public Integer getDataSeq() {
    return dataSeq;
  }

  public void setDataSeq(Integer dataSeq) {
    this.dataSeq = dataSeq;
  }

  public String getDataMsgCode() {
    return dataMsgCode;
  }

  public void setDataMsgCode(String dataMsgCode) {
    this.dataMsgCode = dataMsgCode;
  }

  public String getDataMsg() {
    return dataMsg;
  }

  public void setDataMsg(String dataMsg) {
    this.dataMsg = dataMsg;
  }

  public Long getEbaoFeeId() {
    return ebaoFeeId;
  }

  public void setEbaoFeeId(Long ebaoFeeId) {
    this.ebaoFeeId = ebaoFeeId;
  }

  public String getRefId() {
    return refId;
  }

  public void setRefId(String refId) {
    this.refId = refId;
  }

  public List<EventMsg> getEventMsgs() {
    return eventMsgs;
  }

  public void setEventMsgs(List<EventMsg> eventMsgs) {
    this.eventMsgs = eventMsgs;
  }

  @Override
  public String toString() {
    return "ArapDataMsg{" +
        "dataSeq=" + dataSeq +
        ", dataMsgCode='" + dataMsgCode + '\'' +
        ", dataMsg='" + dataMsg + '\'' +
        ", ebaoFeeId=" + ebaoFeeId +
        ", refId=" + refId +
        ", eventMsgs=" + eventMsgs +
        '}';
  }
}
