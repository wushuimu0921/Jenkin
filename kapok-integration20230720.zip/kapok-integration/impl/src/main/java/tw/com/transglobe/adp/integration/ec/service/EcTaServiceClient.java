package tw.com.transglobe.adp.integration.ec.service;

import tw.com.transglobe.adp.integration.ec.service.cmd.EcTaPolicyPrintReplyCmd;

public interface EcTaServiceClient {

  public EcTaResultVo policyPrintReply(EcTaPolicyPrintReplyCmd cmd);

}
