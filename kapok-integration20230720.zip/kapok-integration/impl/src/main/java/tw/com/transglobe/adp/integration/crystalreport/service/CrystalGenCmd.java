package tw.com.transglobe.adp.integration.crystalreport.service;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;
import tw.com.transglobe.adp.integration.commons.enums.ReportType;

@Data
@Builder
public class CrystalGenCmd {

  @Schema(description = "報表類別")
  ReportType reportType;

  @Schema(description = "查詢條件 reportId")
  String reportId;

  @Schema(description = "使用者 AD 帳號")
  String userAccount;
}
