package tw.com.transglobe.adp.integration.ebao.finance.service.transPosting;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EbaoTransPostingInfoVo {

  @Schema(description = "查詢提供的日期")
  LocalDate postingDate;

  @Schema(description = "查詢提供的RefId")
  String refId;

  @Schema(description = "查詢的結果")
  String responseCode;

  @Schema(description = "查詢結果說明")
  String responseDesc;

  @Schema(description = "現金付款過帳結果")
  EbaoTransPostingCashPayPostingVo cashPayPosting;

  @Schema(description = "現金收款過帳結果")
  EbaoTransPostingCashColPostingVo cashColPosting;

  @Schema(description = "應收應付過帳結果")
  EbaoTransPostingArapPostingVo arapPosting;

  @Schema(description = "佣金過帳結果")
  EbaoTransPostingCommisionPostingVo commisionPosting;
}