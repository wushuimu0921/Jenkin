package tw.com.transglobe.adp.integration.ebao.rest.service;

import java.util.List;
import org.springframework.stereotype.Service;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import tw.com.softleader.data.security.guardium.annotation.Safeguard;

@Slf4j
@Service
@RequiredArgsConstructor
@Safeguard
public class EbaoRestService {

  final EbaoRestServiceClient client;

  public List<EbaoRestQmlistVo> getQmlist(EbaoRestQmlistCriteria criteria) {
    log.debug("EbaoRestService.getQmlist criteria:{}", criteria);
    return client.getQmlist(criteria);
  }

}
