package tw.com.transglobe.adp.integration.ebao.policy.http;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RestController;
import tw.com.transglobe.adp.integration.commons.enums.ProductGroupType;
import tw.com.transglobe.adp.integration.ebao.policy.http.dto.EbaoPolicyDto;
import tw.com.transglobe.adp.integration.ebao.policy.service.EbaoPolicyCommonService;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
class EbaoPolicyCommonWsController implements EbaoPolicyCommonWsApi {

  final EbaoPolicyCommonService service;

  final EbaoPolicyDtoMapper mapper;

  @Override
  public List<EbaoPolicyDto> queryPolicyByIdno(ProductGroupType productGroupType, String idno) {
    return mapper.fromVoList(service.getPolicy(productGroupType, idno));
  }

}
