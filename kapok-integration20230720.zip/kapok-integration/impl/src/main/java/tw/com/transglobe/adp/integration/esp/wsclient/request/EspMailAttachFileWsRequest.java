package tw.com.transglobe.adp.integration.esp.wsclient.request;

import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
@Builder
public class EspMailAttachFileWsRequest {

  @NotNull
  EspHeader header;

  @NotNull
  EspRequesterInfo requesterInfo;

  @NotNull
  EspPolicyHolderInfo policyHolderInfo;

  @NotNull
  EspMessageInfo messageInfo;

  EspTemplateInfo templateInfo;

  EspEventInfo eventInfo;

}
