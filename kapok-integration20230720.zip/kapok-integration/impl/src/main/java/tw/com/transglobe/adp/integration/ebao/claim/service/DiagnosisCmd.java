package tw.com.transglobe.adp.integration.ebao.claim.service;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DiagnosisCmd {
  String diagnosisCode;

  String diagnosisName;
}
