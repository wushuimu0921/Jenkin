package tw.com.transglobe.adp.integration.ebao.claim.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tw.com.softleader.data.security.guardium.annotation.Safeguard;
import tw.com.transglobe.adp.integration.commons.enums.ProductGroupType;

@Slf4j
@Transactional
@Service
@RequiredArgsConstructor
@Safeguard
public class EbaoClaimCommonService {

  final EbaoClaimCommonWsClient client;

  public ClaimRecordQuery071RsCmd queryClaim(ProductGroupType productGroupType, ClaimRecordQuery071RqCmd rq) {
    return client.clm071(productGroupType, rq);
  }
}
