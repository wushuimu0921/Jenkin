
package tw.com.transglobe.adp.integration.aml.wsclient;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * head complex type 的 Java 類別.
 *
 * <p>
 * 下列綱要片段會指定此類別中包含的預期內容.
 *
 * <pre>
 * &lt;complexType name="head"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="AppCode" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="Unit" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="CallType" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="Category" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="MessageID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Fmt" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="Usercode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Userdata" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "head", propOrder = {
    "appCode",
    "unit",
    "callType",
    "category",
    "messageID",
    "fmt",
    "usercode",
    "userdata",
    "retCode",
    "errMsg"
})
public class Head {

  @XmlElement(name = "AppCode", required = true)
  protected String appCode;
  @XmlElement(name = "Unit", required = true)
  protected String unit;
  @XmlElement(name = "CallType", required = true)
  protected String callType;
  @XmlElement(name = "Category")
  protected String category;
  @XmlElement(name = "MessageID")
  protected String messageID;
  @XmlElement(name = "Fmt", required = true)
  protected String fmt;
  @XmlElement(name = "Usercode")
  protected String usercode;
  @XmlElement(name = "Userdata")
  protected String userdata;
  @XmlElement(name = "RetCode")
  protected Integer retCode;
  @XmlElement(name = "ErrMsg")
  protected String errMsg;

  /**
   * 取得 appCode 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getAppCode() {
    return appCode;
  }

  /**
   * 設定 appCode 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setAppCode(String value) {
    this.appCode = value;
  }

  /**
   * 取得 unit 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getUnit() {
    return unit;
  }

  /**
   * 設定 unit 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setUnit(String value) {
    this.unit = value;
  }

  /**
   * 取得 callType 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getCallType() {
    return callType;
  }

  /**
   * 設定 callType 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCallType(String value) {
    this.callType = value;
  }

  /**
   * 取得 category 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getCategory() {
    return category;
  }

  /**
   * 設定 category 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCategory(String value) {
    this.category = value;
  }

  /**
   * 取得 messageID 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getMessageID() {
    return messageID;
  }

  /**
   * 設定 messageID 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setMessageID(String value) {
    this.messageID = value;
  }

  /**
   * 取得 fmt 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getFmt() {
    return fmt;
  }

  /**
   * 設定 fmt 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setFmt(String value) {
    this.fmt = value;
  }

  /**
   * 取得 usercode 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getUsercode() {
    return usercode;
  }

  /**
   * 設定 usercode 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setUsercode(String value) {
    this.usercode = value;
  }

  /**
   * 取得 userdata 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getUserdata() {
    return userdata;
  }

  /**
   * 設定 userdata 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setUserdata(String value) {
    this.userdata = value;
  }

  public Integer getRetCode() {
    return retCode;
  }

  public void setRetCode(Integer retCode) {
    this.retCode = retCode;
  }

  public String getErrMsg() {
    return errMsg;
  }

  public void setErrMsg(String errMsg) {
    this.errMsg = errMsg;
  }

}
