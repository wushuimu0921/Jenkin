package tw.com.transglobe.adp.integration.ebao.common.wsclient;

import com.sun.xml.txw2.output.DataWriter;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import tw.com.transglobe.adp.integration.config.AdpIntegrationProperties;
import tw.com.transglobe.adp.integration.ebao.common.service.EbaoCommonWsClient;
import tw.com.transglobe.adp.integration.ebao.common.service.vo.EbaoCommonRequestVo;
import tw.com.transglobe.adp.integration.ebao.common.service.vo.EbaoCommonResponseVo;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.UUID;

@Component
@Slf4j
@RequiredArgsConstructor
public class EbaoGenericWsClientImpl implements EbaoCommonWsClient {
  final AdpIntegrationProperties properties;
  final EbaoMapper mapper;

  @SneakyThrows
  @Override
  public EbaoCommonResponseVo exchange(EbaoCommonRequestVo commonRequest) {
    CommonWSService serviceImpl = new CommonWSService(new URL(properties.getEbaoClaimWs().getUrl()));
    CommonWS service = serviceImpl.getCommonWSServicePort();

    StandardRequest request = new StandardRequest();
    RqHeader header = new RqHeader();

    LocalDateTime now = LocalDateTime.now();
    header.setRqTimestamp(now);
    header.setRqUID(UUID.randomUUID().toString());

    request.setRqHeader(header);
    request.setServiceName(commonRequest.getServiceName());
    request.setSystemCode(commonRequest.getSystemCode());
    request.setRqBody(commonRequest.getRqBody());

    StandardResponse response = service.exchange(request);

    log.debug("the response is {}", response);
    return mapper.toResponse(response);
  }
}
