package tw.com.transglobe.adp.integration.esp.wsclient.impl;

import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import tw.com.transglobe.adp.integration.config.AdpIntegrationProperties;
import tw.com.transglobe.adp.integration.esp.service.cmd.EspSmsMessageCmd;
import tw.com.transglobe.adp.integration.esp.service.client.EspSmsMessageWebServiceClient;
import tw.com.transglobe.adp.integration.esp.wsclient.EspSmsMessageFeignClient;
import tw.com.transglobe.adp.integration.esp.wsclient.request.EspEventInfo;
import tw.com.transglobe.adp.integration.esp.wsclient.request.EspHeader;
import tw.com.transglobe.adp.integration.esp.wsclient.request.EspPolicyHolderInfo;
import tw.com.transglobe.adp.integration.esp.wsclient.request.EspRequesterInfo;
import tw.com.transglobe.adp.integration.esp.wsclient.request.EspSmsMessageInfo;
import tw.com.transglobe.adp.integration.esp.wsclient.request.EspSmsMessageWsRequest;
import tw.com.transglobe.adp.integration.esp.wsclient.request.EspTemplateInfo;
import tw.com.transglobe.adp.integration.esp.wsclient.response.EspSmsResponse;

@Slf4j
@RequiredArgsConstructor
public class EspSmsMessageWebServiceClientImpl implements EspSmsMessageWebServiceClient {

  final EspSmsMessageFeignClient feignClient;

  final AdpIntegrationProperties properties;

  @SneakyThrows
  @Override
  public String sendSmsMessage(EspSmsMessageCmd cmd) {
    EspSmsMessageWsRequest wsRequest = EspSmsMessageWsRequest.builder()
        .header(getHeader(cmd))
        .requesterInfo(getRequesterInfo(cmd))
        .policyHolderInfo(getPolicyHolderInfo(cmd))
        .messageInfo(getMessageInfo(cmd))
        .templateInfo(getTemplateInfo(cmd))
        .eventInfo(getEventInfo(cmd))
        .build();

    log.debug("SendSmsMessage url:{}", properties.getEspSmsMessage().getUrl());
    log.debug("SendSmsMessage wsRequest:{}", wsRequest);
    EspSmsResponse response = feignClient.sendSmsMessage(wsRequest);
    String returnCode = response.getHeader() != null ? response.getHeader().getReturnCode() : "";
    log.debug("SendSmsMessage returnCode = {}", returnCode);
    return returnCode;
  }

  private EspHeader getHeader(EspSmsMessageCmd cmd) {
    return EspHeader.builder()
        .requesterSystem("ADP")
        .requesterID(cmd.getProductGroupType().name())
        .requesterPwd(null)
        .build();
  }

  private EspRequesterInfo getRequesterInfo(EspSmsMessageCmd cmd) {
    return EspRequesterInfo.builder()
        .contactSysId("ADP-" + cmd.getProductGroupType().name())
        .contactSysOperatorId(cmd.getContactSysOperatorId())
        .contactSysOperatorName(cmd.getContactSysOperatorName())
        .functionCategory(cmd.getFunctionCategory())
        .functionName(cmd.getFunctionName())
        .build();
  }

  private EspPolicyHolderInfo getPolicyHolderInfo(EspSmsMessageCmd cmd) {
    return EspPolicyHolderInfo.builder()
        .policyNo(cmd.getPolicyNo())
        .proposerId(cmd.getProposerId())
        .insuredId(cmd.getInsuredId())
        .beneficiaryId(cmd.getBeneficiaryId())
        .build();
  }

  private EspSmsMessageInfo getMessageInfo(EspSmsMessageCmd cmd) {
    return EspSmsMessageInfo.builder()
        .referenceId(String.valueOf(cmd.getReferenceId()))
        .destPhoneNo(cmd.getDestPhoneNo())
        .msgData(cmd.getMsgData())
        .chargeCode(StringUtils.isNotBlank(cmd.getChargeCode()) ? cmd.getChargeCode() : "UNB")
        .build();
  }

  /**
   * 不會用到模板，整個TemplateInfo給null，不然API會判斷以為需要模板
   */
  private EspTemplateInfo getTemplateInfo(EspSmsMessageCmd cmd) {
    return null;
  }

  private EspEventInfo getEventInfo(EspSmsMessageCmd cmd) {
    return EspEventInfo.builder()
        .eventId(cmd.getEventId())
        .build();
  }

}
