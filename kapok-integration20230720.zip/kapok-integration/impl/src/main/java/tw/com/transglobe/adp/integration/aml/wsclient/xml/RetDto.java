package tw.com.transglobe.adp.integration.aml.wsclient.xml;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
@XmlRootElement(name = "ret")
@XmlAccessorType(XmlAccessType.FIELD)
public class RetDto {
  @XmlElement(name = "HitCount", required = true)
  protected String hitCount;
  @XmlElement(name = "DecType", required = true)
  protected String decType;
  @XmlElement(name = "DecState", required = true)
  protected String decState;
  @XmlElement(name = "DecDate", required = true)
  protected String decDate;
  @XmlElement(name = "DecBy", required = true)
  protected String decBy;
  @XmlElement(name = "DecComments", required = true)
  protected String decComments;
}
