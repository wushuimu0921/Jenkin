package tw.com.transglobe.adp.integration.esp.wsclient.impl;

import com.google.common.collect.Lists;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import tw.com.transglobe.adp.integration.esp.service.cmd.EspMailAttachFileCmd;
import tw.com.transglobe.adp.integration.esp.service.FileUploadService;
import tw.com.transglobe.adp.integration.esp.service.UploadFileVo;
import tw.com.transglobe.adp.integration.esp.service.client.EspMailAttachFileWebServiceClient;
import tw.com.transglobe.adp.integration.esp.wsclient.EspMailAttachFeignClient;
import tw.com.transglobe.adp.integration.esp.wsclient.request.EspAttachFileInfo;
import tw.com.transglobe.adp.integration.esp.wsclient.request.EspAttachInfo;
import tw.com.transglobe.adp.integration.esp.wsclient.request.EspEventInfo;
import tw.com.transglobe.adp.integration.esp.wsclient.request.EspHeader;
import tw.com.transglobe.adp.integration.esp.wsclient.request.EspMailAttachFileWsRequest;
import tw.com.transglobe.adp.integration.esp.wsclient.request.EspMessageInfo;
import tw.com.transglobe.adp.integration.esp.wsclient.request.EspPolicyHolderInfo;
import tw.com.transglobe.adp.integration.esp.wsclient.request.EspRequesterInfo;
import tw.com.transglobe.adp.integration.esp.wsclient.request.EspTemplateInfo;

import java.io.IOException;
import java.util.Base64;
import java.util.List;

@Slf4j
@RequiredArgsConstructor
@Component
public class EspMailAttachFileWebServiceClientImpl implements EspMailAttachFileWebServiceClient {

  final EspMailAttachFeignClient feignClient;
  final FileUploadService fileUploadService;

  @SneakyThrows
  @Override
  public String sendMailAttach(EspMailAttachFileCmd cmd) {

    // test:存到本地電腦 C:\file-download\
    //    try {
    //      var timeStamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd HHmmss"));
    //      var download = fileUploadService.download(cmd.getFileKey(), cmd.getFilePath());
    //      Path path = Paths.get("C:\\file-download\\" + timeStamp + cmd.getQuotationNo() + ".pdf");
    //      Files.write(path, download);
    //    } catch (IOException e) {
    //      e.printStackTrace();
    //    }

    // 從PV下載附件resource
    EspMailAttachFileWsRequest wsRequest = EspMailAttachFileWsRequest.builder()
        .header(getHeader(cmd))
        .requesterInfo(getRequesterInfo(cmd))
        .policyHolderInfo(getPolicyHolderInfo(cmd))
        .messageInfo(getMessageInfo(cmd))
        //        .templateInfo(getTemplateInfo(cmd))
        .eventInfo(getEventInfo(cmd))
        .build();

    String result = feignClient.sendMailAttach(wsRequest);
    log.debug("SendEmail result = {}", result);

    return result;
  }

  private EspHeader getHeader(EspMailAttachFileCmd cmd) {
    return EspHeader.builder()
        .requesterSystem("ADP")
        .requesterID("GI")
        //        .requesterPwd(null)
        .build();
  }

  private EspRequesterInfo getRequesterInfo(EspMailAttachFileCmd cmd) {
    return EspRequesterInfo.builder()
        .contactSysId("ADP-GI")
        .contactSysOperatorId("QOT")
        .contactSysOperatorName("計劃書")
        .functionCategory("EMAIL")
        .functionName("EMAIL")
        .build();
  }

  private EspPolicyHolderInfo getPolicyHolderInfo(EspMailAttachFileCmd cmd) {
    return EspPolicyHolderInfo.builder()
        .policyNo(cmd.getQuotationNo())
        .proposerId(cmd.getApplicantIdno())
        //        .insuredId(null)
        //        .beneficiaryId(null)
        .build();
  }

  private EspMessageInfo getMessageInfo(EspMailAttachFileCmd cmd) throws IOException {
    List<EspAttachFileInfo> fileInfos = Lists.newArrayList();

    if (!CollectionUtils.isEmpty(cmd.getFiles())) {
      for (UploadFileVo file : cmd.getFiles()) {
        String fileName = file.getFileName();
        log.info("full file name is {}", fileName);
        String extName = file.getExtName();

        var resource = fileUploadService.getResource(file.getPvcFileKey(), file.getPvcPaths());

        EspAttachFileInfo fileInfo = EspAttachFileInfo
            .builder()
            .attachFileName(fileName)
            .attachFileNameExt(extName)
            .attachFileContent(Base64.getEncoder().encodeToString(resource.getInputStream().readAllBytes()))
            .attachFileCert(cmd.getFilePassword())
            .build();

        fileInfos.add(fileInfo);
      }
    }

    EspAttachInfo attachInfo = EspAttachInfo.builder()
        //        .doZip(false)
        //        .zipCert(null)
        //        .zipFileName(null)
        .attachFileInfos(fileInfos)
        .build();

    return EspMessageInfo.builder()
        .referenceId(String.valueOf(cmd.getPolicyId()))
        .subject(cmd.getMailSubject())
        .msgData(cmd.getMailContent())
        .fromAddress(cmd.getSenderEmail())
        .fromName(cmd.getSenderName())
        .toAddress(List.of(cmd.getContactEmail()))
        .attachInfo(attachInfo)
        .build();
  }

  private EspTemplateInfo getTemplateInfo(EspMailAttachFileCmd cmd) {
    return EspTemplateInfo.builder()
        .templateId(null)
        .templateXmlVar(null)
        .build();
  }

  private EspEventInfo getEventInfo(EspMailAttachFileCmd cmd) {

    return EspEventInfo.builder()
        .eventId(cmd.getEventCode())
        .build();
  }

}
