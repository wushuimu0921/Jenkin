@javax.xml.bind.annotation.XmlSchema(namespace = "http://webservice.lyods.com/")
package tw.com.transglobe.adp.integration.aml.wsclient;
