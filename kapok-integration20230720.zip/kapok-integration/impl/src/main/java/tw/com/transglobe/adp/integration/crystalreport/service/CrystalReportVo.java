package tw.com.transglobe.adp.integration.crystalreport.service;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CrystalReportVo {
  byte[] file;
}
