package tw.com.transglobe.adp.integration.ebao.finance.service;

import lombok.Builder;
import lombok.Data;
import tw.com.transglobe.adp.integration.commons.enums.Status;

@Data
@Builder
public class EbaoCommonResponseVo {

  Status status;

  String message;
}
