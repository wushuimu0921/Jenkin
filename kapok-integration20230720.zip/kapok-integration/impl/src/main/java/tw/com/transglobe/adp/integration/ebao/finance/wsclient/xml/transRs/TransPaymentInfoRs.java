
package tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRs;

import java.time.LocalDate;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import tw.com.transglobe.adp.integration.ebao.common.wsclient.SlashLocalDateAdapter;

@ToString
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "transPaymentInfoRs", propOrder = {
    "paymentDate",
    "policyCode",
    "paymentResultInfo"
})
@XmlRootElement(name = "GlTransPaymentInfoRs")
public class TransPaymentInfoRs {

  @XmlElement(name = "PaymentDate")
  @XmlJavaTypeAdapter(SlashLocalDateAdapter.class)
  protected LocalDate paymentDate;

  @XmlElement(name = "PolicyCode")
  protected String policyCode;

  @XmlElement(name = "PaymentResultInfo")
  protected PaymentResultInfo paymentResultInfo;

  @XmlAccessorType(XmlAccessType.FIELD)
  @XmlType(name = "paymentResultInfo", propOrder = {
      "totalCount",
      "failCount",
      "successCount",
      "unpaidCount",
      "paymentFailResults"
  })
  @Data
  public static class PaymentResultInfo {
    @XmlElement(name = "TotalCount")
    protected Integer totalCount;

    @XmlElement(name = "FailCount")
    protected Integer failCount;

    @XmlElement(name = "SuccessCount")
    protected Integer successCount;

    @XmlElement(name = "UnpaidCount")
    protected Integer unpaidCount;

    @XmlElementWrapper(name = "PaymentFailResults")
    @XmlElement(name = "PaymentFailResult")
    protected List<PaymentFailResult> paymentFailResults;

  }

  @XmlAccessorType(XmlAccessType.FIELD)
  @XmlType(name = "paymentFailResult", propOrder = {
      "paymentIndi",
      "paymentStatus",
      "paymentStatusDesc",
      "paymentDate",
      "dataDate",
      "batchNo",
      "resultCode",
      "resultDesc",
      "resultEbaoDesc",
      "refId",
      "feeId",
      "paymentUserName",
      "paymentUserDeptName",
      "chequeNo",
      "chequeId",
      "chequeStatus",
      "transStatus",
      "transStatusName",
      "rtnRemitReason",
      "rtnRemitReasonName",
      "paymentBranchBankCode",
      "paymentBankCode",
      "paymentBankAccount",
      "paymentBankName",
      "paymentAbbrName"
  })
  @Data
  @ToString
  public static class PaymentFailResult {
    @XmlElement(name = "PaymentIndi")
    protected String paymentIndi; // S : 付款成功, F : 付款失敗, P : 付款中, NULL : 尚未付款
    /**
     * 匯款、信用卡 :
     * 1 : 產生報盤, 2 : 付款中, 3 : 付款中 (已上傳),
     * 4 : 已回銷 (檔案), 5 : 已取消, 6 : 暫停付款, 7 : 已回銷 (人工)
     * 支票 : NULL
     */
    @XmlElement(name = "PaymentStatus")
    protected String paymentStatus;

    @XmlElement(name = "PaymentStatusDesc")
    protected String paymentStatusDesc; // 支票 : NULL

    @XmlElement(name = "PaymentDate")
    @XmlJavaTypeAdapter(SlashLocalDateAdapter.class)
    protected LocalDate paymentDate;

    @XmlElement(name = "DataDate")
    @XmlJavaTypeAdapter(SlashLocalDateAdapter.class)
    protected LocalDate dataDate;

    @XmlElement(name = "BatchNo")
    protected String batchNo;

    @XmlElement(name = "ResultCode")
    protected String resultCode; // 支票 : NULL

    @XmlElement(name = "ResultDesc")
    protected String resultDesc; // 支票 : NULL

    @XmlElement(name = "ResultEbaoDesc")
    protected String resultEbaoDesc;

    @XmlElement(name = "RefId")
    protected String refId;

    @XmlElement(name = "FeeId")
    protected Long feeId;

    @XmlElement(name = "PaymentUserName")
    protected String paymentUserName;

    @XmlElement(name = "PaymentUserDeptName")
    protected String paymentUserDeptName;

    @XmlElement(name = "ChequeNo")
    protected String chequeNo;

    @XmlElement(name = "ChequeId")
    protected Long chequeId;

    @XmlElement(name = "ChequeStatus")
    protected String chequeStatus;

    @XmlElement(name = "TransStatus")
    protected String transStatus;

    @XmlElement(name = "TransStatusName")
    protected String transStatusName;

    @XmlElement(name = "RtnRemitReason")
    protected String rtnRemitReason;

    @XmlElement(name = "RtnRemitReasonName")
    protected String rtnRemitReasonName;

    @XmlElement(name = "PaymentBranchBankCode")
    protected String paymentBranchBankCode;

    @XmlElement(name = "PaymentBankCode")
    protected String paymentBankCode;

    @XmlElement(name = "PaymentBankAccount")
    protected String paymentBankAccount;

    @XmlElement(name = "PaymentBankName")
    protected String paymentBankName;

    @XmlElement(name = "PaymentAbbrName")
    protected String paymentAbbrName;
  }

}
