package tw.com.transglobe.adp.integration.ebao.kmiddle.wsclient;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.NullValueCheckStrategy;
import tw.com.transglobe.adp.integration.commons.enums.ChannelType;
import tw.com.transglobe.adp.integration.commons.enums.ChargePeriod;
import tw.com.transglobe.adp.integration.commons.enums.ChargeType;
import tw.com.transglobe.adp.integration.commons.enums.CheckSource;
import tw.com.transglobe.adp.integration.commons.enums.CoveragePeriod;
import tw.com.transglobe.adp.integration.commons.enums.FeeStatus;
import tw.com.transglobe.adp.integration.commons.enums.FeeType;
import tw.com.transglobe.adp.integration.commons.enums.MoneyId;
import tw.com.transglobe.adp.integration.commons.enums.PayMode;
import tw.com.transglobe.adp.integration.commons.enums.PaySource;
import tw.com.transglobe.adp.integration.commons.enums.PhCertiType;
import tw.com.transglobe.adp.integration.commons.enums.ProdContract;
import tw.com.transglobe.adp.integration.commons.enums.WithdrawType;
import tw.com.transglobe.adp.integration.ebao.kmiddle.service.KmiddleClaimVo;
import tw.com.transglobe.adp.integration.ebao.kmiddle.service.KmiddlePolicyVo;
import tw.com.transglobe.adp.integration.ebao.kmiddle.wsclient.xml.cmn150res.Cmn150OutC1;
import tw.com.transglobe.adp.integration.ebao.kmiddle.wsclient.xml.generated_rs.Cmn130Out;

@Mapper(nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
public interface KmiddleMapper {
  //  @Mapping(target = "agentChannelTypeCode", source = "agentChannelType")
  //  @Mapping(target = "issueChannelTypeCode", source = "issueChannelType")
  //  @Mapping(target = "prodContractName", source = "prodContract", qualifiedByName = "prodContractToLocalName")
  //  TransactionColArapInfo toColArapInfo(EbaoFinanceAparCreateCmd cmd);
  //
  //  @Mapping(target = "agentChannelTypeCode", source = "agentChannelType")
  //  @Mapping(target = "issueChannelTypeCode", source = "issueChannelType")
  //  @Mapping(target = "prodContractName", source = "prodContract", qualifiedByName = "prodContractToLocalName")
  //  TransactionPayArapInfo toPayArapInfo(EbaoFinanceAparCreateCmd cmd);
  //
  //  @Mapping(target = "agentChannelTypeCode", source = "agentChannelType")
  //  CollectionInfo toColInfo(EbaoFinanceCollectionCreateCmd cmd);
  //
  //  PaymentInfo toPayInfo(EbaoFinancePaymentCreatCmd cmd);

  default String dateToStr(LocalDate date) {
    return date.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
  }

  default Integer feeTypeToInt(FeeType fee) {
    return fee.getValue();
  }

  default int payModeToInt(PayMode pay) {
    return pay.getValue();
  }

  default int feeStatusToInt(FeeStatus status) {
    return status.getValue();
  }

  default int MoneyIdToInt(MoneyId id) {
    return id.getValue();
  }

  default Integer paySourceToInt(PaySource source) {
    return source.getValue();
  }

  default String phCertiTypeToString(PhCertiType phCertiType) {
    return phCertiType.getValue();
  }

  default Long channelTypeToLong(ChannelType channelType) {
    return channelType.getOrder();
  }

  default String chargeTypeToInteger(ChargeType chargeType) {
    return chargeType.getValue();
  }

  default String chargePeriodToInteger(ChargePeriod chargePeriod) {
    return chargePeriod.getValue();
  }

  default String coveragePeriodToString(CoveragePeriod coveragePeriod) {
    return coveragePeriod.getValue();
  }

  @Named("prodContractToLocalName")
  default String prodContractToLocalName(ProdContract prodContract) {
    return prodContract.getValue();
  }

  default String withdrawTypeToString(WithdrawType withdrawType) {
    return withdrawType.getValue();
  }

  default Integer checkSourceToInteger(CheckSource checkSource) {
    return checkSource.getValue();
  }

  KmiddleClaimVo toVo(Cmn130Out out);

  @Mapping(target = "policyNo", source = "policyCode")
  List<KmiddlePolicyVo> toVo(List<Cmn150OutC1> out);

}
