package tw.com.transglobe.adp.integration.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import lombok.Data;

@Data
@ConfigurationProperties(prefix = "transglobe.integration")
public class AdpIntegrationProperties {

  AddrFmt addrFmt = new AddrFmt();
  Aml aml = new Aml();
  EbaoFinanceWs ebaoFinanceWs = new EbaoFinanceWs();
  EbaoClaimWs ebaoClaimWs = new EbaoClaimWs();
  EbaoPolicyWs ebaoPolicyWs = new EbaoPolicyWs();
  KMiddleWs kMiddleWs = new KMiddleWs();
  CrystalReport crystalReport = new CrystalReport();
  EspEmailAttach espEmailAttach = new EspEmailAttach();
  Stakeholder stakeholder = new Stakeholder();
  EspSmsMessage espSmsMessage = new EspSmsMessage();
  EbaoRestQmlist ebaoRestQmlist = new EbaoRestQmlist();
  EcTa ecTa = new EcTa();
  Ciben ciben = new Ciben();

  //"${transglobe.integration.ebao-common-ws.url}"
  @Data
  public static class AddrFmt {
    String url;
  }

  @Data
  public static class Aml {
    String url;
  }

  @Data
  public static class EbaoFinanceWs {
    String url;
  }

  @Data
  public static class EbaoClaimWs {
    String url;
  }

  @Data
  public static class EbaoPolicyWs {
    String url;
  }

  @Data
  public static class KMiddleWs {
    String url;
  }

  @Data
  public static class CrystalReport {
    String moduleName;
  }

  @Data
  public static class EspEmailAttach {
    String url;
  }

  @Data
  public static class Stakeholder {
    String path;
  }

  @Data
  public static class EspSmsMessage {
    String url;
  }

  @Data
  public static class EbaoRestQmlist {
    String url;
  }

  @Data
  public static class EcTa {
    String url;
  }

  @Data
  public static class Ciben {
    String filePath;
  }
}
