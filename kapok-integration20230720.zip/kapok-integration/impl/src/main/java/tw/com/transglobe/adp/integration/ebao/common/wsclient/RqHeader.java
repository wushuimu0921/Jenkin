package tw.com.transglobe.adp.integration.ebao.common.wsclient;

import java.time.LocalDateTime;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * <p>
 * rqHeader complex type �� Java ���O.
 *
 * <p>
 * �U�C���n���q�|���w�����O���]�t���w�����e.
 *
 * <pre>
 * &lt;complexType name="rqHeader">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="custID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="prevReturnCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="prevReturnMsg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="prevRqUID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="rqTimestamp" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="rqUID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "rqHeader", propOrder = {
    "custID",
    "prevReturnCode",
    "prevReturnMsg",
    "prevRqUID",
    "rqTimestamp",
    "rqUID"
})
public class RqHeader {

  protected String custID;
  protected String prevReturnCode;
  protected String prevReturnMsg;
  protected String prevRqUID;
  @XmlSchemaType(name = "dateTime")
  @XmlJavaTypeAdapter(ISODateTimeAdapter.class)
  protected LocalDateTime rqTimestamp;
  protected String rqUID;

  /**
   * ���o custID �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getCustID() {
    return custID;
  }

  /**
   * �]�w custID �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCustID(String value) {
    this.custID = value;
  }

  /**
   * ���o prevReturnCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getPrevReturnCode() {
    return prevReturnCode;
  }

  /**
   * �]�w prevReturnCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setPrevReturnCode(String value) {
    this.prevReturnCode = value;
  }

  /**
   * ���o prevReturnMsg �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getPrevReturnMsg() {
    return prevReturnMsg;
  }

  /**
   * �]�w prevReturnMsg �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setPrevReturnMsg(String value) {
    this.prevReturnMsg = value;
  }

  /**
   * ���o prevRqUID �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getPrevRqUID() {
    return prevRqUID;
  }

  /**
   * �]�w prevRqUID �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setPrevRqUID(String value) {
    this.prevRqUID = value;
  }

  /**
   * ���o rqTimestamp �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link XMLGregorianCalendar }
   *
   */
  public LocalDateTime getRqTimestamp() {
    return rqTimestamp;
  }

  /**
   * �]�w rqTimestamp �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link XMLGregorianCalendar }
   *
   */
  public void setRqTimestamp(LocalDateTime value) {
    this.rqTimestamp = value;
  }

  /**
   * ���o rqUID �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getRqUID() {
    return rqUID;
  }

  /**
   * �]�w rqUID �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setRqUID(String value) {
    this.rqUID = value;
  }

}
