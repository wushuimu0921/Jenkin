package tw.com.transglobe.adp.integration.ebao.claim.wsclient.xml;

import lombok.Getter;
import lombok.Setter;
import tw.com.transglobe.adp.integration.ebao.common.wsclient.LocalDateAdapter;
import javax.xml.bind.annotation.*;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.time.LocalDate;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "medicalBillVO")
@Getter
@Setter
public class MedicalBillVO {

  @XmlElement(required = true)
  protected String hospitalName;

  @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
  protected LocalDate billStartDate;

  @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
  protected LocalDate billEndDate;

  @XmlElement
  protected String receiptTypeCode;

  @XmlElement
  protected Integer limitIndicator;

  @XmlElement
  protected String auditDecision;

  @XmlElement
  protected String auditDecisionDesc;
}
