package tw.com.transglobe.adp.integration.esp.wsclient.request;

import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 *
 * 欲夾檔資訊
 *
 * @author Default User
 *
 */
@Data
@Builder
public class EspAttachInfo {

  boolean doZip;
  String zipCert;
  String zipFileName;

  List<EspAttachFileInfo> attachFileInfos;
}
