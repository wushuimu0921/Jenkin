//
// ���ɮ׬O�� JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.3.0 �Ҳ���
// �аѾ\ <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a>
// �@�����s�sĶ�ӷ����n, �惡�ɮשҰ�������קﳣ�N�|��.
// ���ͮɶ�: 2022.11.22 �� 02:34:48 PM CST
//

package tw.com.transglobe.adp.integration.ebao.policy.wsclient.xml;

import java.time.LocalDate;
import javax.xml.bind.annotation.*;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import javax.xml.datatype.XMLGregorianCalendar;
import tw.com.transglobe.adp.integration.ebao.common.wsclient.LocalDateAdapter;

/**
 * <p>
 * effectPolicyListRq complex type �� Java ���O.
 *
 * <p>
 * �U�C���n���q�|���w�����O���]�t���w�����e.
 *
 * <pre>
 * &lt;complexType name="effectPolicyListRq"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="certiCode" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="birthDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "effectPolicyListRq", propOrder = {
    "certiCode",
    "birthDate"
})
@XmlRootElement
public class EffectPolicyListRq {

  @XmlElement(required = true)
  protected String certiCode;
  //@XmlSchemaType(name = "dateTime")
  @XmlJavaTypeAdapter(LocalDateAdapter.class)
  protected LocalDate birthDate;

  /**
   * ���o certiCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getCertiCode() {
    return certiCode;
  }

  /**
   * �]�w certiCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCertiCode(String value) {
    this.certiCode = value;
  }

  /**
   * ���o birthDate �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link XMLGregorianCalendar }
   *
   */
  public LocalDate getBirthDate() {
    return birthDate;
  }

  /**
   * �]�w birthDate �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link XMLGregorianCalendar }
   *
   */
  public void setBirthDate(LocalDate value) {
    this.birthDate = value;
  }

}
