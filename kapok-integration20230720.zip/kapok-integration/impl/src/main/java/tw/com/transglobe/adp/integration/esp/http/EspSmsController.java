package tw.com.transglobe.adp.integration.esp.http;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RestController;
import tw.com.transglobe.adp.integration.esp.http.req.EspSmsMessageRequest;
import tw.com.transglobe.adp.integration.esp.service.EspSmsService;

@Slf4j
@RestController
@RequiredArgsConstructor
class EspSmsController implements EspSmsApi {

  final EspSmsService service;
  final EspSmsDtoMapper mapper;

  @Override
  public String sendSmsMessage(EspSmsMessageRequest request) {
    return service.sendSmsMessage(mapper.toCmd(request));
  }

}
