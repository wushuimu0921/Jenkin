package tw.com.transglobe.adp.integration.ebao.rest.wsclient;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tw.com.transglobe.adp.integration.ebao.rest.service.EbaoRestServiceClient;

@Slf4j
@Configuration
class EbaoRestServiceClientConfig {

  @Bean
  @ConditionalOnMissingBean
  @ConditionalOnProperty(value = "ebao-rest-client.enabled", havingValue = "false")
  public EbaoRestServiceClient ebaoRestServiceClientOfMock() {
    return new EbaoRestServiceClientMock();
  }

  @Bean
  @ConditionalOnProperty(value = "ebao-rest-client.enabled", havingValue = "true")
  public EbaoRestServiceClient ebaoRestServiceClient(EbaoRestQmlistFeignClient feignClient) {
    return new EbaoRestServiceClientImpl(feignClient);
  }
}
