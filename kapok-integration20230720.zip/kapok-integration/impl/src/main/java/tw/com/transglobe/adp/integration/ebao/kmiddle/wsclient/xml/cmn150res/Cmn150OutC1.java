//
// ���ɮ׬O�� JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.3.0 �Ҳ��� 
// �аѾ\ <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a> 
// �@�����s�sĶ�ӷ����n, �惡�ɮשҰ�������קﳣ�N�|��. 
// ���ͮɶ�: 2022.11.17 �� 02:36:56 PM CST 
//

package tw.com.transglobe.adp.integration.ebao.kmiddle.wsclient.xml.cmn150res;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * <p>
 * cmn150OutC1 complex type �� Java ���O.
 * 
 * <p>
 * �U�C���n���q�|���w�����O���]�t���w�����e.
 * 
 * <pre>
 * &lt;complexType name="cmn150OutC1"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="policyCode" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="devName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="num" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="policyStatus" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="issueDate" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
 *         &lt;element name="renewDate" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
 *         &lt;element name="chargeMode" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="payMode" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="prem" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="paymentDate" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
 *         &lt;element name="companyContact" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="companyTel" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="addr" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="isSelfPay" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="serviceAgent1" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="serviceAgent2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="serviceAgent3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="commAgent1" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="assignRate1" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="commAgent2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="assignRate2" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="commAgent3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="assignRate3" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "cmn150OutC1", propOrder = {
    "policyCode",
    "devName",
    "num",
    "policyStatus",
    "issueDate",
    "renewDate",
    "chargeMode",
    "payMode",
    "prem",
    "paymentDate",
    "companyContact",
    "companyTel",
    "addr",
    "isSelfPay",
    "serviceAgent1",
    "serviceAgent2",
    "serviceAgent3",
    "commAgent1",
    "assignRate1",
    "commAgent2",
    "assignRate2",
    "commAgent3",
    "assignRate3"
})
public class Cmn150OutC1 {

  @XmlElement(required = true)
  protected String policyCode;
  @XmlElement(required = true)
  protected String devName;
  protected int num;
  @XmlElement(required = true)
  protected String policyStatus;
  @XmlElement(required = true)
  @XmlSchemaType(name = "date")
  protected XMLGregorianCalendar issueDate;
  @XmlElement(required = true)
  @XmlSchemaType(name = "date")
  protected XMLGregorianCalendar renewDate;
  @XmlElement(required = true)
  protected String chargeMode;
  @XmlElement(required = true)
  protected String payMode;
  @XmlElement(required = true)
  protected BigDecimal prem;
  @XmlElement(required = true)
  @XmlSchemaType(name = "date")
  protected XMLGregorianCalendar paymentDate;
  @XmlElement(required = true)
  protected String companyContact;
  @XmlElement(required = true)
  protected String companyTel;
  @XmlElement(required = true)
  protected String addr;
  @XmlElement(required = true)
  protected String isSelfPay;
  @XmlElement(required = true)
  protected String serviceAgent1;
  protected String serviceAgent2;
  protected String serviceAgent3;
  @XmlElement(required = true)
  protected String commAgent1;
  @XmlElement(required = true)
  protected BigDecimal assignRate1;
  protected String commAgent2;
  protected BigDecimal assignRate2;
  protected String commAgent3;
  protected BigDecimal assignRate3;

  /**
   * ���o policyCode �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link String }
   * 
   */
  public String getPolicyCode() {
    return policyCode;
  }

  /**
   * �]�w policyCode �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link String }
   * 
   */
  public void setPolicyCode(String value) {
    this.policyCode = value;
  }

  /**
   * ���o devName �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link String }
   * 
   */
  public String getDevName() {
    return devName;
  }

  /**
   * �]�w devName �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link String }
   * 
   */
  public void setDevName(String value) {
    this.devName = value;
  }

  /**
   * ���o num �S�ʪ���.
   * 
   */
  public int getNum() {
    return num;
  }

  /**
   * �]�w num �S�ʪ���.
   * 
   */
  public void setNum(int value) {
    this.num = value;
  }

  /**
   * ���o policyStatus �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link String }
   * 
   */
  public String getPolicyStatus() {
    return policyStatus;
  }

  /**
   * �]�w policyStatus �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link String }
   * 
   */
  public void setPolicyStatus(String value) {
    this.policyStatus = value;
  }

  /**
   * ���o issueDate �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link XMLGregorianCalendar }
   * 
   */
  public XMLGregorianCalendar getIssueDate() {
    return issueDate;
  }

  /**
   * �]�w issueDate �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link XMLGregorianCalendar }
   * 
   */
  public void setIssueDate(XMLGregorianCalendar value) {
    this.issueDate = value;
  }

  /**
   * ���o renewDate �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link XMLGregorianCalendar }
   * 
   */
  public XMLGregorianCalendar getRenewDate() {
    return renewDate;
  }

  /**
   * �]�w renewDate �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link XMLGregorianCalendar }
   * 
   */
  public void setRenewDate(XMLGregorianCalendar value) {
    this.renewDate = value;
  }

  /**
   * ���o chargeMode �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link String }
   * 
   */
  public String getChargeMode() {
    return chargeMode;
  }

  /**
   * �]�w chargeMode �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link String }
   * 
   */
  public void setChargeMode(String value) {
    this.chargeMode = value;
  }

  /**
   * ���o payMode �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link String }
   * 
   */
  public String getPayMode() {
    return payMode;
  }

  /**
   * �]�w payMode �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link String }
   * 
   */
  public void setPayMode(String value) {
    this.payMode = value;
  }

  /**
   * ���o prem �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link BigDecimal }
   * 
   */
  public BigDecimal getPrem() {
    return prem;
  }

  /**
   * �]�w prem �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link BigDecimal }
   * 
   */
  public void setPrem(BigDecimal value) {
    this.prem = value;
  }

  /**
   * ���o paymentDate �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link XMLGregorianCalendar }
   * 
   */
  public XMLGregorianCalendar getPaymentDate() {
    return paymentDate;
  }

  /**
   * �]�w paymentDate �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link XMLGregorianCalendar }
   * 
   */
  public void setPaymentDate(XMLGregorianCalendar value) {
    this.paymentDate = value;
  }

  /**
   * ���o companyContact �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link String }
   * 
   */
  public String getCompanyContact() {
    return companyContact;
  }

  /**
   * �]�w companyContact �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link String }
   * 
   */
  public void setCompanyContact(String value) {
    this.companyContact = value;
  }

  /**
   * ���o companyTel �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link String }
   * 
   */
  public String getCompanyTel() {
    return companyTel;
  }

  /**
   * �]�w companyTel �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link String }
   * 
   */
  public void setCompanyTel(String value) {
    this.companyTel = value;
  }

  /**
   * ���o addr �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link String }
   * 
   */
  public String getAddr() {
    return addr;
  }

  /**
   * �]�w addr �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link String }
   * 
   */
  public void setAddr(String value) {
    this.addr = value;
  }

  /**
   * ���o isSelfPay �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link String }
   * 
   */
  public String getIsSelfPay() {
    return isSelfPay;
  }

  /**
   * �]�w isSelfPay �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link String }
   * 
   */
  public void setIsSelfPay(String value) {
    this.isSelfPay = value;
  }

  /**
   * ���o serviceAgent1 �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link String }
   * 
   */
  public String getServiceAgent1() {
    return serviceAgent1;
  }

  /**
   * �]�w serviceAgent1 �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link String }
   * 
   */
  public void setServiceAgent1(String value) {
    this.serviceAgent1 = value;
  }

  /**
   * ���o serviceAgent2 �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link String }
   * 
   */
  public String getServiceAgent2() {
    return serviceAgent2;
  }

  /**
   * �]�w serviceAgent2 �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link String }
   * 
   */
  public void setServiceAgent2(String value) {
    this.serviceAgent2 = value;
  }

  /**
   * ���o serviceAgent3 �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link String }
   * 
   */
  public String getServiceAgent3() {
    return serviceAgent3;
  }

  /**
   * �]�w serviceAgent3 �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link String }
   * 
   */
  public void setServiceAgent3(String value) {
    this.serviceAgent3 = value;
  }

  /**
   * ���o commAgent1 �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link String }
   * 
   */
  public String getCommAgent1() {
    return commAgent1;
  }

  /**
   * �]�w commAgent1 �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link String }
   * 
   */
  public void setCommAgent1(String value) {
    this.commAgent1 = value;
  }

  /**
   * ���o assignRate1 �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link BigDecimal }
   * 
   */
  public BigDecimal getAssignRate1() {
    return assignRate1;
  }

  /**
   * �]�w assignRate1 �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link BigDecimal }
   * 
   */
  public void setAssignRate1(BigDecimal value) {
    this.assignRate1 = value;
  }

  /**
   * ���o commAgent2 �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link String }
   * 
   */
  public String getCommAgent2() {
    return commAgent2;
  }

  /**
   * �]�w commAgent2 �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link String }
   * 
   */
  public void setCommAgent2(String value) {
    this.commAgent2 = value;
  }

  /**
   * ���o assignRate2 �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link BigDecimal }
   * 
   */
  public BigDecimal getAssignRate2() {
    return assignRate2;
  }

  /**
   * �]�w assignRate2 �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link BigDecimal }
   * 
   */
  public void setAssignRate2(BigDecimal value) {
    this.assignRate2 = value;
  }

  /**
   * ���o commAgent3 �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link String }
   * 
   */
  public String getCommAgent3() {
    return commAgent3;
  }

  /**
   * �]�w commAgent3 �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link String }
   * 
   */
  public void setCommAgent3(String value) {
    this.commAgent3 = value;
  }

  /**
   * ���o assignRate3 �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link BigDecimal }
   * 
   */
  public BigDecimal getAssignRate3() {
    return assignRate3;
  }

  /**
   * �]�w assignRate3 �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link BigDecimal }
   * 
   */
  public void setAssignRate3(BigDecimal value) {
    this.assignRate3 = value;
  }

}
