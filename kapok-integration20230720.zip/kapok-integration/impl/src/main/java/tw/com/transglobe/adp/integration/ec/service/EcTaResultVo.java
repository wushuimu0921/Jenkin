package tw.com.transglobe.adp.integration.ec.service;

import lombok.Data;

@Data
public class EcTaResultVo {

  String status;

  String errorCode;

  String errorMsg;
}
