package tw.com.transglobe.adp.integration.esp.wsclient.request;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EspMailAttachFileInfo {
  String attachFileName;
  String attachFileExt;
  String attachFileContent;
  String attachFileCert;
}
