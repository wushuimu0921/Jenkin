package tw.com.transglobe.adp.integration.ebao.finance.service.exchange;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EbaoExchangeMessage {

  String columnName;

  String systemLength;

  String dataLength;

  String desc;
}
