package tw.com.transglobe.adp.integration.aml.wsclient.xml;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
@XmlRootElement(name = "tm")
@XmlAccessorType(XmlAccessType.FIELD)
public class TmDto {
  @XmlElement(name = "HitType", required = true)
  protected String hitType;
  @XmlElement(name = "DecDate", required = true)
  protected String decDate;
  @XmlElement(name = "DecBy", required = true)
  protected String decby;
  @XmlElement(name = "SusCnt", required = true)
  protected String susCnt;
  @XmlElement(name = "UnsCnt", required = true)
  protected String unsCnt;
  @XmlElement(name = "NewCnt", required = true)
  protected String newCnt;
  @XmlElement(name = "MonCnt", required = true)
  protected String monCnt;
}
