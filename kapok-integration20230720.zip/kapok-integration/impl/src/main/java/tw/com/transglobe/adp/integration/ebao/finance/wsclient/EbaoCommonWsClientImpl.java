package tw.com.transglobe.adp.integration.ebao.finance.wsclient;

import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import tw.com.transglobe.adp.integration.config.AdpIntegrationProperties;
import tw.com.transglobe.adp.integration.ebao.common.wsclient.RqHeader;
import tw.com.transglobe.adp.integration.ebao.common.wsclient.StandardRequest;
import tw.com.transglobe.adp.integration.ebao.common.wsclient.StandardResponse;
import tw.com.transglobe.adp.integration.ebao.finance.service.EbaoCommonWsClient;
import tw.com.transglobe.adp.integration.ebao.finance.service.chequeInfo.EbaoChequeInfoVo;
import tw.com.transglobe.adp.integration.ebao.finance.service.cmd.EbaoFinanceAparCreateCmd;
import tw.com.transglobe.adp.integration.ebao.finance.service.cmd.EbaoFinanceCollectCreateCmd;
import tw.com.transglobe.adp.integration.ebao.finance.service.cmd.EbaoFinanceGetPaymentCmd;
import tw.com.transglobe.adp.integration.ebao.finance.service.cmd.EbaoFinancePayCreateCmd;
import tw.com.transglobe.adp.integration.ebao.finance.service.cmd.EbaoFinanceQueryChequeCmd;
import tw.com.transglobe.adp.integration.ebao.finance.service.cmd.EbaoFinanceTransPostingCmd;
import tw.com.transglobe.adp.integration.ebao.finance.service.exchange.EbaoExchangeResponseVo;
import tw.com.transglobe.adp.integration.ebao.finance.service.transPayment.EbaoTransPaymentInfoVo;
import tw.com.transglobe.adp.integration.ebao.finance.service.transPosting.EbaoTransPostingInfoVo;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.col.CreateTransactionColMixedRq;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.col.CreateTransactionColMixedRq.TransColMixedInfos;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.col.TransactionColArapInfo;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.col.TransactionColMixedInfo;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.col.TransactionColMixedInfo.CollectionInfos;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.col.TransactionColMixedInfo.ReceivableInfos;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.exchangeRs.GlTransRs;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.pay.CreateTransactionPayMixedRq;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.pay.TransactionPayMixedInfo;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRq.QueryChequeInfoRq;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRq.TransPaymentInfoRq;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRq.TransPostingInfoRq;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRs.TransCheckInfoRs;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRs.TransPaymentInfoRs;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRs.TransPostingInfoRs;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Slf4j
@RequiredArgsConstructor
@Component
public class EbaoCommonWsClientImpl implements EbaoCommonWsClient {

  final AdpIntegrationProperties properties;

  final EbaoFinanceWsMapper mapper;

  /**
   * INT-FIN-001 實收 + 應收
   */
  @SneakyThrows
  @Override
  public EbaoExchangeResponseVo exchangeReceivable(String systemCode, String policyNo,
      List<EbaoFinanceAparCreateCmd> aparCreateCmds, List<EbaoFinanceCollectCreateCmd> colCreateCmds) {
    log.debug("policyNo:{} systemCode:{}, 準備開始收款資料送EBAO", policyNo, systemCode);

    TransactionColMixedInfo mixInfo = new TransactionColMixedInfo();
    mixInfo.setTransSeq(1);
    mixInfo.setReceivableInfos(new ReceivableInfos());
    // 應收
    //var arapInfo = mapper.toColArapInfo(aparCreateCmds);
    for (EbaoFinanceAparCreateCmd cmd : aparCreateCmds) {
      TransactionColArapInfo arapInfo = mapper.toColArapInfo(cmd);
      log.debug("arapInfo = {}", arapInfo);
      mixInfo.getReceivableInfos().getReceivableInfo().add(arapInfo);
    }
    log.debug("arap number:{}", mixInfo.getReceivableInfos().getReceivableInfo().size());
    // 實收 List<EbaoFinanceCollectionCreateCmd>
    mixInfo.setCollectionInfos(new CollectionInfos());
    for (EbaoFinanceCollectCreateCmd cmd : colCreateCmds) {
      var cinfo = mapper.toColInfo(cmd);
      // 全球繳費網139、支票跟信用卡128
      if (cinfo.getPayMode() == 95) { // 全國繳費網139
        cinfo.setInternalAccount(139L);
      }
      if (cinfo.getPayMode() == 2 || cinfo.getPayMode() == 94 || cinfo.getPayMode() == 30) { // 票據、回籠票、信用卡128
        cinfo.setInternalAccount(128L);
      }
      if (cinfo.getPayMode() == 30) { // 票據、回籠票、信用卡128
        cinfo.setCreditCardAcquirerId(83L);
      }
      log.debug("collectInfo = {}", cinfo);
      mixInfo.getCollectionInfos().getCollectionInfo().add(cinfo);
    }
    CreateTransactionColMixedRq request = new CreateTransactionColMixedRq();
    request.setTransColMixedInfos(new TransColMixedInfos());
    request.getTransColMixedInfos().getTransColMixedInfo().add(mixInfo);

    JAXBContext jaxbContext = JAXBContext.newInstance(CreateTransactionColMixedRq.class);
    Marshaller marshaller = jaxbContext.createMarshaller();
    marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
    marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);

    StringWriter sw = new StringWriter();
    marshaller.marshal(request, sw);
    String xmlData = sw.toString();
    log.debug("policyNo:{}, 收費資料送ebao, xmlData:{}", policyNo, xmlData);
    var standardResponse = exchange("cashColMixedService", systemCode, xmlData);
    log.debug("policyNo:{}, 收費資料送ebao, response:{}", policyNo, standardResponse);

    log.debug("response.header.returnCode={}", standardResponse.getRsHeader().getReturnCode());
    log.debug("response.header.returnMsg={}", standardResponse.getRsHeader().getReturnMsg());
    GlTransRs response = (GlTransRs) JAXBContext.newInstance(GlTransRs.class).createUnmarshaller()
        .unmarshal(new StringReader(standardResponse.getRsBody()));

    return mapper.toExchangeVo(response);

  }

  /**
   * INT-FIN-002 實付 + 應付
   */
  @SneakyThrows
  @Override
  public EbaoExchangeResponseVo exchangePayable(String systemCode, String policyNo,
      List<EbaoFinanceAparCreateCmd> aparCreateCmds, List<EbaoFinancePayCreateCmd> payCreateCmds) {

    TransactionPayMixedInfo mixInfo = new TransactionPayMixedInfo();

    mixInfo.setTransSeq(1);
    mixInfo.setPayableInfos(new TransactionPayMixedInfo.PayableInfos());
    mixInfo.setPaymentInfos(new TransactionPayMixedInfo.PaymentInfos());

    if (aparCreateCmds != null) {
      for (EbaoFinanceAparCreateCmd cmd : aparCreateCmds) {
        mixInfo.getPayableInfos().getPayableInfo().add(mapper.toPayArapInfo(cmd));
      }
    }

    if (payCreateCmds != null) {
      for (EbaoFinancePayCreateCmd cmd : payCreateCmds) {
        mixInfo.getPaymentInfos().getPaymentInfo().add(mapper.toPayInfo(cmd));
      }
    }

    CreateTransactionPayMixedRq request = new CreateTransactionPayMixedRq();
    request.setTransPayMixedInfos(new CreateTransactionPayMixedRq.TransPayMixedInfos());
    request.getTransPayMixedInfos().getTransPayMixedInfo().add(mixInfo);

    JAXBContext jaxbContext = JAXBContext.newInstance(CreateTransactionPayMixedRq.class);
    Marshaller marshaller = jaxbContext.createMarshaller();
    marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
    marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);

    StringWriter sw = new StringWriter();
    marshaller.marshal(request, sw);
    String xmlData = sw.toString();

    String sendType = CollectionUtils.isEmpty(aparCreateCmds) ? "實付" : "應付";
    log.debug("policyNo:{}, {}資料送ebao, xmlData:{}", policyNo, sendType, xmlData);
    var standardResponse = exchange("cashPayMixedService", systemCode, xmlData);
    log.debug("policyNo:{}, {}資料送ebao, response:{}", policyNo, sendType, standardResponse);

    log.debug("response.header.returnCode={}", standardResponse.getRsHeader().getReturnCode());
    log.debug("response.header.returnMsg={}", standardResponse.getRsHeader().getReturnMsg());
    GlTransRs response = (GlTransRs) JAXBContext.newInstance(GlTransRs.class).createUnmarshaller()
        .unmarshal(new StringReader(standardResponse.getRsBody()));

    return mapper.toExchangeVo(response);
  }

  /**
   * INT-FIN-003 支票查詢
   */
  @SneakyThrows
  @Override
  public EbaoChequeInfoVo getChequeInfo(String systemCode, EbaoFinanceQueryChequeCmd cmd) {
    //轉成xml
    QueryChequeInfoRq request = mapper.toQueryChequeInfoRq(cmd);
    log.info("request:{}", request);

    JAXBContext jaxbContext = JAXBContext.newInstance(QueryChequeInfoRq.class);
    Marshaller marshaller = jaxbContext.createMarshaller();
    marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
    marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);

    StringWriter sw = new StringWriter();
    marshaller.marshal(request, sw);
    String xmlData = sw.toString();

    log.info("資票查詢，xmlData:{}", xmlData);
    var standardResponse = exchange("queryChequeService", systemCode, xmlData);
    log.info("資票查詢結果:{}", standardResponse);

    log.info("response.header.returnCode={}", standardResponse.getRsHeader().getReturnCode());
    log.debug("response.header.returnMsg={}", standardResponse.getRsHeader().getReturnMsg());
    TransCheckInfoRs response = (TransCheckInfoRs) JAXBContext.newInstance(TransCheckInfoRs.class).createUnmarshaller()
        .unmarshal(new StringReader(standardResponse.getRsBody()));

    return mapper.toChequeInfoVo(response);

  }

  /**
   * INT-FIN-004 付款結果查詢
   */
  @SneakyThrows
  @Override
  public EbaoTransPaymentInfoVo getPaymentResult(String systemCode, EbaoFinanceGetPaymentCmd cmd) {
    TransPaymentInfoRq request = mapper.toTransPaymentInfo(cmd);

    JAXBContext jaxbContext = JAXBContext.newInstance(TransPaymentInfoRq.class);
    Marshaller marshaller = jaxbContext.createMarshaller();
    marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
    marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);

    StringWriter sw = new StringWriter();
    marshaller.marshal(request, sw);
    String xmlData = sw.toString();

    log.info("付款結果查詢，paymentDate:{}, xmlData:{}", cmd.getPaymentDate(), xmlData);
    var standardResponse = exchange("paymentResultService", systemCode, xmlData);
    log.info("付款結果查詢結果:{}", standardResponse);

    log.info("response.header.returnCode={}", standardResponse.getRsHeader().getReturnCode());
    log.debug("response.header.returnMsg={}", standardResponse.getRsHeader().getReturnMsg());
    TransPaymentInfoRs response = (TransPaymentInfoRs) JAXBContext.newInstance(TransPaymentInfoRs.class).createUnmarshaller()
        .unmarshal(new StringReader(standardResponse.getRsBody()));

    return mapper.toPaymentInfoVo(response);

  }

  /**
   * INT-FIN-006 過帳查詢
   */
  @SneakyThrows
  @Override
  public EbaoTransPostingInfoVo getTransPostingInfo(String systemCode, EbaoFinanceTransPostingCmd cmd) {
    TransPostingInfoRq request = mapper.toTransPostingInfo(cmd);

    JAXBContext jaxbContext = JAXBContext.newInstance(TransPostingInfoRq.class);
    Marshaller marshaller = jaxbContext.createMarshaller();
    marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
    marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);

    StringWriter sw = new StringWriter();
    marshaller.marshal(request, sw);
    String xmlData = sw.toString();

    log.info("過帳結果查詢，xmlData:{}", xmlData);
    var standardResponse = exchange("postingResultService", systemCode, xmlData);
    log.info("過帳結果查詢結果:{}", standardResponse);

    log.info("response.header.returnCode={}", standardResponse.getRsHeader().getReturnCode());
    log.debug("response.header.returnMsg={}", standardResponse.getRsHeader().getReturnMsg());
    TransPostingInfoRs response = (TransPostingInfoRs) JAXBContext.newInstance(TransPostingInfoRs.class).createUnmarshaller()
        .unmarshal(new StringReader(standardResponse.getRsBody()));

    return mapper.toPostingInfoVo(response);

  }

  @SneakyThrows
  private StandardResponse exchange(String serviceName, String systemCode, String xmlData) {
    //var resource = new ClassPathResource("wsdl/ebao-common-service.wsdl");
    log.info("EbaoFinanceWs Properties Url:{}", properties.getEbaoFinanceWs().getUrl());
    CommonWSService serviceImpl = new CommonWSService(new URL(properties.getEbaoFinanceWs().getUrl()));
    CommonWS service = serviceImpl.getCommonWSServicePort();

    StandardRequest request = new StandardRequest();
    RqHeader header = new RqHeader();

    LocalDateTime now = LocalDateTime.now();
    header.setRqTimestamp(now);
    header.setRqUID(UUID.randomUUID().toString());

    request.setRqHeader(header);
    request.setServiceName(serviceName);
    request.setSystemCode(systemCode);
    request.setRqBody(xmlData);

    StandardResponse response = service.exchange(request);
    // Status responseStatus = response.getRsHeader().getReturnCode().equals("0000") ? Status.SUCCESS : Status.FAIL;
    return response;
  }

  //  @SneakyThrows
  //  private Object standardResponseToResponse(Class responseClass, StandardResponse response) {
  //    return JAXBContext.newInstance(responseClass)
  //        .createUnmarshaller().unmarshal(
  //            new StringReader(response.getRsBody()));
  //  }

}
