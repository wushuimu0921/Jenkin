package tw.com.transglobe.adp.integration.crystalreport.http;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RestController;
import tw.com.transglobe.adp.integration.crystalreport.http.dto.CrystalReportDto;
import tw.com.transglobe.adp.integration.crystalreport.http.query.CrystalReportRequest;
import tw.com.transglobe.adp.integration.crystalreport.service.CrystalReportService;

@Slf4j
@RestController
@RequiredArgsConstructor
class CrystalReportController implements CrystalReportApi {

  final CrystalReportService crystalReportService;
  final CrystalReportDtoMapper crystalReportDtoMapper;

  @Override
  public CrystalReportDto getCrystalReport(CrystalReportRequest request) {
    return crystalReportDtoMapper.fromVo(crystalReportService.getCrystalreport(crystalReportDtoMapper.toGenCmd(request)));
  }
}
