package tw.com.transglobe.adp.integration.esp.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import tw.com.softleader.data.security.guardium.annotation.Safeguard;
import tw.com.transglobe.adp.integration.esp.service.cmd.EspMailAttachFileCmd;
import tw.com.transglobe.adp.integration.esp.service.cmd.EspMailCmd;
import tw.com.transglobe.adp.integration.esp.service.client.EspMailAttachFileWebServiceClient;
import tw.com.transglobe.adp.integration.esp.service.client.EspMailWebServiceClient;

@Slf4j
@Service
@RequiredArgsConstructor
@Safeguard
public class EspMailService {

  final EspMailAttachFileWebServiceClient mailAttachFileWebServiceClient;

  final EspMailWebServiceClient mailWebServiceClient;

  /**
   * 取得email附件
   *
   * @param cmd-email寄送相關資訊，包含附件的PV位址
   * @return 回傳Esp的回傳訊息 e.g."returnCode: 9000, returnMessage:不支援pdf以外的檔案加密"
   */
  public String sendMailAttach(EspMailAttachFileCmd cmd) {
    log.debug("sendMailAttach cmd:{}", cmd);
    cmd.setEventCode("ADP0001");
    return mailAttachFileWebServiceClient.sendMailAttach(cmd);
  }

  public String sendMail(EspMailCmd cmd) {
    log.debug("sendMail cmd:{}", cmd);
    return mailWebServiceClient.sendMail(cmd);
  }

}
