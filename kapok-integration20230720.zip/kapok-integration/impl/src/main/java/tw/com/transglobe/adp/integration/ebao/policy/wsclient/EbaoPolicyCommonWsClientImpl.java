package tw.com.transglobe.adp.integration.ebao.policy.wsclient;

import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.ws.Binding;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.Handler;
import com.google.common.collect.Lists;
import com.sun.xml.txw2.output.DataWriter;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import tw.com.transglobe.adp.integration.common.ws.SOAPLoggingHandler;
import tw.com.transglobe.adp.integration.commons.enums.ProductGroupType;
import tw.com.transglobe.adp.integration.commons.enums.Status;
import tw.com.transglobe.adp.integration.config.AdpIntegrationProperties;
import tw.com.transglobe.adp.integration.ebao.common.wsclient.RqHeader;
import tw.com.transglobe.adp.integration.ebao.common.wsclient.StandardRequest;
import tw.com.transglobe.adp.integration.ebao.common.wsclient.StandardResponse;
import tw.com.transglobe.adp.integration.ebao.policy.service.EbaoPolicyCommonVo;
import tw.com.transglobe.adp.integration.ebao.policy.service.EbaoPolicyCommonWsClient;
import tw.com.transglobe.adp.integration.ebao.policy.wsclient.xml.EffectPolicyListRq;
import tw.com.transglobe.adp.integration.ebao.policy.wsclient.xml.EffectPolicyListRs;

@Slf4j
@RequiredArgsConstructor
public class EbaoPolicyCommonWsClientImpl implements EbaoPolicyCommonWsClient {

  final AdpIntegrationProperties properties;
  final EbaoPolicyWsMapper mapper;

  @SneakyThrows
  @Override
  public List<EbaoPolicyCommonVo> getPolicy(ProductGroupType productGroupType, String idno) {
    EffectPolicyListRq request = new EffectPolicyListRq();
    request.setCertiCode(idno);

    JAXBContext jaxbContext = JAXBContext.newInstance(EffectPolicyListRq.class);
    Marshaller marshaller = jaxbContext.createMarshaller();
    marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
    marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);
    StringWriter sw = new StringWriter();
    marshaller.marshal(request, sw);

    try {
      StandardResponse response = exchange("wsEffectPolicyListService", productGroupType.toString(), sw.toString());
      log.debug("the response is \n {}", response);
      Status responseStatus = response.getRsHeader().getReturnMsg().equals("success") ? Status.SUCCESS : Status.FAIL;
      log.debug("Ebao Policy response:{}", responseStatus);
      if (response.getRsHeader().getReturnMsg().equals("success")) {
        JAXBContext policyJaxbContext = JAXBContext.newInstance(EffectPolicyListRs.class);
        Unmarshaller unmarshaller = policyJaxbContext.createUnmarshaller();

        EffectPolicyListRs out = (EffectPolicyListRs) unmarshaller.unmarshal(new StringReader(response.getRsBody()));
        log.debug("success EffectPolicyListRs:{}", out);
        if (out != null && out.getEffectPolicyDataList() != null) {

          return mapper.toPolicyVoList(out.getEffectPolicyDataList().getEffectPolicyData());

        }
      }
    } catch (Exception e) {
      log.error("Catched WS error:{}", e);
    }

    return Lists.newArrayList();
  }

  @SneakyThrows
  private StandardResponse exchange(String serviceName, String systemCode, String xmlData) {
    log.debug("xmlData:{}", xmlData);
    //var resource = new ClassPathResource("wsdl/ebao-common-service.wsdl");
    log.info("getEbaoPolicyWs Properties Url:{}", properties.getEbaoPolicyWs().getUrl());
    CommonWSService serviceImpl = new CommonWSService(new URL(properties.getEbaoPolicyWs().getUrl()));
    CommonWS service = serviceImpl.getCommonWSServicePort();

    Binding binding = ((BindingProvider) service).getBinding();
    List<Handler> handlerChain = binding.getHandlerChain();
    handlerChain.add(new SOAPLoggingHandler());
    binding.setHandlerChain(handlerChain);

    StandardRequest request = new StandardRequest();
    RqHeader header = new RqHeader();

    LocalDateTime now = LocalDateTime.now();
    header.setRqTimestamp(now);
    header.setRqUID(UUID.randomUUID().toString());

    request.setRqHeader(header);
    request.setServiceName(serviceName);
    request.setSystemCode(systemCode);
    request.setRqBody(xmlData);

    if (log.isDebugEnabled()) {
      JAXBContext jaxbContext = JAXBContext.newInstance(StandardRequest.class);
      Marshaller marshaller = jaxbContext.createMarshaller();
      marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
      marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);

      StringWriter sw = new StringWriter();
      // for xml data *DO NOT* convert to &lt; &gt; etc.. to escape all characters
      PrintWriter pw = new PrintWriter(sw);
      DataWriter dw = new DataWriter(pw, "UTF-8",
          (buf, start, len, b, out) -> out.write(buf, start, len));

      marshaller.marshal(request, dw);

      String wsData = sw.toString();

      log.debug("xml data:{}", wsData);
    }
    StandardResponse response = service.exchange(request);
    log.debug("the response is {}", response);
    Status responseStatus = response.getRsHeader().getReturnCode().equals("0000") ? Status.SUCCESS : Status.FAIL;
    return response;
  }
  //
  //  @SneakyThrows
  //  private Object standardResponseToResponse(Class responseClass, StandardResponse response) {
  //    return JAXBContext.newInstance(responseClass)
  //        .createUnmarshaller().unmarshal(
  //            new StringReader(response.getRsBody()));
  //  }

}
