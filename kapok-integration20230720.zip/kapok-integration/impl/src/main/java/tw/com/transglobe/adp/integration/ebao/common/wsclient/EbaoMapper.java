package tw.com.transglobe.adp.integration.ebao.common.wsclient;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.mapstruct.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import tw.com.transglobe.adp.integration.commons.enums.*;
import tw.com.transglobe.adp.integration.ebao.common.service.vo.EbaoCommonResponseVo;
import tw.com.transglobe.adp.integration.ebao.finance.service.cmd.EbaoFinanceAparCreateCmd;
import tw.com.transglobe.adp.integration.ebao.finance.service.cmd.EbaoFinanceQueryChequeCmd;
import tw.com.transglobe.adp.integration.ebao.finance.service.cmd.EbaoFinanceTransPostingCmd;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.col.CollectionInfo;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.col.TransactionColArapInfo;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.pay.PaymentInfo;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.pay.TransactionPayArapInfo;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRq.QueryChequeInfoRq;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRq.TransPaymentInfoRq;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRq.TransPostingInfoRq;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRs.TransCheckInfoRs;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRs.TransPaymentInfoRs;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRs.TransPostingInfoRs;
import tw.com.transglobe.adp.integration.ebao.kmiddle.service.cmd.EbaoFinanceCollectionCreateCmd;
import tw.com.transglobe.adp.integration.ebao.kmiddle.service.cmd.EbaoFinancePaymentCreatCmd;
import tw.com.transglobe.adp.integration.ebao.policy.service.EbaoPolicyCommonVo;
import tw.com.transglobe.adp.integration.ebao.policy.wsclient.xml.EffectPolicyDataVO;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Mapper(nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
public interface EbaoMapper {

  Logger log = LoggerFactory.getLogger(EbaoMapper.class.getName());

  @Mapping(target = "agentChannelTypeCode", source = "agentChannelType")
  @Mapping(target = "issueChannelTypeCode", source = "issueChannelType")
  @Mapping(target = "prodContractName", source = "prodContract", qualifiedByName = "prodContractToLocalName")
  TransactionColArapInfo toColArapInfo(EbaoFinanceAparCreateCmd cmd);

  // feeAmount 跟 payAmount 都傳給eBao 正值
  @Mapping(target = "agentChannelTypeCode", source = "agentChannelType")
  @Mapping(target = "issueChannelTypeCode", source = "issueChannelType")
  @Mapping(target = "feeAmount", expression = "java(cmd.getFeeAmount() != null ? cmd.getFeeAmount().abs() : null)")
  @Mapping(target = "payAmount", expression = "java(cmd.getPayAmount() != null ? cmd.getPayAmount().abs() : null)")
  @Mapping(target = "prodContractName", source = "prodContract", qualifiedByName = "prodContractToLocalName")
  TransactionPayArapInfo toPayArapInfo(EbaoFinanceAparCreateCmd cmd);

  @Mapping(target = "creditCardExpireDate", ignore = true)
  @Mapping(target = "agentChannelTypeCode", source = "agentChannelType")
  CollectionInfo toColInfo(EbaoFinanceCollectionCreateCmd cmd);

  @AfterMapping
  default void afterToColInfo(EbaoFinanceCollectionCreateCmd cmd, @MappingTarget CollectionInfo collect) {
    log.info("信用卡截止日:{}", cmd.getCreditCardExpireDate());
    if (StringUtils.length(cmd.getCreditCardExpireDate()) >= 6) {
      int expireDateYear = NumberUtils.toInt(cmd.getCreditCardExpireDate().substring(0, 4));
      int expireDateMonth = NumberUtils.toInt(cmd.getCreditCardExpireDate().substring(4, 6));
      collect.setCreditCardExpireDate(LocalDate.of(expireDateYear, expireDateMonth, 1));
    }
  }

  //  @Mapping(target = "creditCardExpireDate", qualifiedByName = "expireDateChange")
  @Mapping(target = "creditCardExpireDate", ignore = true)
  PaymentInfo toPayInfo(EbaoFinancePaymentCreatCmd cmd);

  @AfterMapping
  default void afterToPayInfo(EbaoFinancePaymentCreatCmd cmd, @MappingTarget PaymentInfo pay) {
    log.info("信用卡截止日:{}", cmd.getCreditCardExpireDate());
    if (StringUtils.length(cmd.getCreditCardExpireDate()) >= 6) {
      int expireDateYear = NumberUtils.toInt(cmd.getCreditCardExpireDate().substring(0, 4));
      int expireDateMonth = NumberUtils.toInt(cmd.getCreditCardExpireDate().substring(4, 6));
      pay.setCreditCardExpireDate(LocalDate.of(expireDateYear, expireDateMonth, 1));
    }
  }

  default String dateToStr(LocalDate date) {
    return date.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
  }

  default Integer feeTypeToInt(FeeType fee) {
    return fee.getValue();
  }

  default int payModeToInt(PayMode pay) {
    return pay.getValue();
  }

  default int feeStatusToInt(FeeStatus status) {
    return status.getValue();
  }

  default int MoneyIdToInt(MoneyId id) {
    return id.getValue();
  }

  default Integer paySourceToInt(PaySource source) {
    return source.getValue();
  }

  default String paySourceToString(PaySource source) {
    return source.getValue().toString();
  }

  default String phCertiTypeToString(PhCertiType phCertiType) {
    return phCertiType.getValue();
  }

  default Long channelTypeToLong(ChannelType channelType) {
    return channelType.getOrder();
  }

  default String chargeTypeToInteger(ChargeType chargeType) {
    return chargeType.getValue();
  }

  default String chargePeriodToInteger(ChargePeriod chargePeriod) {
    return chargePeriod.getValue();
  }

  default String coveragePeriodToString(CoveragePeriod coveragePeriod) {
    return coveragePeriod.getValue();
  }

  @Named("prodContractToLocalName")
  default String prodContractToLocalName(ProdContract prodContract) {
    return prodContract.getValue();
  }

  default String withdrawTypeToString(WithdrawType withdrawType) {
    return withdrawType.getValue();
  }

  default Integer checkSourceToInteger(CheckSource checkSource) {
    return checkSource.getValue();
  }

  @Named("expireDateChange")
  default String expireDateChange(String expDate) {
    String month = expDate.substring(0, 2);
    String year = expDate.substring(2, 4);
    return "20" + year + "/" + month + "/" + "01";
  }

  default LocalDate stringToDate(String date) {
    return LocalDate.parse(date, DateTimeFormatter.ofPattern("yyyy/MM/dd"));
  }

  @Mapping(target = "policyNo", source = "policyCode")
  @Mapping(target = "birthday", source = "birthdate")
  @Mapping(target = "localName", source = "name")
  EbaoPolicyCommonVo toPolicyVo(EffectPolicyDataVO policyDataVo);

  List<EbaoPolicyCommonVo> toPolicyVoList(List<EffectPolicyDataVO> policyDataList);

  QueryChequeInfoRq toQueryChequeInfoRq(EbaoFinanceQueryChequeCmd cmd);

  TransPostingInfoRq toTransPostingInfo(EbaoFinanceTransPostingCmd cmd);

  @Mapping(target = "status", source = "rsHeader.returnCode")
  @Mapping(target = "message", source = "rsHeader.returnMsg")
  EbaoCommonResponseVo toResponse(StandardResponse response);

  default Status toStatus(String returnCode) {
    return switch (returnCode) {
      case "0000" -> Status.SUCCESS;
      default -> Status.FAIL;
    };
  }
}
