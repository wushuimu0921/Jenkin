//
// ���ɮ׬O�� JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.3.0 �Ҳ��� 
// �аѾ\ <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a> 
// �@�����s�sĶ�ӷ����n, �惡�ɮשҰ�������קﳣ�N�|��. 
// ���ͮɶ�: 2022.11.17 �� 02:36:28 PM CST 
//

package tw.com.transglobe.adp.integration.ebao.kmiddle.wsclient.xml.cmn150req;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the tw.com.transglobe.adp.integration.ebao.kmiddle.xml.cmn150req package.
 * <p>
 * An ObjectFactory allows you to programatically
 * construct new instances of the Java representation
 * for XML content. The Java representation of XML
 * content can consist of schema derived interfaces
 * and classes representing the binding of schema
 * type definitions, element declarations and model
 * groups. Factory methods for each of these are
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

  private final static QName _GroupPolicyListQueryRq_QNAME = new QName("", "GroupPolicyListQueryRq");

  /**
   * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package:
   * tw.com.transglobe.adp.integration.ebao.kmiddle.xml.cmn150req
   * 
   */
  public ObjectFactory() {
  }

  /**
   * Create an instance of {@link Cmn150In }
   * 
   */
  public Cmn150In createCmn150In() {
    return new Cmn150In();
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link Cmn150In }{@code >}
   * 
   * @param value
   *        Java instance representing xml element's value.
   * @return
   *         the new instance of {@link JAXBElement }{@code <}{@link Cmn150In }{@code >}
   */
  @XmlElementDecl(namespace = "", name = "GroupPolicyListQueryRq")
  public JAXBElement<Cmn150In> createGroupPolicyListQueryRq(Cmn150In value) {
    return new JAXBElement<Cmn150In>(_GroupPolicyListQueryRq_QNAME, Cmn150In.class, null, value);
  }

}
