package tw.com.transglobe.adp.integration.ebao.common.wsclient;

import javax.xml.bind.annotation.adapters.XmlAdapter;
import lombok.extern.slf4j.Slf4j;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Slf4j
public class SlashLocalDateAdapter extends XmlAdapter<String, LocalDate> {

  final DateTimeFormatter formatter_hyphen = DateTimeFormatter.ofPattern("yyyy-MM-dd");
  final DateTimeFormatter formatter_slash = DateTimeFormatter.ofPattern("yyyy/MM/dd");

  @Override
  public LocalDate unmarshal(String v) throws Exception {
    // 如果回傳2022-01-03T23:11:11.11，只拿2022-01-03
    if (v == null)
      return null;

    if (v.length() > 19) {
      v = v.substring(0, 19);
      log.debug("{}", v);
    }

    if (v.matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}")) {
      return LocalDate.parse(v.substring(0, 10), formatter_hyphen);
    } else if (v.matches("\\d{4}-\\d{2}-\\d{2}")) {
      return LocalDate.parse(v, formatter_hyphen);
    } else if (v.matches("\\d{4}/\\d{2}/\\d{2}T\\d{2}:\\d{2}:\\d{2}")) {
      return LocalDate.parse(v.substring(0, 10), formatter_slash);
    } else if (v.matches("\\d{4}/\\d{2}/\\d{2}")) {
      return LocalDate.parse(v, formatter_slash);
    }
    log.error("Can't convert to LocalDate input value : {}, return null", v);
    return null;
  }

  @Override
  public String marshal(LocalDate v) throws Exception {
    return v.format(formatter_slash);
  }

}
