package tw.com.transglobe.adp.integration.ebao.claim.wsclient.xml;

import lombok.Getter;
import lombok.Setter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "diagnosisVO")
@Getter
@Setter
public class DiagnosisVO {
  @XmlElement(required = true)
  protected String diagnosisCode;

  @XmlElement(required = true)
  protected String diagnosisName;
}
