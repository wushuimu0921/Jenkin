package tw.com.transglobe.adp.integration.ebao.policy.service;

import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import tw.com.softleader.data.security.guardium.annotation.Safeguard;
import tw.com.transglobe.adp.integration.commons.enums.ProductGroupType;

@Slf4j
@Transactional
@Service
@RequiredArgsConstructor
@Safeguard
public class EbaoPolicyCommonService {

  final EbaoPolicyCommonWsClient client;

  public List<EbaoPolicyCommonVo> getPolicy(ProductGroupType productGroupType, String idno) {
    return client.getPolicy(productGroupType, idno);
  }

}
