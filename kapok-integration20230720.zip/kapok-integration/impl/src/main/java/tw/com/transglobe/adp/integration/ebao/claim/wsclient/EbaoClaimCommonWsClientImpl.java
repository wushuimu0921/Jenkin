package tw.com.transglobe.adp.integration.ebao.claim.wsclient;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.UUID;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import org.springframework.stereotype.Component;
import com.sun.xml.txw2.output.CharacterEscapeHandler;
import com.sun.xml.txw2.output.DataWriter;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import tw.com.transglobe.adp.integration.commons.enums.ProductGroupType;
import tw.com.transglobe.adp.integration.commons.enums.Status;
import tw.com.transglobe.adp.integration.config.AdpIntegrationProperties;
import tw.com.transglobe.adp.integration.ebao.claim.service.ClaimRecordQuery071RqCmd;
import tw.com.transglobe.adp.integration.ebao.claim.service.ClaimRecordQuery071RsCmd;
import tw.com.transglobe.adp.integration.ebao.claim.service.EbaoClaimCommonWsClient;
import tw.com.transglobe.adp.integration.ebao.claim.wsclient.xml.ClaimRecordQuery071Rq;
import tw.com.transglobe.adp.integration.ebao.claim.wsclient.xml.ClaimRecordQuery071Rs;
import tw.com.transglobe.adp.integration.ebao.common.wsclient.RqHeader;
import tw.com.transglobe.adp.integration.ebao.common.wsclient.StandardRequest;
import tw.com.transglobe.adp.integration.ebao.common.wsclient.StandardResponse;

@Slf4j
@RequiredArgsConstructor
@Component
class EbaoClaimCommonWsClientImpl implements EbaoClaimCommonWsClient {

  final AdpIntegrationProperties properties;
  final EbaoClaimMapper mapper;

  @SneakyThrows
  @Override
  public ClaimRecordQuery071RsCmd clm071(ProductGroupType productGroupType, ClaimRecordQuery071RqCmd clm071Cmd) {

    var clm071 = mapper.toRq(clm071Cmd);

    JAXBContext jaxbContext = JAXBContext.newInstance(ClaimRecordQuery071Rq.class);
    Marshaller marshaller = jaxbContext.createMarshaller();
    marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
    marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);

    var sw = new StringWriter();
    marshaller.marshal(clm071, sw);

    var xmlData = sw.toString();
    log.debug("clm071 request:{}", xmlData);
    return exchange("WSClaimRecordQuery071Service", productGroupType, xmlData);
  }

  @SneakyThrows
  private ClaimRecordQuery071RsCmd exchange(String serviceName, ProductGroupType productGroupType, String xmlData) {

    log.debug("xmlData:{}", xmlData);
    log.info("EbaoClaimWs Properties Url:{}", properties.getEbaoClaimWs().getUrl());
    CommonWSService serviceImpl = new CommonWSService(new URL(properties.getEbaoClaimWs().getUrl()));
    CommonWS service = serviceImpl.getCommonWSServicePort();

    StandardRequest request = new StandardRequest();
    RqHeader header = new RqHeader();

    LocalDateTime now = LocalDateTime.now();
    header.setRqTimestamp(now);
    header.setRqUID(UUID.randomUUID().toString());

    request.setRqHeader(header);
    request.setServiceName(serviceName);
    request.setSystemCode(productGroupType.toString());
    request.setRqBody(xmlData);

    if (log.isDebugEnabled()) {
      JAXBContext jaxbContext = JAXBContext.newInstance(StandardRequest.class);
      Marshaller marshaller = jaxbContext.createMarshaller();
      marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
      marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);

      StringWriter sw = new StringWriter();
      // for xml data *DO NOT* convert to &lt; &gt; etc.. to escape all characters
      PrintWriter pw = new PrintWriter(sw);
      DataWriter dw = new DataWriter(pw, "UTF-8", new CharacterEscapeHandler() {
        @Override
        public void escape(char[] buf, int start, int len, boolean b, Writer out) throws IOException {
          out.write(buf, start, len);
        }
      });

      marshaller.marshal(request, dw);

      String wsData = sw.toString();

      log.debug("xml data:{}", wsData);
    }

    try {
      StandardResponse response = service.exchange(request);
      log.debug("the response is \n {}", response);
      Status responseStatus = response.getRsHeader().getReturnMsg().equals("success") ? Status.SUCCESS : Status.FAIL;
      log.debug("Ebao Claim response:{}", responseStatus);
      if (response.getRsHeader().getReturnMsg().equals("success")) {
        JAXBContext jaxbContext = JAXBContext.newInstance(ClaimRecordQuery071Rs.class);
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();

        ClaimRecordQuery071Rs out = (ClaimRecordQuery071Rs) unmarshaller.unmarshal(new StringReader(response.getRsBody()));
        log.debug("success Clm071Rs:{}", out);
        return mapper.toRsCmd(out);
      }
    } catch (Exception e) {
      log.error("Catched WS error:{}", e);
    }
    return mapper.toRsCmd(new ClaimRecordQuery071Rs());
  }
}
