package tw.com.transglobe.adp.integration.ebao.rest.wsclient;

import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "ebao-rest-qmlist", url = "${transglobe.integration.ebao-rest-qmlist.url}")
public interface EbaoRestQmlistFeignClient {

  @PostMapping
  List<EbaoRestQmlistResponse> getQmlist(@RequestBody EbaoRestQmlistRequest request);

}
