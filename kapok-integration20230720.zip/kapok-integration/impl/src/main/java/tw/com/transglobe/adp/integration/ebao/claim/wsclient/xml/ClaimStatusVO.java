package tw.com.transglobe.adp.integration.ebao.claim.wsclient.xml;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import tw.com.transglobe.adp.integration.ebao.common.wsclient.LocalDateAdapter;
import javax.xml.bind.annotation.*;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.time.LocalDate;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClaimStatus")
@Getter
@Setter
@ToString
public class ClaimStatusVO {

  @XmlElement
  protected String policySource;

  @XmlElement(required = true)
  protected String caseNo;

  @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
  protected LocalDate acceptTime;

  @XmlElement(required = true)
  protected String certCode;

  @XmlElement(required = true)
  protected String accidentName;

  @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
  protected LocalDate accidentBirthday;

  @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
  protected LocalDate accidentTime;

  @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
  protected LocalDate approveTime;

  @XmlElement(required = true)
  protected String auditorId;

  @XmlElement(required = true)
  protected String auditorName;

  @XmlElement(required = true)
  protected String auditorOrgan;

  @XmlElement(required = true)
  protected String auditorTel;

  @XmlElement(required = true)
  protected String auditorExt;

  @XmlElement(required = true)
  protected String auditorEmail;

  @XmlElement(required = true)
  protected String caseStatusCode;

  @XmlElement(required = true)
  protected String caseStatusDesc;

  @XmlElement(required = true)
  protected String isSurvey;

  @XmlElement(required = true)
  protected String generalComm;

  @XmlElement(required = true)
  protected String rptrNo;

  @XmlElement(required = true)
  protected String rptrName;

  @XmlElementWrapper(name = "DiagnosisList")
  @XmlElement(required = true, name = "Diagnosis")
  protected List<DiagnosisVO> diagnosisList;

  @XmlElementWrapper(name = "MedicalBillList")
  @XmlElement(required = true, name = "MedicalBill")
  protected List<MedicalBillVO> medicalBillList;

  @XmlElementWrapper(name = "PolicyDataList")
  @XmlElement(required = true, name = "PolicyData")
  protected List<PolicyDataVO> policyDataList;

  @XmlElement
  protected String checkFlag;

  @XmlElement
  protected Integer claimType;

  @XmlElement
  protected Integer claimNature;

}
