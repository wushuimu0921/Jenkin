package tw.com.transglobe.adp.integration.ebao.finance.service.cmd;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;
import tw.com.transglobe.adp.integration.commons.enums.ChannelType;
import tw.com.transglobe.adp.integration.commons.enums.CheckSource;
import tw.com.transglobe.adp.integration.commons.enums.FeeType;
import tw.com.transglobe.adp.integration.commons.enums.MoneyId;
import tw.com.transglobe.adp.integration.commons.enums.PayMode;
import tw.com.transglobe.adp.integration.commons.enums.PaySource;
import tw.com.transglobe.adp.integration.commons.enums.PhCertiType;
import tw.com.transglobe.adp.integration.commons.enums.ProductCategory;

@Data
@Builder
public class EbaoFinanceCollectCreateCmd {

  LocalDateTime dataDate; //資料日期

  Integer cashSeq; //流水號
  Integer systemId; //系統代碼(1=>團旅險)
  Integer subSystemId;
  Integer businessTypeId;

  String refId; // REF ID, 取得 Record.id
  String adpPolNo; // 保單號碼, 非必填
  String divideIndi; // 區隔標記 ?? default T

  String phCertiCode; //要保人證號
  String phName; //要保人姓名

  FeeType feeType; // 費用類型
  PayMode payMode; // 付款方式
  PaySource paySource; // 付款來源
  //  FeeStatus feeStatus; // 費用狀態 , default 0
  MoneyId moneyId; // 保單幣別
  BigDecimal feeAmount; // 費用金額
  MoneyId payMoneyId; // 交易幣別
  BigDecimal payAmount; // 交易幣金額
  LocalDate checkEnterTime; // 交易日期
  LocalDate finishTime; // 公司入帳日

  String cashierDeptCode;
  String cashierDeptName;
  String cashierName;
  String cashierJobNo;
  LocalDateTime cashierTime;

  ChannelType agentChannelType;
  String agentChannelCode;
  String agentRegisterCode;

  String voucherNo;
  LocalDate voucherDate;
  BigDecimal voucherAmount;

  String postTransNo;

  String creditCardNum;
  String creditCardAuth;
  String creditCardExpireDate;
  Long creditCardAcquirerId;

  String chequeNo;
  CheckSource chequeSource;
  BigDecimal chequeAmount;
  String chequeBank;
  String chequeAccount;
  LocalDate chequeDueDate;
  String chequePhCertiCode;
  PhCertiType chequePhCertiType;
  String chequePhName;

  LocalDate accountingDate;

  ProductCategory productCategory;

  String agentChannelName;
  String agentChannelTypeCode;
  Integer overPaymentType;
  BigDecimal overPaymentAmount;
  Long relatedId;

  Long internalAccount;

  LocalDate validateDate;

}
