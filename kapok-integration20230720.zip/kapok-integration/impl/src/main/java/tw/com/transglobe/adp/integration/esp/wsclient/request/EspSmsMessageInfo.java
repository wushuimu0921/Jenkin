package tw.com.transglobe.adp.integration.esp.wsclient.request;

import lombok.Builder;
import lombok.Data;

/**
 *
 * 訊息資訊
 *
 * @author Default User
 *
 */
@Data
@Builder
public class EspSmsMessageInfo {

  String referenceId;

  String destPhoneNo;

  String msgData;

  String chargeCode;

}
