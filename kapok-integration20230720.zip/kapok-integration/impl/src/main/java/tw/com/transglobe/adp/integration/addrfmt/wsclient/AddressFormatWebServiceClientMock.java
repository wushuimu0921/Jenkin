package tw.com.transglobe.adp.integration.addrfmt.wsclient;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import tw.com.transglobe.adp.integration.addrfmt.service.AddressFormatVo;
import tw.com.transglobe.adp.integration.addrfmt.service.AddressFormatWebServiceClient;

@Slf4j
public class AddressFormatWebServiceClientMock implements AddressFormatWebServiceClient {

  @Override
  public AddressFormatVo getAddressFormat(String inputAddress) {
    if (StringUtils.isNotEmpty(inputAddress) && "桃園市中正路1號".equals(inputAddress)) {
      AddressFormatVo vo = new AddressFormatVo();
      vo.setErrorDescription("無法辨別行政區");
      vo.setArea("桃園市");
      vo.setRoad("中正路");
      vo.setNumber("1");
      vo.setFullAddress("桃園市中正路１號");
      return vo;
    }
    var address = new AddressFormatVo();
    address.setZipCode("106078");
    address.setFullAddress("臺北市大安區忠孝東路四段２９５號三樓");
    return address;
  }

}
