package tw.com.transglobe.adp.integration.addrfmt.wsclient;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tw.com.transglobe.adp.integration.addrfmt.service.AddressFormatWebServiceClient;
import tw.com.transglobe.adp.integration.config.AdpIntegrationProperties;

@RequiredArgsConstructor
@Configuration
@Slf4j
public class AddressFormatWebServiceClientConfig {

  @Bean
  @ConditionalOnMissingBean
  @ConditionalOnProperty(value = "address-format-client.enabled", havingValue = "false")
  public AddressFormatWebServiceClient addressFormatWebServiceClientOfMock() {
    log.info("Creating mock addressFormatClient.");
    return new AddressFormatWebServiceClientMock();
  }

  @Bean
  @ConditionalOnProperty(value = "address-format-client.enabled", havingValue = "true")
  public AddressFormatWebServiceClient addressFormatWebServiceClient(
      AdpIntegrationProperties properties) {
    log.info("Creating dev addressFormatClient.");
    return new AddressFormatWebServiceClientImpl(properties);
  }

}
