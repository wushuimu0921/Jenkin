package tw.com.transglobe.adp.integration.aml.wsclient.xml;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import javax.xml.bind.annotation.XmlElement;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
public class CifDto {
  @XmlElement(name = "CINO", required = true)
  protected String cino;
  @XmlElement(name = "FIELD", required = true)
  protected String field;

}
