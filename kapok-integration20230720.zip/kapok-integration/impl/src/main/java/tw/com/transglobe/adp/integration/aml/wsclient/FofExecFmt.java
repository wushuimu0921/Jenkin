
package tw.com.transglobe.adp.integration.aml.wsclient;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * FofExecFmt complex type 的 Java 類別.
 *
 * <p>
 * 下列綱要片段會指定此類別中包含的預期內容.
 *
 * <pre>
 * &lt;complexType name="FofExecFmt"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="appCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="unit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="messageId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="fmt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="usercode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="userdata" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="details" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="sendTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="msg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="authkey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="authname" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="exts" type="{http://webservice.lyods.com/}exts" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FofExecFmt", propOrder = {
    "appCode",
    "unit",
    "messageId",
    "fmt",
    "usercode",
    "userdata",
    "details",
    "sendTime",
    "msg",
    "authkey",
    "authname",
    "exts"
})
public class FofExecFmt {

  protected String appCode;
  protected String unit;
  protected String messageId;
  protected String fmt;
  protected String usercode;
  protected String userdata;
  protected Integer details;
  protected String sendTime;
  protected String msg;
  protected String authkey;
  protected String authname;
  protected Exts exts;

  /**
   * 取得 appCode 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getAppCode() {
    return appCode;
  }

  /**
   * 設定 appCode 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setAppCode(String value) {
    this.appCode = value;
  }

  /**
   * 取得 unit 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getUnit() {
    return unit;
  }

  /**
   * 設定 unit 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setUnit(String value) {
    this.unit = value;
  }

  /**
   * 取得 messageId 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getMessageId() {
    return messageId;
  }

  /**
   * 設定 messageId 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setMessageId(String value) {
    this.messageId = value;
  }

  /**
   * 取得 fmt 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getFmt() {
    return fmt;
  }

  /**
   * 設定 fmt 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setFmt(String value) {
    this.fmt = value;
  }

  /**
   * 取得 usercode 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getUsercode() {
    return usercode;
  }

  /**
   * 設定 usercode 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setUsercode(String value) {
    this.usercode = value;
  }

  /**
   * 取得 userdata 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getUserdata() {
    return userdata;
  }

  /**
   * 設定 userdata 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setUserdata(String value) {
    this.userdata = value;
  }

  /**
   * 取得 details 特性的值.
   *
   * @return
   *         possible object is
   *         {@link Integer }
   *
   */
  public Integer getDetails() {
    return details;
  }

  /**
   * 設定 details 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link Integer }
   *
   */
  public void setDetails(Integer value) {
    this.details = value;
  }

  /**
   * 取得 sendTime 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getSendTime() {
    return sendTime;
  }

  /**
   * 設定 sendTime 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setSendTime(String value) {
    this.sendTime = value;
  }

  /**
   * 取得 msg 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getMsg() {
    return msg;
  }

  /**
   * 設定 msg 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setMsg(String value) {
    this.msg = value;
  }

  /**
   * 取得 authkey 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getAuthkey() {
    return authkey;
  }

  /**
   * 設定 authkey 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setAuthkey(String value) {
    this.authkey = value;
  }

  /**
   * 取得 authname 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getAuthname() {
    return authname;
  }

  /**
   * 設定 authname 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setAuthname(String value) {
    this.authname = value;
  }

  /**
   * 取得 exts 特性的值.
   *
   * @return
   *         possible object is
   *         {@link Exts }
   *
   */
  public Exts getExts() {
    return exts;
  }

  /**
   * 設定 exts 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link Exts }
   *
   */
  public void setExts(Exts value) {
    this.exts = value;
  }

}
