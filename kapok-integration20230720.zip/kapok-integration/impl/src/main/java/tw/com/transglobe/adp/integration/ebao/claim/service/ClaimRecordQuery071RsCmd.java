package tw.com.transglobe.adp.integration.ebao.claim.service;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class ClaimRecordQuery071RsCmd {

  List<ClaimStatusCmd> claimStatusList;

}
