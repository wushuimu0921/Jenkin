package tw.com.transglobe.adp.integration.esp.wsclient.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tw.com.transglobe.adp.integration.config.AdpIntegrationProperties;
import tw.com.transglobe.adp.integration.esp.wsclient.EspMailAttachFeignClient;
import tw.com.transglobe.adp.integration.esp.wsclient.impl.EspMailServiceClientImpl;
import tw.com.transglobe.adp.integration.esp.wsclient.impl.EspMailServiceClientMock;
import tw.com.transglobe.adp.integration.esp.service.client.EspMailWebServiceClient;

@Slf4j
@Configuration
class EspMailServiceClientConfig {

  @Bean
  @ConditionalOnMissingBean
  @ConditionalOnProperty(value = "mail-client.enabled", havingValue = "false")
  public EspMailWebServiceClient espMailWebServiceClientOfMock(AdpIntegrationProperties properties) {
    return new EspMailServiceClientMock(properties);
  }

  @Bean
  @ConditionalOnProperty(value = "mail-client.enabled", havingValue = "true")
  public EspMailWebServiceClient espMailWebServiceClient(EspMailAttachFeignClient feignClient) {
    return new EspMailServiceClientImpl(feignClient);
  }
}
