//
// ���ɮ׬O�� JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.3.0 �Ҳ���
// �аѾ\ <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a>
// �@�����s�sĶ�ӷ����n, �惡�ɮשҰ�������קﳣ�N�|��.
// ���ͮɶ�: 2022.11.17 �� 02:36:28 PM CST
//

package tw.com.transglobe.adp.integration.ebao.kmiddle.wsclient.xml.cmn150req;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * cmn150In complex type �� Java ���O.
 *
 * <p>
 * �U�C���n���q�|���w�����O���]�t���w�����e.
 *
 * <pre>
 * &lt;complexType name="cmn150In"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="type" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="param" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="policyStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "cmn150In", propOrder = {
    "type",
    "param",
    "policyStatus"
})
@XmlRootElement(name = "GroupPolicyListQueryRq")
public class Cmn150In {

  protected String type;
  protected String param;
  protected String policyStatus;

  /**
   * ���o type �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getType() {
    return type;
  }

  /**
   * �]�w type �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setType(String value) {
    this.type = value;
  }

  /**
   * ���o param �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getParam() {
    return param;
  }

  /**
   * �]�w param �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setParam(String value) {
    this.param = value;
  }

  /**
   * ���o policyStatus �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getPolicyStatus() {
    return policyStatus;
  }

  /**
   * �]�w policyStatus �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setPolicyStatus(String value) {
    this.policyStatus = value;
  }

}
