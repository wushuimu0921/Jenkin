package tw.com.transglobe.adp.integration.esp.wsclient.request;

import lombok.Builder;
import lombok.Data;

/**
 *
 * ESP 主旨/內容模板資訊
 * 若直接指定主旨/內容，此物件請不要放
 *
 * @author Default User
 *
 */
@Data
@Builder
public class EspTemplateInfo {

  String templateId;
  String templateXmlVar;

}
