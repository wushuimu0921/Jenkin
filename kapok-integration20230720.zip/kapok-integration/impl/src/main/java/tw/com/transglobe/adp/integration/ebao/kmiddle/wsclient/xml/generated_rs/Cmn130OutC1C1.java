//
// ���ɮ׬O�� JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.8-b130911.1802 �Ҳ���
// �аѾ\ <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a>
// �@�����s�sĶ�ӷ����n, �惡�ɮשҰ�������קﳣ�N�|��.
// ���ͮɶ�: 2022.10.05 �� 12:31:29 PM CST
//

package tw.com.transglobe.adp.integration.ebao.kmiddle.wsclient.xml.generated_rs;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * cmn130OutC1C1 complex type �� Java ���O.
 *
 * <p>
 * �U�C���n���q�|���w�����O���]�t���w�����e.
 *
 * <pre>
 * &lt;complexType name="cmn130OutC1C1">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="policyCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="insuredRelation" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="publicCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="payAmout" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "cmn130OutC1C1", propOrder = {
    "policyCode",
    "insuredRelation",
    "publicCode",
    "payAmout"
})
public class Cmn130OutC1C1 {

  @XmlElement(required = true)
  protected String policyCode;
  @XmlElement(required = true)
  protected String insuredRelation;
  @XmlElement(required = true)
  protected String publicCode;
  @XmlElement(required = true)
  protected BigDecimal payAmout;

  /**
   * ���o policyCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getPolicyCode() {
    return policyCode;
  }

  /**
   * �]�w policyCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setPolicyCode(String value) {
    this.policyCode = value;
  }

  /**
   * ���o insuredRelation �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getInsuredRelation() {
    return insuredRelation;
  }

  /**
   * �]�w insuredRelation �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setInsuredRelation(String value) {
    this.insuredRelation = value;
  }

  /**
   * ���o publicCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getPublicCode() {
    return publicCode;
  }

  /**
   * �]�w publicCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setPublicCode(String value) {
    this.publicCode = value;
  }

  /**
   * ���o payAmout �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link BigDecimal }
   *
   */
  public BigDecimal getPayAmout() {
    return payAmout;
  }

  /**
   * �]�w payAmout �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link BigDecimal }
   *
   */
  public void setPayAmout(BigDecimal value) {
    this.payAmout = value;
  }

}
