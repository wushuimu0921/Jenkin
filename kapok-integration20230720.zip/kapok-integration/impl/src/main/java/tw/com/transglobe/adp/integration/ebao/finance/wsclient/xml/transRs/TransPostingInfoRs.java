package tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRs;

import lombok.*;
import tw.com.transglobe.adp.integration.commons.enums.YesNo;
import tw.com.transglobe.adp.integration.ebao.common.wsclient.SlashLocalDateAdapter;

import javax.xml.bind.annotation.*;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.time.LocalDate;
import java.util.List;

@ToString
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TransPostingInfoRs", propOrder = {
    "postingDate",
    "refId",
    "responseCode",
    "responseDesc",
    "cashPayPosting",
    "cashColPosting",
    "arapPosting",
    "commisionPosting"
})
@XmlRootElement(name = "GlTransPostingInfoRs")
public class TransPostingInfoRs {

  @XmlElement(name = "PostingDate")
  @XmlJavaTypeAdapter(SlashLocalDateAdapter.class)
  protected LocalDate postingDate;

  @XmlElement(name = "RefId")
  protected String refId;

  @XmlElement(name = "ResponseCode")
  protected String responseCode;

  @XmlElement(name = "ResponseDesc")
  protected String responseDesc;

  @XmlElement(name = "CashPayPosting")
  protected CashPayPosting cashPayPosting;

  @XmlElement(name = "CashColPosting")
  protected CashColPosting cashColPosting;

  @XmlElement(name = "ArapPosting")
  protected ArapPosting arapPosting;

  @XmlElement(name = "CommisionPosting")
  protected CommisionPosting commisionPosting;

  @XmlAccessorType(XmlAccessType.FIELD)
  @XmlType(name = "CashPayPosting", propOrder = {
      "successCount",
      "failCount",
      "totalCount",
      "postingResult"
  })
  @Data
  public static class CashPayPosting {
    @XmlElement(name = "SuccessCount")
    protected Integer successCount;

    @XmlElement(name = "FailCount")
    protected Integer failCount;

    @XmlElement(name = "TotalCount")
    protected Integer totalCount;

    @XmlElementWrapper(name = "PostingResults")
    @XmlElement(name = "PostingResult")
    protected List<PostingResult> postingResult;
  }

  @XmlAccessorType(XmlAccessType.FIELD)
  @XmlType(name = "CashColPosting", propOrder = {
      "successCount",
      "failCount",
      "totalCount",
      "postingResult"
  })
  @Data
  public static class CashColPosting {
    @XmlElement(name = "SuccessCount")
    protected Integer successCount;

    @XmlElement(name = "FailCount")
    protected Integer failCount;

    @XmlElement(name = "TotalCount")
    protected Integer totalCount;

    @XmlElementWrapper(name = "PostingResults")
    @XmlElement(name = "PostingResult")
    protected List<PostingResult> postingResult;
  }

  @XmlAccessorType(XmlAccessType.FIELD)
  @XmlType(name = "ArapPosting", propOrder = {
      "successCount",
      "failCount",
      "totalCount",
      "postingResult"
  })
  @Data
  public static class ArapPosting {

    @XmlElement(name = "SuccessCount")
    protected Integer successCount;

    @XmlElement(name = "FailCount")
    protected Integer failCount;

    @XmlElement(name = "TotalCount")
    protected Integer totalCount;

    @XmlElementWrapper(name = "PostingResults")
    @XmlElement(name = "PostingResult")
    protected List<PostingResult> postingResult;
  }

  @XmlAccessorType(XmlAccessType.FIELD)
  @XmlType(name = "CommisionPosting", propOrder = {
      "successCount",
      "failCount",
      "totalCount",
      "postingResult"
  })
  @Data
  public static class CommisionPosting {

    @XmlElement(name = "SuccessCount")
    protected Integer successCount;

    @XmlElement(name = "FailCount")
    protected Integer failCount;

    @XmlElement(name = "TotalCount")
    protected Integer totalCount;

    @XmlElementWrapper(name = "PostingResults")
    @XmlElement(name = "PostingResult")
    protected List<PostingResult> postingResult;
  }

  @XmlAccessorType(XmlAccessType.FIELD)
  @XmlType(name = "PostingResult", propOrder = {
      "posted",
      "feeId",
      "refId",
      "adpFeeId",
      "statusName",
      "statusCode",
      "accountGlDate",
      "payMode",
      "payModeName",
      "oriChequeStatus",
      "oriChequeStatusName",
      "afterChequeStatus",
      "afterChequeStatusName"
  })
  @Data
  public static class PostingResult {
    @XmlElement(name = "Posted")
    protected YesNo posted;

    @XmlElement(name = "FeeId")
    protected Long feeId;

    @XmlElement(name = "RefId")
    protected String refId;

    @XmlElement(name = "AdpFeeId")
    protected Long adpFeeId;

    @XmlElement(name = "StatusName")
    protected String statusName;

    @XmlElement(name = "StatusCode")
    protected Integer statusCode;

    @XmlElement(name = "AccountGlDate")
    protected String accountGlDate;

    @XmlElement(name = "PayMode")
    protected String payMode;

    @XmlElement(name = "PayModeName")
    protected String payModeName;

    @XmlElement(name = "OriChequeStatus")
    protected String oriChequeStatus;

    @XmlElement(name = "OriChequeStatusName")
    protected String oriChequeStatusName;

    @XmlElement(name = "AfterChequeStatus")
    protected String afterChequeStatus;

    @XmlElement(name = "AfterChequeStatusName")
    protected String afterChequeStatusName;
  }

}
