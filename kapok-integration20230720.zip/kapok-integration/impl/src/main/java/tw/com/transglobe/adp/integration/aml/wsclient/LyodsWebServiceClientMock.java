package tw.com.transglobe.adp.integration.aml.wsclient;

import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;
import tw.com.transglobe.adp.integration.aml.service.AmlCifResultVo;
import tw.com.transglobe.adp.integration.aml.service.AmlRelData;
import tw.com.transglobe.adp.integration.aml.service.AmlRelResultVo;
import tw.com.transglobe.adp.integration.aml.service.AmlResultVo;
import tw.com.transglobe.adp.integration.aml.service.LyodsWebServiceClient;
import tw.com.transglobe.adp.integration.aml.service.LyodsWebServiceCmd;

import java.time.LocalDateTime;
import java.util.List;

@Slf4j
public class LyodsWebServiceClientMock implements LyodsWebServiceClient {
  @Override
  public AmlCifResultVo fofExecCif(LyodsWebServiceCmd execCif) {
    if (execCif.getCif() != null && "X101010107".equals(execCif.getCif().idno())) {
      // mock X101010107 中風險
      final AmlCifResultVo cifResultVo = new AmlCifResultVo();
      cifResultVo.setIdno(execCif.getCif().idno());
      cifResultVo.setResult(AmlResultVo.NOHIT);
      cifResultVo.setHitCount(0);
      cifResultVo.setDecType("NEW");
      cifResultVo.setDecState("LPEP");
      cifResultVo.setDecDate(LocalDateTime.now());
      cifResultVo.setCalculateLevel("M");

      List<AmlRelResultVo> rels = Lists.newArrayList();

      if (!CollectionUtils.isEmpty(execCif.getRels())) {
        for (AmlRelData rel : execCif.getRels()) {
          if ("B123456780".equals(rel.idno())) {
            AmlRelResultVo relResultVo = new AmlRelResultVo();
            relResultVo.setIdno(rel.idno());
            relResultVo.setHitCount(10);
            relResultVo.setDecType("NEW");
            relResultVo.setDecState("SAN");
            relResultVo.setDecDate(LocalDateTime.now());
            relResultVo.setDecBy("");
            relResultVo.setDecComments("");
            relResultVo.setResult(AmlResultVo.SANCTION);
            rels.add(relResultVo);
          }
        }
      }
      cifResultVo.setRels(rels);

      return cifResultVo;
    } else if (execCif.getCif() != null && "B123456780".equals(execCif.getCif().idno())) {
      // mock B123456780 高風險
      final AmlCifResultVo vo = new AmlCifResultVo();
      vo.setIdno(execCif.getCif().idno());
      vo.setResult(AmlResultVo.SANCTION);
      vo.setHitCount(10);
      vo.setDecType("NEW");
      vo.setDecState("SAN");
      vo.setDecDate(LocalDateTime.now());
      vo.setCalculateLevel("H");
      return vo;
    }
    return new AmlCifResultVo();
  }
}
