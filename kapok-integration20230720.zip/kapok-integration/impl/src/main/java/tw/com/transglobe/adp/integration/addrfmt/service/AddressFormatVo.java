package tw.com.transglobe.adp.integration.addrfmt.service;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class AddressFormatVo {

  @Schema(description = "郵遞區號 6碼")
  String zipCode;

  @Schema(description = "縣市")
  String area;

  @Schema(description = "鄉鎮區")
  String district;

  @Schema(description = "里")
  String village;

  @Schema(description = "街路")
  String road;

  @Schema(description = "鄰")
  String neighborhood;

  @Schema(description = "巷")
  String lane;

  @Schema(description = "弄")
  String alley;

  @Schema(description = "衖")
  String subAlley;

  @Schema(description = "號")
  String number;

  @Schema(description = "樓")
  String floor;

  @Schema(description = "其他")
  String other;

  @Schema(description = "錯誤說明")
  String errorDescription;

  @Schema(description = "錯誤碼")
  String errorCode;

  @Schema(description = "是否為郵箱")
  String mailBox;

  @Schema(description = "完整地址")
  String fullAddress;

  @Schema(description = "保留欄")
  String reserve;
}
