//
// ���ɮ׬O�� JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.3.0 �Ҳ���
// �аѾ\ <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a>
// �@�����s�sĶ�ӷ����n, �惡�ɮשҰ�������קﳣ�N�|��.
// ���ͮɶ�: 2022.11.22 �� 03:29:21 PM CST
//

package tw.com.transglobe.adp.integration.ebao.policy.wsclient.xml;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.*;

/**
 * <p>
 * effectPolicyListRs complex type �� Java ���O.
 *
 * <p>
 * �U�C���n���q�|���w�����O���]�t���w�����e.
 *
 * <pre>
 * &lt;complexType name="effectPolicyListRs"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="EffectPolicyDataList" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="EffectPolicyData" type="{}effectPolicyDataVO" maxOccurs="unbounded" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EffectPolicyListRs", propOrder = {
    "effectPolicyDataList"
})
@XmlRootElement(name = "EffectPolicyListRs")
public class EffectPolicyListRs {

  @XmlElement(name = "EffectPolicyDataList")
  protected EffectPolicyListRs.EffectPolicyDataList effectPolicyDataList;

  /**
   * ���o effectPolicyDataList �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link EffectPolicyListRs.EffectPolicyDataList }
   *
   */
  public EffectPolicyListRs.EffectPolicyDataList getEffectPolicyDataList() {
    return effectPolicyDataList;
  }

  /**
   * �]�w effectPolicyDataList �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link EffectPolicyListRs.EffectPolicyDataList }
   *
   */
  public void setEffectPolicyDataList(EffectPolicyListRs.EffectPolicyDataList value) {
    this.effectPolicyDataList = value;
  }

  /**
   * <p>
   * anonymous complex type �� Java ���O.
   *
   * <p>
   * �U�C���n���q�|���w�����O���]�t���w�����e.
   *
   * <pre>
   * &lt;complexType&gt;
   *   &lt;complexContent&gt;
   *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
   *       &lt;sequence&gt;
   *         &lt;element name="EffectPolicyData" type="{}effectPolicyDataVO" maxOccurs="unbounded" minOccurs="0"/&gt;
   *       &lt;/sequence&gt;
   *     &lt;/restriction&gt;
   *   &lt;/complexContent&gt;
   * &lt;/complexType&gt;
   * </pre>
   *
   *
   */
  @XmlAccessorType(XmlAccessType.FIELD)
  @XmlType(name = "EffectPolicyData", propOrder = {
      "effectPolicyData"
  })
  public static class EffectPolicyDataList {

    @XmlElement(name = "EffectPolicyData")
    protected List<EffectPolicyDataVO> effectPolicyData;

    /**
     * Gets the value of the effectPolicyData property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the effectPolicyData property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     *
     * <pre>
     * getEffectPolicyData().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link EffectPolicyDataVO }
     *
     *
     */
    public List<EffectPolicyDataVO> getEffectPolicyData() {
      if (effectPolicyData == null) {
        effectPolicyData = new ArrayList<EffectPolicyDataVO>();
      }
      return this.effectPolicyData;
    }

  }

}
