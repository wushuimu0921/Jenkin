package tw.com.transglobe.adp.integration.crystalreport.http;

import org.mapstruct.Mapper;
import tw.com.transglobe.adp.integration.crystalreport.http.dto.CrystalReportDto;
import tw.com.transglobe.adp.integration.crystalreport.http.query.CrystalReportRequest;
import tw.com.transglobe.adp.integration.crystalreport.service.CrystalGenCmd;
import tw.com.transglobe.adp.integration.crystalreport.service.CrystalReportVo;

@Mapper
interface CrystalReportDtoMapper {

  CrystalGenCmd toGenCmd(CrystalReportRequest request);

  CrystalReportDto fromVo(CrystalReportVo vo);

}
