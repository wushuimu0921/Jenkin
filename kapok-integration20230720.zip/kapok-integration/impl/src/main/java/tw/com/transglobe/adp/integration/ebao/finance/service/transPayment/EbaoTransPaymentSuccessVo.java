package tw.com.transglobe.adp.integration.ebao.finance.service.transPayment;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EbaoTransPaymentSuccessVo {
  Integer successCount;
  PaymentSuccessResultVo paymentSuccessResults;
}
