package tw.com.transglobe.adp.integration.aml.service;

import java.util.Map;
import tw.com.transglobe.adp.integration.aml.enums.AmlIdentType;

public record AmlRelData(String idno, AmlIdentType type, Map<String, String> fields) {

}
