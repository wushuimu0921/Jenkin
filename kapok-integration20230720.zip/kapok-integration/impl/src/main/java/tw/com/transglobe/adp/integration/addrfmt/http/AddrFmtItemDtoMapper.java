package tw.com.transglobe.adp.integration.addrfmt.http;

import org.mapstruct.Mapper;
import tw.com.transglobe.adp.integration.addrfmt.http.query.AddrFmtItemDto;
import tw.com.transglobe.adp.integration.addrfmt.service.AddressFormatVo;

@Mapper
interface AddrFmtItemDtoMapper {

  AddrFmtItemDto toAddrFmtItem(AddressFormatVo request);
}
