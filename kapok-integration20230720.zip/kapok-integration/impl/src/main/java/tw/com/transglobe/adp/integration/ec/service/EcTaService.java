package tw.com.transglobe.adp.integration.ec.service;

import org.springframework.stereotype.Service;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import tw.com.softleader.data.security.guardium.annotation.Safeguard;
import tw.com.transglobe.adp.integration.ec.service.cmd.EcTaPolicyPrintReplyCmd;

@Slf4j
@Service
@RequiredArgsConstructor
@Safeguard
public class EcTaService {

  final EcTaServiceClient client;

  public EcTaResultVo policyPrintReply(EcTaPolicyPrintReplyCmd cmd) {
    log.debug("{}", cmd);
    return client.policyPrintReply(cmd);
  }

}
