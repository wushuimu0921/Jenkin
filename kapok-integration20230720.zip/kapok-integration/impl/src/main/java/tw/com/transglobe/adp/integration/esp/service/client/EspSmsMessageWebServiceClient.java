package tw.com.transglobe.adp.integration.esp.service.client;

import tw.com.transglobe.adp.integration.esp.service.cmd.EspSmsMessageCmd;

public interface EspSmsMessageWebServiceClient {

  String sendSmsMessage(EspSmsMessageCmd cmd);

}
