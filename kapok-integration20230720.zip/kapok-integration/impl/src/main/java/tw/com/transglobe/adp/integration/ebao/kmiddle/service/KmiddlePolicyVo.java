package tw.com.transglobe.adp.integration.ebao.kmiddle.service;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

@Data
@Builder
public class KmiddlePolicyVo {

  String policyNo;
  String name;
  LocalDate birthday;

}
