
package tw.com.transglobe.adp.integration.addrfmt.wsclient;

import javax.xml.bind.annotation.XmlRegistry;

/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the org.tempuri package.
 * <p>
 * An ObjectFactory allows you to programatically
 * construct new instances of the Java representation
 * for XML content. The Java representation of XML
 * content can consist of schema derived interfaces
 * and classes representing the binding of schema
 * type definitions, element declarations and model
 * groups. Factory methods for each of these are
 * provided in this class.
 *
 */
@XmlRegistry
public class ObjectFactory {

  /**
   * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: org.tempuri
   *
   */
  public ObjectFactory() {
  }

  /**
   * Create an instance of {@link OrgAddEz2 }
   *
   */
  public OrgAddEz2 createOrgAddEz2() {
    return new OrgAddEz2();
  }

  /**
   * Create an instance of {@link OrgAddNew }
   *
   */
  public OrgAddNew createOrgAddNew() {
    return new OrgAddNew();
  }

  /**
   * Create an instance of {@link OrgAddRevResponse }
   *
   */
  public OrgAddRevResponse createOrgAddRevResponse() {
    return new OrgAddRevResponse();
  }

  /**
   * Create an instance of {@link OrgAddRev }
   *
   */
  public OrgAddRev createOrgAddRev() {
    return new OrgAddRev();
  }

  /**
   * Create an instance of {@link RegADDR }
   *
   */
  public RegADDR createRegADDR() {
    return new RegADDR();
  }

  /**
   * Create an instance of {@link OrgADDResponse }
   *
   */
  public OrgADDResponse createOrgADDResponse() {
    return new OrgADDResponse();
  }

  /**
   * Create an instance of {@link Cmp2ADDRResponse }
   *
   */
  public Cmp2ADDRResponse createCmp2ADDRResponse() {
    return new Cmp2ADDRResponse();
  }

  /**
   * Create an instance of {@link Cmp2ADDR }
   *
   */
  public Cmp2ADDR createCmp2ADDR() {
    return new Cmp2ADDR();
  }

  /**
   * Create an instance of {@link OrgAddNewResponse }
   *
   */
  public OrgAddNewResponse createOrgAddNewResponse() {
    return new OrgAddNewResponse();
  }

  /**
   * Create an instance of {@link TranC2E }
   *
   */
  public TranC2E createTranC2E() {
    return new TranC2E();
  }

  /**
   * Create an instance of {@link Recycle }
   *
   */
  public Recycle createRecycle() {
    return new Recycle();
  }

  /**
   * Create an instance of {@link OrgADD }
   *
   */
  public OrgADD createOrgADD() {
    return new OrgADD();
  }

  /**
   * Create an instance of {@link OrgAddEz }
   *
   */
  public OrgAddEz createOrgAddEz() {
    return new OrgAddEz();
  }

  /**
   * Create an instance of {@link RecycleResponse }
   *
   */
  public RecycleResponse createRecycleResponse() {
    return new RecycleResponse();
  }

  /**
   * Create an instance of {@link OrgAddEzResponse }
   *
   */
  public OrgAddEzResponse createOrgAddEzResponse() {
    return new OrgAddEzResponse();
  }

  /**
   * Create an instance of {@link OrgAddEz2Response }
   *
   */
  public OrgAddEz2Response createOrgAddEz2Response() {
    return new OrgAddEz2Response();
  }

  /**
   * Create an instance of {@link TranC2EResponse }
   *
   */
  public TranC2EResponse createTranC2EResponse() {
    return new TranC2EResponse();
  }

  /**
   * Create an instance of {@link RegADDRResponse }
   *
   */
  public RegADDRResponse createRegADDRResponse() {
    return new RegADDRResponse();
  }

}
