package tw.com.transglobe.adp.integration.ebao.finance.service.cmd;

import lombok.Builder;
import lombok.Data;
import tw.com.transglobe.adp.integration.commons.enums.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Builder
public class EbaoFinancePayCreateCmd {
  LocalDateTime dataDate;
  String cashSeq;
  Integer systemId;
  Integer subSystemId;
  Integer businessTypeId;
  String refId;
  String adpPolNo;
  String divideIndi;
  PhCertiType phCertiType;
  String phCertiCode;
  String phName;
  FeeType feeType;
  PayMode payMode;
  MoneyId moneyId;
  BigDecimal feeAmount;
  MoneyId payMoneyId;
  BigDecimal payAmount;
  //  BigDecimal payMergeAmount;

  String approveUserId;
  String cashierDeptCode;
  String cashierDeptName;
  String cashierName;
  String cashierJobNo;
  LocalDateTime cashierTime;

  ChannelType agentChannelType;
  String agentChannelCode;
  String agentRegisterCode;

  LocalDate dueTime;
  LocalDateTime approveDate;

  String approveUserName;
  String approveUserDeptCode;
  String approveUserDeptName;
  String approveUserJobNo;

  String payeeCertiCode;
  String payeeName;
  String payeeBankCode;
  String payeeBankName;
  String payeeAccount;

  String creditCardNum;
  String creditCardAuth;
  String creditCardExpireDate;
  LocalDate creditCardTransDate;
  Long creditCardAcquirerId;
  WithdrawType withdrawType;
  Integer paymentSource;

  // 支票
  YesNo cancelEndorsementIndi;
  YesNo cancelScoreIndi;
  String sendZipCode;
  String sendAddress;
  String companyName;
  String recipientName;
  String attachmentIndi;
  String posAcceptNo;
  String chequeSendType;

  ProductCategory productCategory;

  String agentChannelName;
  String agentChannelTypeCode;
  Long relatedId;
  String clmCaseNo;
}
