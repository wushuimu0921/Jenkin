package tw.com.transglobe.adp.integration.aml.wsclient.xml;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import javax.xml.bind.annotation.XmlElement;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
public class RelDto {
  @XmlElement(name = "CINO", required = true)
  protected String cino;
  @XmlElement(name = "TYPE", required = true)
  protected String type;
  @XmlElement(name = "HitCount", required = true)
  protected String hitCount;
  @XmlElement(name = "DecType", required = true)
  protected String decType;
  @XmlElement(name = "DecState", required = true)
  protected String DecState;
  @XmlElement(name = "DecDate", required = true)
  protected String DecDate;
  @XmlElement(name = "DecBy", required = true)
  protected String decBy;
  @XmlElement(name = "DecComments", required = true)
  protected String decComments;
}
