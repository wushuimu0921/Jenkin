package tw.com.transglobe.adp.integration.config;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tw.com.transglobe.adp.setting.opdate.OpDateCacheConfigFactory;
import tw.com.transglobe.adp.setting.opdate.OpDateSupplier;
import tw.com.transglobe.adp.setting.opdate.http.SettingOpDateApi;
import tw.com.transglobe.framework.cache.MultiCacheManager;

@Slf4j
@RequiredArgsConstructor
@Configuration(proxyBeanMethods = false)
@EnableConfigurationProperties(AdpIntegrationProperties.class)
class AdpIntegrationAutoConfiguration {

  final AdpIntegrationProperties properties;

  @Bean
  OpDateSupplier opDateSupplier(MultiCacheManager cacheManager, SettingOpDateApi settingOpDateApi) {
    return new OpDateSupplier(cacheManager, settingOpDateApi);
  }

  @Bean
  OpDateCacheConfigFactory opDateCacheConfigFactory() {
    return new OpDateCacheConfigFactory();
  }

}
