package tw.com.transglobe.adp.integration.aml.wsclient.xml;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "rel")
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
public class RelForXmlDto {

  @XmlElement(name = "CINO")
  String cino;

  @XmlElement(name = "TYPE")
  String type;

  @XmlElement(name = "HitCount", required = true)
  protected String hitCount;
  @XmlElement(name = "DecType", required = true)
  protected String decType;
  @XmlElement(name = "DecState", required = true)
  protected String decState;
  @XmlElement(name = "DecDate", required = true)
  protected String decDate;
  @XmlElement(name = "DecBy", required = true)
  protected String decBy;
  @XmlElement(name = "DecComments", required = true)
  protected String decComments;

  @XmlElement(name = "FIELD")
  List<FieldDto> fieldDto;

}
