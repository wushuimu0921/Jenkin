package tw.com.transglobe.adp.integration.ebao.kmiddle.wsclient;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.ws.BindingProvider;
import com.sun.xml.txw2.output.CharacterEscapeHandler;
import com.sun.xml.txw2.output.DataWriter;
import com.sun.xml.ws.developer.JAXWSProperties;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import tw.com.transglobe.adp.integration.commons.enums.ProductGroupType;
import tw.com.transglobe.adp.integration.commons.enums.Status;
import tw.com.transglobe.adp.integration.config.AdpIntegrationProperties;
import tw.com.transglobe.adp.integration.ebao.common.wsclient.RqHeader;
import tw.com.transglobe.adp.integration.ebao.common.wsclient.StandardRequest;
import tw.com.transglobe.adp.integration.ebao.common.wsclient.StandardResponse;
import tw.com.transglobe.adp.integration.ebao.kmiddle.service.KmiddleClaimVo;
import tw.com.transglobe.adp.integration.ebao.kmiddle.service.KmiddleCommonWsClient;
import tw.com.transglobe.adp.integration.ebao.kmiddle.service.KmiddlePolicyVo;
import tw.com.transglobe.adp.integration.ebao.kmiddle.wsclient.xml.cmn150req.Cmn150In;
import tw.com.transglobe.adp.integration.ebao.kmiddle.wsclient.xml.cmn150res.Cmn150Out;
import tw.com.transglobe.adp.integration.ebao.kmiddle.wsclient.xml.generated_rq.Cmn130In;
import tw.com.transglobe.adp.integration.ebao.kmiddle.wsclient.xml.generated_rs.Cmn130Out;

@Slf4j
@RequiredArgsConstructor
public class KmiddleCommonWsClientImpl implements KmiddleCommonWsClient {

  final AdpIntegrationProperties properties;
  final KmiddleMapper mapper;

  @SneakyThrows
  @Override
  public KmiddleClaimVo cmn130(ProductGroupType productGroupType, String type, String data) {
    var cmn130In = new Cmn130In();
    cmn130In.setType(type);
    cmn130In.setData(data);

    JAXBContext jaxbContext = JAXBContext.newInstance(Cmn130In.class);
    Marshaller marshaller = jaxbContext.createMarshaller();
    marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
    marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);

    var sw = new StringWriter();
    marshaller.marshal(cmn130In, sw);

    var xmlData = sw.toString();
    log.debug("cmn130 request:{}", xmlData);

    StandardResponse response = exchange("GroupClaimRecordQuery", productGroupType, xmlData);

    Status responseStatus = response.getRsHeader().getReturnMsg().equals("success") ? Status.SUCCESS : Status.FAIL;
    log.debug("kmiddle response:{}", responseStatus);
    if (response.getRsHeader().getReturnMsg().equals("success")) {
      JAXBContext jaxbResponseContext = JAXBContext.newInstance(Cmn130Out.class);
      Unmarshaller unmarshaller = jaxbResponseContext.createUnmarshaller();

      Cmn130Out out = (Cmn130Out) unmarshaller.unmarshal(new StringReader(response.getRsBody()));
      log.debug("Cmn130Out:{}", out);
      KmiddleClaimVo vo = mapper.toVo(out);
      log.debug("kmiddle response vo:{}", vo);
      return vo;
    } else {
      return null;
    }
  }

  @SneakyThrows
  @Override
  public List<KmiddlePolicyVo> cmn150(ProductGroupType productGroupType, String idno) {
    Cmn150In cmn150in = new Cmn150In();
    cmn150in.setType("2"); //1. 團險保單號碼    2. 被保人ID    3. 業務員身分證ID(屬於服務業務員或是領佣業務員)    4. 要保人ID
    cmn150in.setParam(idno);
    cmn150in.setPolicyStatus("A"); // A: 有效契約    B: 無效契約    C: 全部

    JAXBContext jaxbContext = JAXBContext.newInstance(Cmn150In.class);
    Marshaller marshaller = jaxbContext.createMarshaller();
    marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
    marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);

    var sw = new StringWriter();
    marshaller.marshal(cmn150in, sw);

    var xmlData = sw.toString();
    log.debug("cmn150 request:{}", xmlData);

    StandardResponse response = exchange("GroupPolicyListQuery", productGroupType, xmlData);

    Status responseStatus = response.getRsHeader().getReturnMsg().equals("success") ? Status.SUCCESS : Status.FAIL;
    log.debug("kmiddle response:{}", responseStatus);
    if (response.getRsHeader().getReturnMsg().equals("success")) {
      JAXBContext jaxbResponseContext = JAXBContext.newInstance(Cmn150Out.class);
      Unmarshaller unmarshaller = jaxbResponseContext.createUnmarshaller();

      Cmn150Out out = (Cmn150Out) unmarshaller.unmarshal(new StringReader(response.getRsBody()));
      log.debug("cmn150Out:{}", out);
      if (out != null) {
        List<KmiddlePolicyVo> vo = mapper.toVo(out.getGroupPolicyList().getGroupPolicy());
        log.debug("kmiddle response vo:{}", vo);
        return vo;
      }
    }

    return null;

  }

  @SneakyThrows
  private StandardResponse exchange(String serviceName, ProductGroupType productGroupType, String xmlData) {

    log.debug("xmlData:{}", xmlData);
    log.info("KMiddleWs Properties Url:{}", properties.getKMiddleWs().getUrl());
    CommonWSService serviceImpl = new CommonWSService(new URL(properties.getKMiddleWs().getUrl()));
    CommonWS service = serviceImpl.getCommonWSServicePort();

    Map<String, Object> requestContext = ((BindingProvider) service).getRequestContext();
    requestContext.put(JAXWSProperties.CONNECT_TIMEOUT, 30000);
    requestContext.put(JAXWSProperties.REQUEST_TIMEOUT, 60000);

    StandardRequest request = new StandardRequest();
    RqHeader header = new RqHeader();

    LocalDateTime now = LocalDateTime.now();
    header.setRqTimestamp(now);
    header.setRqUID(UUID.randomUUID().toString());

    request.setRqHeader(header);
    request.setServiceName(serviceName);
    request.setSystemId(productGroupType.toString());
    request.setRqBody(xmlData);

    if (log.isDebugEnabled()) {
      JAXBContext jaxbContext = JAXBContext.newInstance(StandardRequest.class);
      Marshaller marshaller = jaxbContext.createMarshaller();
      marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
      marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);

      StringWriter sw = new StringWriter();
      // for xml data *DO NOT* convert to &lt; &gt; etc.. to escape all characters
      PrintWriter pw = new PrintWriter(sw);
      DataWriter dw = new DataWriter(pw, "UTF-8", new CharacterEscapeHandler() {
        @Override
        public void escape(char[] buf, int start, int len, boolean b, Writer out) throws IOException {
          out.write(buf, start, len);
        }
      });
      marshaller.marshal(request, dw);
      String wsData = sw.toString();
      log.debug("xml data:{}", wsData);
    }

    StandardResponse response = service.exchange(request);
    log.debug("the response is \n {}", response);
    return response;

  }

}
