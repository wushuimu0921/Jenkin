package tw.com.transglobe.adp.integration.ebao.claim.service;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

@Data
@Builder
public class ClaimRecordQuery071RqCmd {

  String queryType;

  String queryParam;

  LocalDate startDate;

  LocalDate endDate;

  String isDC;

  String serviceRegisterCode;

  String reporterRegisterCode;

  Integer limitIndicator;

  String querySource;

}
