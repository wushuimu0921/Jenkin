package tw.com.transglobe.adp.integration.ebao.kmiddle.service.cmd;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EbaoFinanceQueryChequeCmd {
  String chequeNo; //支票號碼
}
