package tw.com.transglobe.adp.integration.aml.service;

public interface LyodsWebServiceClient {

  AmlCifResultVo fofExecCif(LyodsWebServiceCmd execCif);
}
