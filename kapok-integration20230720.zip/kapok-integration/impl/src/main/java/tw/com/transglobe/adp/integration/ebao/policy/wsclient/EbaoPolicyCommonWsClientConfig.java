package tw.com.transglobe.adp.integration.ebao.policy.wsclient;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tw.com.transglobe.adp.integration.config.AdpIntegrationProperties;
import tw.com.transglobe.adp.integration.ebao.finance.service.EbaoFinanceVoMapper;
import tw.com.transglobe.adp.integration.ebao.policy.service.EbaoPolicyCommonWsClient;

@Slf4j
@Configuration
class EbaoPolicyCommonWsClientConfig {

  @Bean
  @ConditionalOnMissingBean
  @ConditionalOnProperty(value = "ebao-policy-common-ws-client.enabled", havingValue = "false")
  public EbaoPolicyCommonWsClient ebaoPolicyCommonWsClientOfMock() {
    return new EbaoPolicyCommonWsClientMock();
  }

  @Bean
  @ConditionalOnProperty(value = "ebao-policy-common-ws-client.enabled", havingValue = "true")
  public EbaoPolicyCommonWsClient ebaoPolicyCommonWsClient(AdpIntegrationProperties properties, EbaoPolicyWsMapper mapper) {
    return new EbaoPolicyCommonWsClientImpl(properties, mapper);
  }
}
