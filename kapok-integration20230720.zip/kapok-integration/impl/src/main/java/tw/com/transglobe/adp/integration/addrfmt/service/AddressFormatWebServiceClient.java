package tw.com.transglobe.adp.integration.addrfmt.service;

public interface AddressFormatWebServiceClient {

  AddressFormatVo getAddressFormat(String inputAddress);

}
