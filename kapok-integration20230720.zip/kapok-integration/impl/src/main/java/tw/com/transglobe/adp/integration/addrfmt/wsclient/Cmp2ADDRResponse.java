
package tw.com.transglobe.adp.integration.addrfmt.wsclient;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * anonymous complex type �� Java ���O.
 *
 * <p>
 * �U�C���n���q�|���w�����O���]�t���w�����e.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Cmp2ADDRResult" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "cmp2ADDRResult"
})
@XmlRootElement(name = "Cmp2ADDRResponse")
public class Cmp2ADDRResponse {

  @XmlElement(name = "Cmp2ADDRResult")
  protected String cmp2ADDRResult;

  /**
   * ���o cmp2ADDRResult �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getCmp2ADDRResult() {
    return cmp2ADDRResult;
  }

  /**
   * �]�w cmp2ADDRResult �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCmp2ADDRResult(String value) {
    this.cmp2ADDRResult = value;
  }

}
