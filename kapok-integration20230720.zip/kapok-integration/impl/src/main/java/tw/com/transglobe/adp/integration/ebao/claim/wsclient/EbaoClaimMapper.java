package tw.com.transglobe.adp.integration.ebao.claim.wsclient;

import org.mapstruct.Mapper;
import tw.com.transglobe.adp.integration.ebao.claim.service.ClaimRecordQuery071RqCmd;
import tw.com.transglobe.adp.integration.ebao.claim.service.ClaimRecordQuery071RsCmd;
import tw.com.transglobe.adp.integration.ebao.claim.wsclient.xml.ClaimRecordQuery071Rq;
import tw.com.transglobe.adp.integration.ebao.claim.wsclient.xml.ClaimRecordQuery071Rs;

@Mapper
public interface EbaoClaimMapper {

  ClaimRecordQuery071Rq toRq(ClaimRecordQuery071RqCmd cmd);

  ClaimRecordQuery071RsCmd toRsCmd(ClaimRecordQuery071Rs cmd);
}
