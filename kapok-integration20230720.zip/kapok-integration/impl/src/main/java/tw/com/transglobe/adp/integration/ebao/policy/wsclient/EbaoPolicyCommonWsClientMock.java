package tw.com.transglobe.adp.integration.ebao.policy.wsclient;

import com.google.common.collect.Lists;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import tw.com.transglobe.adp.integration.commons.enums.ProductGroupType;
import tw.com.transglobe.adp.integration.ebao.policy.service.EbaoPolicyCommonVo;
import tw.com.transglobe.adp.integration.ebao.policy.service.EbaoPolicyCommonWsClient;

import java.util.List;

@Slf4j
@RequiredArgsConstructor
public class EbaoPolicyCommonWsClientMock implements EbaoPolicyCommonWsClient {

  @SneakyThrows
  @Override
  public List<EbaoPolicyCommonVo> getPolicy(ProductGroupType productGroupType, String idno) {
    return Lists.newArrayList();
  }
}
