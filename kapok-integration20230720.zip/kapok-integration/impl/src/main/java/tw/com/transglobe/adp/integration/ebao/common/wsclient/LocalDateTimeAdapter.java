package tw.com.transglobe.adp.integration.ebao.common.wsclient;

import javax.xml.bind.annotation.adapters.XmlAdapter;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class LocalDateTimeAdapter extends XmlAdapter<String, LocalDateTime> {

  final DateTimeFormatter formatter_hyphen = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
  final DateTimeFormatter formatter_slash = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");

  @Override
  public LocalDateTime unmarshal(String v) throws Exception {
    if (v == null)
      return null;

    return LocalDateTime.parse(v, formatter_hyphen);

  }

  @Override
  public String marshal(LocalDateTime v) throws Exception {
    return v.format(formatter_hyphen);
  }

}
