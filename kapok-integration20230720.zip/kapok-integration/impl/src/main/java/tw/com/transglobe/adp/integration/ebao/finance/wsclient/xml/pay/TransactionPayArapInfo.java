//
// ���ɮ׬O�� JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.3.0 �Ҳ���
// �аѾ\ <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a>
// �@�����s�sĶ�ӷ����n, �惡�ɮשҰ�������קﳣ�N�|��.
// ���ͮɶ�: 2022.05.28 �� 10:58:57 AM CST
//

package tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.pay;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * transactionPayArapInfo complex type �� Java ���O.
 *
 * <p>
 * �U�C���n���q�|���w�����O���]�t���w�����e.
 *
 * <pre>
 * &lt;complexType name="transactionPayArapInfo"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{}abstractArapInfo"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ClmCaseNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ClmAuditDecision" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="LiabCategory" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LiabId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ClmAccidentAge" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="InsuredCertiType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="InsuredCertiCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="InsuredGender" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="InsuredEntryAge" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="PayeeNationality" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "transactionPayArapInfo", propOrder = {
    "clmCaseNo",
    "clmAuditDecision",
    "liabCategory",
    "liabId",
    "clmAccidentAge",
    "insuredCertiType",
    "insuredCertiCode",
    "insuredGender",
    "insuredEntryAge",
    "payeeNationality"
})
public class TransactionPayArapInfo extends AbstractArapInfo {

  @XmlElement(name = "ClmCaseNo")
  protected String clmCaseNo;
  @XmlElement(name = "ClmAuditDecision")
  protected Integer clmAuditDecision;
  @XmlElement(name = "LiabCategory")
  protected String liabCategory;
  @XmlElement(name = "LiabId")
  protected String liabId;
  @XmlElement(name = "ClmAccidentAge")
  protected Long clmAccidentAge;
  @XmlElement(name = "InsuredCertiType")
  protected String insuredCertiType;
  @XmlElement(name = "InsuredCertiCode")
  protected String insuredCertiCode;
  @XmlElement(name = "InsuredGender")
  protected String insuredGender;
  @XmlElement(name = "InsuredEntryAge")
  protected Integer insuredEntryAge;
  @XmlElement(name = "PayeeNationality")
  protected String payeeNationality;

  /**
   * ���o clmCaseNo �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getClmCaseNo() {
    return clmCaseNo;
  }

  /**
   * �]�w clmCaseNo �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setClmCaseNo(String value) {
    this.clmCaseNo = value;
  }

  /**
   * ���o clmAuditDecision �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link Integer }
   *
   */
  public Integer getClmAuditDecision() {
    return clmAuditDecision;
  }

  /**
   * �]�w clmAuditDecision �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link Integer }
   *
   */
  public void setClmAuditDecision(Integer value) {
    this.clmAuditDecision = value;
  }

  /**
   * ���o liabCategory �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getLiabCategory() {
    return liabCategory;
  }

  /**
   * �]�w liabCategory �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setLiabCategory(String value) {
    this.liabCategory = value;
  }

  /**
   * ���o liabId �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getLiabId() {
    return liabId;
  }

  /**
   * �]�w liabId �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setLiabId(String value) {
    this.liabId = value;
  }

  /**
   * ���o clmAccidentAge �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link Long }
   *
   */
  public Long getClmAccidentAge() {
    return clmAccidentAge;
  }

  /**
   * �]�w clmAccidentAge �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link Long }
   *
   */
  public void setClmAccidentAge(Long value) {
    this.clmAccidentAge = value;
  }

  /**
   * ���o insuredCertiType �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getInsuredCertiType() {
    return insuredCertiType;
  }

  /**
   * �]�w insuredCertiType �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setInsuredCertiType(String value) {
    this.insuredCertiType = value;
  }

  /**
   * ���o insuredCertiCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getInsuredCertiCode() {
    return insuredCertiCode;
  }

  /**
   * �]�w insuredCertiCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setInsuredCertiCode(String value) {
    this.insuredCertiCode = value;
  }

  /**
   * ���o insuredGender �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getInsuredGender() {
    return insuredGender;
  }

  /**
   * �]�w insuredGender �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setInsuredGender(String value) {
    this.insuredGender = value;
  }

  /**
   * ���o insuredEntryAge �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link Integer }
   *
   */
  public Integer getInsuredEntryAge() {
    return insuredEntryAge;
  }

  /**
   * �]�w insuredEntryAge �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link Integer }
   *
   */
  public void setInsuredEntryAge(Integer value) {
    this.insuredEntryAge = value;
  }

  /**
   * ���o payeeNationality �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getPayeeNationality() {
    return payeeNationality;
  }

  /**
   * �]�w payeeNationality �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setPayeeNationality(String value) {
    this.payeeNationality = value;
  }

}
