
package tw.com.transglobe.adp.integration.aml.service;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Slf4j
public class LyodsWebServiceCmd {

  String appCode;
  String unit;
  String callType;

  String userdata;
  String calc;
  String isFull;

  AmlCifData cif;
  List<AmlRelData> rels;
  List<AmlAccData> acc;

}
