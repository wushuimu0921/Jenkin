package tw.com.transglobe.adp.integration.esp.wsclient.request;

import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotEmpty;

/**
 * ESP 確認來源用
 *
 * @author Default User
 *
 */
@Data
@Builder
public class EspHeader {

  @NotEmpty
  String requesterSystem; // ADP
  @NotEmpty
  String requesterID; // GI

  String requesterPwd;

}
