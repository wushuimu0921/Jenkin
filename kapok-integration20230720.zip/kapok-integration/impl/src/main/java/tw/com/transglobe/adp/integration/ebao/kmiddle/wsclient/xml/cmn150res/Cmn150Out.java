//
// ���ɮ׬O�� JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.3.0 �Ҳ���
// �аѾ\ <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a>
// �@�����s�sĶ�ӷ����n, �惡�ɮשҰ�������קﳣ�N�|��.
// ���ͮɶ�: 2022.11.17 �� 02:36:56 PM CST
//

package tw.com.transglobe.adp.integration.ebao.kmiddle.wsclient.xml.cmn150res;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.*;

/**
 * <p>
 * cmn150Out complex type �� Java ���O.
 *
 * <p>
 * �U�C���n���q�|���w�����O���]�t���w�����e.
 *
 * <pre>
 * &lt;complexType name="cmn150Out"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="GroupPolicyList" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="GroupPolicy" type="{}cmn150OutC1" maxOccurs="unbounded" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "cmn150Out", propOrder = {
    "groupPolicyList"
})
@XmlRootElement(name = "GroupPolicyListQueryRs")
public class Cmn150Out {

  @XmlElement(name = "GroupPolicyList")
  protected Cmn150Out.GroupPolicyList groupPolicyList;

  /**
   * ���o groupPolicyList �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link Cmn150Out.GroupPolicyList }
   *
   */
  public Cmn150Out.GroupPolicyList getGroupPolicyList() {
    return groupPolicyList;
  }

  /**
   * �]�w groupPolicyList �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link Cmn150Out.GroupPolicyList }
   *
   */
  public void setGroupPolicyList(Cmn150Out.GroupPolicyList value) {
    this.groupPolicyList = value;
  }

  /**
   * <p>
   * anonymous complex type �� Java ���O.
   *
   * <p>
   * �U�C���n���q�|���w�����O���]�t���w�����e.
   *
   * <pre>
   * &lt;complexType&gt;
   *   &lt;complexContent&gt;
   *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
   *       &lt;sequence&gt;
   *         &lt;element name="GroupPolicy" type="{}cmn150OutC1" maxOccurs="unbounded" minOccurs="0"/&gt;
   *       &lt;/sequence&gt;
   *     &lt;/restriction&gt;
   *   &lt;/complexContent&gt;
   * &lt;/complexType&gt;
   * </pre>
   *
   *
   */
  @XmlAccessorType(XmlAccessType.FIELD)
  @XmlType(name = "", propOrder = {
      "groupPolicy"
  })
  public static class GroupPolicyList {

    @XmlElement(name = "GroupPolicy")
    protected List<Cmn150OutC1> groupPolicy;

    /**
     * Gets the value of the groupPolicy property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the groupPolicy property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     *
     * <pre>
     * getGroupPolicy().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Cmn150OutC1 }
     *
     *
     */
    public List<Cmn150OutC1> getGroupPolicy() {
      if (groupPolicy == null) {
        groupPolicy = new ArrayList<Cmn150OutC1>();
      }
      return this.groupPolicy;
    }

  }

}
