//
// ���ɮ׬O�� JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.3.0 �Ҳ���
// �аѾ\ <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a>
// �@�����s�sĶ�ӷ����n, �惡�ɮשҰ�������קﳣ�N�|��.
// ���ͮɶ�: 2022.05.28 �� 10:58:49 AM CST
//

package tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.col;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the tw.com.transglobe.kapok.integration.ebao.wsclient.xml.col package.
 * <p>
 * An ObjectFactory allows you to programatically
 * construct new instances of the Java representation
 * for XML content. The Java representation of XML
 * content can consist of schema derived interfaces
 * and classes representing the binding of schema
 * type definitions, element declarations and model
 * groups. Factory methods for each of these are
 * provided in this class.
 *
 */
@XmlRegistry
public class ObjectFactory {

  private final static QName _CollectionInfo_QNAME = new QName("", "CollectionInfo");
  private final static QName _GlTransColMixedRq_QNAME = new QName("", "GlTransColMixedRq");
  private final static QName _TransArapInfo_QNAME = new QName("", "TransArapInfo");
  private final static QName _TransColInfo_QNAME = new QName("", "TransColInfo");

  /**
   * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package:
   * tw.com.transglobe.kapok.integration.ebao.wsclient.xml.col
   *
   */
  public ObjectFactory() {
  }

  /**
   * Create an instance of {@link TransactionColMixedInfo }
   *
   */
  public TransactionColMixedInfo createTransactionColMixedInfo() {
    return new TransactionColMixedInfo();
  }

  /**
   * Create an instance of {@link CreateTransactionColMixedRq }
   *
   */
  public CreateTransactionColMixedRq createCreateTransactionColMixedRq() {
    return new CreateTransactionColMixedRq();
  }

  /**
   * Create an instance of {@link CollectionInfo }
   *
   */
  public CollectionInfo createCollectionInfo() {
    return new CollectionInfo();
  }

  /**
   * Create an instance of {@link TransactionColArapInfo }
   *
   */
  public TransactionColArapInfo createTransactionColArapInfo() {
    return new TransactionColArapInfo();
  }

  /**
   * Create an instance of {@link AbstractArapInfo }
   *
   */
  public AbstractArapInfo createAbstractArapInfo() {
    return new AbstractArapInfo();
  }

  /**
   * Create an instance of {@link TransactionColMixedInfo.CollectionInfos }
   *
   */
  public TransactionColMixedInfo.CollectionInfos createTransactionColMixedInfoCollectionInfos() {
    return new TransactionColMixedInfo.CollectionInfos();
  }

  /**
   * Create an instance of {@link TransactionColMixedInfo.ReceivableInfos }
   *
   */
  public TransactionColMixedInfo.ReceivableInfos createTransactionColMixedInfoReceivableInfos() {
    return new TransactionColMixedInfo.ReceivableInfos();
  }

  /**
   * Create an instance of {@link CreateTransactionColMixedRq.TransColMixedInfos }
   *
   */
  public CreateTransactionColMixedRq.TransColMixedInfos createCreateTransactionColMixedRqTransColMixedInfos() {
    return new CreateTransactionColMixedRq.TransColMixedInfos();
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link CollectionInfo }{@code >}
   *
   * @param value
   *        Java instance representing xml element's value.
   * @return
   *         the new instance of {@link JAXBElement }{@code <}{@link CollectionInfo }{@code >}
   */
  @XmlElementDecl(namespace = "", name = "CollectionInfo")
  public JAXBElement<CollectionInfo> createCollectionInfo(CollectionInfo value) {
    return new JAXBElement<CollectionInfo>(_CollectionInfo_QNAME, CollectionInfo.class, null, value);
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link CreateTransactionColMixedRq }{@code >}
   *
   * @param value
   *        Java instance representing xml element's value.
   * @return
   *         the new instance of {@link JAXBElement }{@code <}{@link CreateTransactionColMixedRq }{@code >}
   */
  @XmlElementDecl(namespace = "", name = "GlTransColMixedRq")
  public JAXBElement<CreateTransactionColMixedRq> createGlTransColMixedRq(CreateTransactionColMixedRq value) {
    return new JAXBElement<CreateTransactionColMixedRq>(_GlTransColMixedRq_QNAME, CreateTransactionColMixedRq.class, null,
        value);
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link Object }{@code >}
   *
   * @param value
   *        Java instance representing xml element's value.
   * @return
   *         the new instance of {@link JAXBElement }{@code <}{@link Object }{@code >}
   */
  @XmlElementDecl(namespace = "", name = "TransArapInfo")
  public JAXBElement<Object> createTransArapInfo(Object value) {
    return new JAXBElement<Object>(_TransArapInfo_QNAME, Object.class, null, value);
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link TransactionColMixedInfo }{@code >}
   *
   * @param value
   *        Java instance representing xml element's value.
   * @return
   *         the new instance of {@link JAXBElement }{@code <}{@link TransactionColMixedInfo }{@code >}
   */
  @XmlElementDecl(namespace = "", name = "TransColInfo")
  public JAXBElement<TransactionColMixedInfo> createTransColInfo(TransactionColMixedInfo value) {
    return new JAXBElement<TransactionColMixedInfo>(_TransColInfo_QNAME, TransactionColMixedInfo.class, null, value);
  }

}
