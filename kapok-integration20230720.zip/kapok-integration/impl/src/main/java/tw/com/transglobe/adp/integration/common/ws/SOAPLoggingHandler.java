package tw.com.transglobe.adp.integration.common.ws;

import java.io.IOException;
import java.util.Set;
import javax.xml.namespace.QName;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SOAPLoggingHandler implements SOAPHandler<SOAPMessageContext> {
  public Set<QName> getHeaders() {
    return null;
  }

  public boolean handleMessage(SOAPMessageContext smc) {
    Boolean isRequest = (Boolean) smc.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);
    if (isRequest) {
      log.info("[SOAP Request]");
    } else {
      log.info("[SOAP Response]");
    }
    SOAPMessage message = smc.getMessage();
    try {
      SOAPEnvelope envelope = message.getSOAPPart().getEnvelope();
      SOAPHeader header = envelope.getHeader();
      log.info("header: {}", header);
      log.info("message: {}", message);
    } catch (SOAPException e) {
      // TODO Auto-generated catch block
      log.error("SOAPLoggingHandler", e);
    }
    return true;
  }

  public boolean handleFault(SOAPMessageContext smc) {
    log.error("{}", smc);
    return true;
  }

  // nothing to clean up
  public void close(MessageContext messageContext) {
  }

}
