package tw.com.transglobe.adp.integration.crystalreport.wsclient;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
class EspCrParameter {
  String key;
  String value;
  String type;
  String isArray;
}
