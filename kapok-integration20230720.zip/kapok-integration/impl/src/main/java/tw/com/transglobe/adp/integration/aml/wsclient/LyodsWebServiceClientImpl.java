package tw.com.transglobe.adp.integration.aml.wsclient;

import com.google.common.collect.Lists;
import java.util.ArrayList;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.util.CollectionUtils;
import tw.com.transglobe.adp.integration.aml.service.AmlAccData;
import tw.com.transglobe.adp.integration.aml.service.AmlCifData;
import tw.com.transglobe.adp.integration.aml.service.AmlCifResultVo;
import tw.com.transglobe.adp.integration.aml.service.AmlRelData;
import tw.com.transglobe.adp.integration.aml.service.AmlRelResultVo;
import tw.com.transglobe.adp.integration.aml.service.AmlResultVo;
import tw.com.transglobe.adp.integration.aml.service.LyodsWebServiceClient;
import tw.com.transglobe.adp.integration.aml.service.LyodsWebServiceCmd;
import tw.com.transglobe.adp.integration.aml.wsclient.xml.AccForXmlDto;
import tw.com.transglobe.adp.integration.aml.wsclient.xml.CifForXmlDto;
import tw.com.transglobe.adp.integration.aml.wsclient.xml.FieldDto;
import tw.com.transglobe.adp.integration.aml.wsclient.xml.FircoDto;
import tw.com.transglobe.adp.integration.aml.wsclient.xml.RelForXmlDto;
import tw.com.transglobe.adp.integration.common.exception.NotFoundException;
import tw.com.transglobe.adp.integration.config.AdpIntegrationProperties;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.StringReader;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

@Slf4j
@RequiredArgsConstructor
class LyodsWebServiceClientImpl implements LyodsWebServiceClient {

  final AdpIntegrationProperties properties;

  // TODO: move to properties
  static final String SYSTEM_CODE = "ADP";
  static final String SERVICE_NAME = "AML";
  static final String UNDER_LINE = "_";

  @Override
  @SneakyThrows
  public AmlCifResultVo fofExecCif(LyodsWebServiceCmd cmd) {
    // TODO 以下固定寫死在程式的應搬到 propverties
    //    LyodsWebServiceService lyodsWebServiceImpl = new LyodsWebServiceService();
    //    var resource = new ClassPathResource("wsdl/aml-service.wsdl");
    LyodsWebServiceService lyodsWebServiceImpl = new LyodsWebServiceService(new URL(properties.getAml().getUrl()));
    LyodsWebService lyodsWebService = lyodsWebServiceImpl.getLyodsWebServicePort();
    DateTimeFormatter df1 = DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS");
    LocalDateTime now = LocalDateTime.now();
    String messageId = SYSTEM_CODE + "-" + SERVICE_NAME + "-" + Thread.currentThread().getId() + "-" + df1.format(
        now);
    String fmt = "DEFAULT";
    DateTimeFormatter df2 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    String dataXml = "";

    // 主要客戶 (要保單位, 要保人)
    if (cmd.getCif() == null) {
      throw new NotFoundException("至少要有一筆客戶資訊 CIF");
    }
    final String cinoSuffix = getCinoSuffix(cmd.getCif());
    String cifXml = generateCifXml(cmd, cinoSuffix);
    dataXml = cifXml + "\n\r";

    // 關係人
    if (cmd.getRels() != null) {
      for (AmlRelData rel : cmd.getRels()) {
        String relXml = generateRelXml(rel, cinoSuffix);
        dataXml += relXml + "\n\r";
      }
    }

    // 帳戶
    if (cmd.getAcc() != null) {
      for (AmlAccData acc : cmd.getAcc()) {
        String accXml = generateAccXml(acc, cinoSuffix);
        dataXml += accXml + "\n\r";
      }
    }

    log.debug("fofExecCif xml before:{}", dataXml);
    log.debug("fofExecCif head before:{}-{}-{}-{}-{}-{}", cmd.getAppCode(), cmd.getUnit(), cmd.getCallType(), cmd.getUserdata(),
        cmd.getCalc(), cmd.getIsFull());

    //dataXml = "<![CDATA[" + dataXml + "]]>";

    var response = lyodsWebService.fofExecCif(cmd.getAppCode(),
        cmd.getUnit(),
        cmd.getCallType(),
        messageId, fmt,
        "", // usercode keep empty
        cmd.getUserdata(),
        cmd.getCalc(),
        cmd.getIsFull(),
        df2.format(now),
        dataXml,
        null,
        null);

    log.debug("fofExecCif xml after:{}", response);

    return toResultVo(response);
  }

  /**
   * 客戶編號後綴統一
   *
   * @param cifData
   * @return
   */
  private String getCinoSuffix(final AmlCifData cifData) {
    final List<FieldDto> fields = new ArrayList<>();
    if (cifData.fields() != null) {
      for (String key : cifData.fields().keySet()) {
        fields.add(new FieldDto(key, cifData.fields().get(key)));
      }
    }
    return fields.stream()
        .filter(fieldDto -> "usage".equals(fieldDto.getName()))
        .findFirst()
        .map(fieldDto -> "T".equals(fieldDto.getDescription()) ? "TA" : "GRP")
        .orElse("");
  }

  private String cifCinoToIdno(final String cino) {
    return StringUtils.isNotBlank(cino) ? cino.split(UNDER_LINE)[0] : cino;
  }

  private String generateCifXml(LyodsWebServiceCmd cmd, String cinoSuffix) throws JAXBException {
    JAXBContext jaxbContext = JAXBContext.newInstance(CifForXmlDto.class);
    Marshaller marshaller = jaxbContext.createMarshaller();
    marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
    marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);

    List<FieldDto> fields = Lists.newArrayList();
    if (cmd.getCif().fields() != null) {
      for (String key : cmd.getCif().fields().keySet()) {
        fields.add(new FieldDto(key, cmd.getCif().fields().get(key)));
      }
    }

    final String cino = StringUtils.isNotEmpty(cinoSuffix) ? String.join(UNDER_LINE, cmd.getCif().idno(), cinoSuffix)
        : cmd.getCif().idno();

    CifForXmlDto cifXml = CifForXmlDto.builder()
        .cino(cino)
        .type(cmd.getCif().type().toString())
        .fieldDto(fields)
        .build();

    StringWriter sw = new StringWriter();

    marshaller.marshal(cifXml, sw);

    String xmlData = sw.toString();

    log.debug("generateCifXml {}", xmlData);

    return xmlData;
  }

  private String relIdnoToCino(final String idno, final List<FieldDto> fields) {
    final String cinoSuffix = fields.stream()
        .filter(fieldDto -> "usage".equals(fieldDto.getName()))
        .findFirst()
        .map(fieldDto -> "T".equals(fieldDto.getDescription()) ? "TA" : "GRP")
        .orElse("");
    return StringUtils.isNotEmpty(cinoSuffix) ? String.join(UNDER_LINE, idno, cinoSuffix) : idno;
  }

  private String relCinoToIdno(final String cino) {
    return StringUtils.isNotBlank(cino) ? cino.split(UNDER_LINE)[0] : cino;
  }

  private String generateRelXml(AmlRelData relData, final String cinoSuffix) throws JAXBException {
    JAXBContext jaxbContext = JAXBContext.newInstance(RelForXmlDto.class);
    Marshaller marshaller = jaxbContext.createMarshaller();
    marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
    marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);

    List<FieldDto> fields = Lists.newArrayList();

    if (relData.fields() != null) {
      for (String key : relData.fields().keySet()) {
        fields.add(new FieldDto(key, relData.fields().get(key)));
      }
    }

    final String cino = StringUtils.isNotEmpty(cinoSuffix) ? String.join(UNDER_LINE, relData.idno(), cinoSuffix)
        : relData.idno();

    RelForXmlDto cifXml = RelForXmlDto.builder()
        .cino(cino)
        .type(relData.type().toString())
        .fieldDto(fields)
        .build();

    StringWriter sw = new StringWriter();

    marshaller.marshal(cifXml, sw);

    String xmlData = sw.toString();

    log.debug("generateRelXml {}", xmlData);

    return xmlData;
  }

  private String generateAccXml(AmlAccData accData, final String cinoSuffix) throws JAXBException {
    JAXBContext jaxbContext = JAXBContext.newInstance(AccForXmlDto.class);
    Marshaller marshaller = jaxbContext.createMarshaller();
    marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
    marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);

    List<FieldDto> fields = Lists.newArrayList();

    if (accData.fields() != null) {
      for (String key : accData.fields().keySet()) {
        fields.add(new FieldDto(key, accData.fields().get(key)));
      }
    }

    final String cino = StringUtils.isNotEmpty(cinoSuffix) ? String.join(UNDER_LINE, accData.idno(), cinoSuffix)
        : accData.idno();

    AccForXmlDto accXml = AccForXmlDto.builder()
        .cino(cino)
        .type(accData.type().toString())
        .fieldDto(fields)
        .build();

    StringWriter sw = new StringWriter();

    marshaller.marshal(accXml, sw);

    String xmlData = sw.toString();

    log.debug("generateAccXml {}", xmlData);

    return xmlData;
  }

  private AmlCifResultVo toResultVo(String response) throws JAXBException {

    JAXBContext jaxbContext = JAXBContext.newInstance(FircoDto.class);
    Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();

    FircoDto fircoDto = (FircoDto) unmarshaller.unmarshal(new StringReader(response));
    log.info("fircoDto{}", fircoDto);
    DateTimeFormatter stdDateFmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    AmlCifResultVo cifResult = new AmlCifResultVo();
    if (fircoDto.getCif() != null) {
      cifResult.setIdno(cifCinoToIdno(fircoDto.getCif().getCino()));
    }

    if (fircoDto.getRet() != null) {
      cifResult.setHitCount(NumberUtils.toInt(fircoDto.getRet().getHitCount(), 999));
      cifResult.setDecType(fircoDto.getRet().getDecType());
      cifResult.setDecState(fircoDto.getRet().getDecState());
      if (StringUtils.isNotBlank(fircoDto.getRet().getDecDate())) {
        cifResult.setDecDate(LocalDateTime.parse(fircoDto.getRet().getDecDate(), stdDateFmt));
      }
      cifResult.setDecBy(fircoDto.getRet().getDecBy());
      cifResult.setDecComments(fircoDto.getRet().getDecComments());
    }

    if (Optional.ofNullable(fircoDto.getCalcDto()).isPresent()) {
      if (StringUtils.isNotEmpty(fircoDto.getCalcDto().getDate()) &&
          StringUtils.isNotEmpty(fircoDto.getCalcDto().getScore())) {
        cifResult.setCalculateDate(LocalDateTime.parse(fircoDto.getCalcDto().getDate(), stdDateFmt));
        // todo fix score to bigdecimal
        cifResult.setCalculateScore(new BigDecimal(fircoDto.getCalcDto().getScore()).intValue());
        if (StringUtils.isNotBlank(fircoDto.getCalcDto().getRiskLevel())) {
          cifResult.setCalculateLevel(fircoDto.getCalcDto().getRiskLevel());
        } else {
          cifResult.setCalculateLevel(fircoDto.getCalcDto().getLevel());
        }
        cifResult.setCalculateReview((Integer.parseInt(fircoDto.getCalcDto().getReview())));
      }
    }

    if (cifResult.getHitCount() > 0) {
      if (cifResult.getDecType().equals("NEW") || cifResult.getDecType().equals("PENDING")
          || cifResult.getDecType().equals("CANCEL") || cifResult.getDecType().equals("FAILED")) {
        cifResult.setResult(AmlResultVo.PENDING);
      } else if (cifResult.getDecType().equals("FALSE")) {
        cifResult.setResult(AmlResultVo.NOHIT);
      } else if (cifResult.getDecType().equals("TRUE")) {
        if (cifResult.getDecState().contains("SAN")) {
          cifResult.setResult(AmlResultVo.SANCTION);
        } else if (cifResult.getDecState().contains("NOHIT")) {
          cifResult.setResult(AmlResultVo.NOHIT);
        } else {
          cifResult.setResult(AmlResultVo.WARN);
        }
      } else {
        cifResult.setResult(AmlResultVo.WARN);
      }

    } else {
      cifResult.setResult(AmlResultVo.NOHIT);
    }

    List<AmlRelResultVo> rels = Lists.newArrayList();

    if (!CollectionUtils.isEmpty(fircoDto.getRels())) {
      for (RelForXmlDto relXmlDto : fircoDto.getRels()) {
        AmlRelResultVo vo = new AmlRelResultVo();
        vo.setIdno(relCinoToIdno(relXmlDto.getCino()));
        vo.setHitCount(NumberUtils.toInt(relXmlDto.getHitCount(), 999));
        vo.setDecType(relXmlDto.getDecType());
        vo.setDecState(relXmlDto.getDecState());
        if (StringUtils.isNotBlank(relXmlDto.getDecDate())) {
          vo.setDecDate(LocalDateTime.parse(relXmlDto.getDecDate(), stdDateFmt));
        }
        vo.setDecBy(relXmlDto.getDecBy());
        vo.setDecComments(relXmlDto.getDecComments());

        if (vo.getHitCount() > 0) {
          if (vo.getDecType().equals("NEW") || vo.getDecType().equals("PENDING")
              || vo.getDecType().equals("CANCEL") || vo.getDecType().equals("FAILED")) {
            vo.setResult(AmlResultVo.PENDING);
          } else if (vo.getDecType().equals("FALSE")) {
            vo.setResult(AmlResultVo.NOHIT);
          } else if (vo.getDecType().equals("TRUE")) {
            if (vo.getDecState().contains("SAN")) {
              vo.setResult(AmlResultVo.SANCTION);
            } else if (vo.getDecState().contains("NOHIT")) {
              vo.setResult(AmlResultVo.NOHIT);
            } else {
              vo.setResult(AmlResultVo.WARN);
            }
          } else {
            vo.setResult(AmlResultVo.WARN);
          }

        } else {
          vo.setResult(AmlResultVo.NOHIT);
        }

        rels.add(vo);
      }
    }

    cifResult.setRels(rels);
    return cifResult;
  }

}
