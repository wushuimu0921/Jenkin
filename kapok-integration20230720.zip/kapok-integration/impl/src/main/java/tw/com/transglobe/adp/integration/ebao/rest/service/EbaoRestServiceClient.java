package tw.com.transglobe.adp.integration.ebao.rest.service;

import java.util.List;

public interface EbaoRestServiceClient {

  List<EbaoRestQmlistVo> getQmlist(EbaoRestQmlistCriteria criteria);

}
