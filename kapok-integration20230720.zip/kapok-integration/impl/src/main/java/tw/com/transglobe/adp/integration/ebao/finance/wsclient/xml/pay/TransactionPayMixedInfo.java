//
// ���ɮ׬O�� JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.3.0 �Ҳ���
// �аѾ\ <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a>
// �@�����s�sĶ�ӷ����n, �惡�ɮשҰ�������קﳣ�N�|��.
// ���ͮɶ�: 2022.05.28 �� 10:58:57 AM CST
//

package tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.pay;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * transactionPayMixedInfo complex type �� Java ���O.
 *
 * <p>
 * �U�C���n���q�|���w�����O���]�t���w�����e.
 *
 * <pre>
 * &lt;complexType name="transactionPayMixedInfo"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="TransSeq" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="PaymentInfos" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element ref="{}PaymentInfo" maxOccurs="unbounded"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PayableInfos" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="PayableInfo" type="{}transactionPayArapInfo" maxOccurs="unbounded"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "transactionPayMixedInfo", propOrder = {
    "transSeq",
    "paymentInfos",
    "payableInfos"
})
public class TransactionPayMixedInfo {

  @XmlElement(name = "TransSeq")
  protected int transSeq;
  @XmlElement(name = "PaymentInfos")
  protected TransactionPayMixedInfo.PaymentInfos paymentInfos;
  @XmlElement(name = "PayableInfos")
  protected TransactionPayMixedInfo.PayableInfos payableInfos;

  /**
   * ���o transSeq �S�ʪ���.
   *
   */
  public int getTransSeq() {
    return transSeq;
  }

  /**
   * �]�w transSeq �S�ʪ���.
   *
   */
  public void setTransSeq(int value) {
    this.transSeq = value;
  }

  /**
   * ���o paymentInfos �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link TransactionPayMixedInfo.PaymentInfos }
   *
   */
  public TransactionPayMixedInfo.PaymentInfos getPaymentInfos() {
    return paymentInfos;
  }

  /**
   * �]�w paymentInfos �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link TransactionPayMixedInfo.PaymentInfos }
   *
   */
  public void setPaymentInfos(TransactionPayMixedInfo.PaymentInfos value) {
    this.paymentInfos = value;
  }

  /**
   * ���o payableInfos �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link TransactionPayMixedInfo.PayableInfos }
   *
   */
  public TransactionPayMixedInfo.PayableInfos getPayableInfos() {
    return payableInfos;
  }

  /**
   * �]�w payableInfos �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link TransactionPayMixedInfo.PayableInfos }
   *
   */
  public void setPayableInfos(TransactionPayMixedInfo.PayableInfos value) {
    this.payableInfos = value;
  }

  /**
   * <p>
   * anonymous complex type �� Java ���O.
   *
   * <p>
   * �U�C���n���q�|���w�����O���]�t���w�����e.
   *
   * <pre>
   * &lt;complexType&gt;
   *   &lt;complexContent&gt;
   *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
   *       &lt;sequence&gt;
   *         &lt;element name="PayableInfo" type="{}transactionPayArapInfo" maxOccurs="unbounded"/&gt;
   *       &lt;/sequence&gt;
   *     &lt;/restriction&gt;
   *   &lt;/complexContent&gt;
   * &lt;/complexType&gt;
   * </pre>
   *
   *
   */
  @XmlAccessorType(XmlAccessType.FIELD)
  @XmlType(name = "", propOrder = {
      "payableInfo"
  })
  public static class PayableInfos {

    @XmlElement(name = "PayableInfo", required = true)
    protected List<TransactionPayArapInfo> payableInfo;

    /**
     * Gets the value of the payableInfo property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the payableInfo property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     *
     * <pre>
     * getPayableInfo().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TransactionPayArapInfo }
     *
     *
     */
    public List<TransactionPayArapInfo> getPayableInfo() {
      if (payableInfo == null) {
        payableInfo = new ArrayList<TransactionPayArapInfo>();
      }
      return this.payableInfo;
    }

  }

  /**
   * <p>
   * anonymous complex type �� Java ���O.
   *
   * <p>
   * �U�C���n���q�|���w�����O���]�t���w�����e.
   *
   * <pre>
   * &lt;complexType&gt;
   *   &lt;complexContent&gt;
   *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
   *       &lt;sequence&gt;
   *         &lt;element ref="{}PaymentInfo" maxOccurs="unbounded"/&gt;
   *       &lt;/sequence&gt;
   *     &lt;/restriction&gt;
   *   &lt;/complexContent&gt;
   * &lt;/complexType&gt;
   * </pre>
   *
   *
   */
  @XmlAccessorType(XmlAccessType.FIELD)
  @XmlType(name = "", propOrder = {
      "paymentInfo"
  })
  public static class PaymentInfos {

    @XmlElement(name = "PaymentInfo", required = true)
    protected List<PaymentInfo> paymentInfo;

    /**
     * Gets the value of the paymentInfo property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the paymentInfo property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     *
     * <pre>
     * getPaymentInfo().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PaymentInfo }
     *
     *
     */
    public List<PaymentInfo> getPaymentInfo() {
      if (paymentInfo == null) {
        paymentInfo = new ArrayList<PaymentInfo>();
      }
      return this.paymentInfo;
    }

  }

}
