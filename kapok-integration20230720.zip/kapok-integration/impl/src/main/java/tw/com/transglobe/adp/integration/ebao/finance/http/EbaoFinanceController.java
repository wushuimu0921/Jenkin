package tw.com.transglobe.adp.integration.ebao.finance.http;

import org.springframework.web.bind.annotation.RestController;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import tw.com.transglobe.adp.integration.ebao.finance.service.EbaoCommonService;
import tw.com.transglobe.adp.integration.finance.http.EbaoFinanceApi;
import tw.com.transglobe.adp.integration.finance.http.dto.exchangeRs.EbaoExchangeRsDto;
import tw.com.transglobe.adp.integration.finance.http.dto.transPayment.EbaoFinancePaymentResultDto;
import tw.com.transglobe.adp.integration.finance.http.dto.transPayment.EbaoFinanceQueryChequeDto;
import tw.com.transglobe.adp.integration.finance.http.dto.transPosting.EbaoTransPostingResponseDto;
import tw.com.transglobe.adp.integration.finance.http.req.EbaoFinancePayableRequest;
import tw.com.transglobe.adp.integration.finance.http.req.EbaoFinanceQueryCheckRequest;
import tw.com.transglobe.adp.integration.finance.http.req.EbaoFinanceReceivableRequest;
import tw.com.transglobe.adp.integration.finance.http.req.EbaoFinanceTransPostingRequest;
import tw.com.transglobe.adp.integration.finance.http.req.EbaoGetPaymentResultRequest;

@Slf4j
@RestController
@RequiredArgsConstructor
class EbaoFinanceController implements EbaoFinanceApi {

  final EbaoCommonService service;

  final EbaoFinanceDtoMapper mapper;

  @Override
  public EbaoExchangeRsDto createReceivable(EbaoFinanceReceivableRequest request) {
    log.debug("EbaoFinanceReceivableRequest:{}", request);
    final var exchangeRecvDto = mapper.fromVo(
        service.createReceivable(request.getPolicyNo(),
            mapper.toAparCreateCmd(request.getAparRequests()),
            mapper.toColCreateCmd(request.getColRequests())));
    log.info("createReceivable:{}", exchangeRecvDto);
    return exchangeRecvDto;
  }

  @Override
  public EbaoExchangeRsDto createPayable(EbaoFinancePayableRequest request) {
    log.debug("EbaoFinancePayableRequest:{}", request);
    final var exchangePayDto = mapper.fromVo(
        service.createPayable(request.getPolicyNo(),
            mapper.toAparCreateCmd(request.getAparRequests()),
            mapper.toPayCreateCmd(request.getPayRequests())));
    log.info("createPayable:{}", exchangePayDto);
    return exchangePayDto;
  }

  @Override
  public EbaoFinancePaymentResultDto getPaymentResult(EbaoGetPaymentResultRequest request) {
    log.debug("EbaoGetPaymentResultRequest:{}", request);
    final var paymentResultDto = mapper.fromVo(
        service.getPaymentResult(mapper.toGetPaymentResultCmd(request)));
    log.info("getPaymentResult:{}", paymentResultDto);
    return paymentResultDto;
  }

  @Override
  public EbaoFinanceQueryChequeDto getChequeInfo(EbaoFinanceQueryCheckRequest request) {
    log.debug("EbaoFinanceQueryCheckRequest:{}", request);
    var vo = service.getChequeInfo(mapper.toQueryChequeCmd(request));
    log.info("getChequeInfo:{}", vo);
    return mapper.fromVo(vo);
  }

  @Override
  public EbaoTransPostingResponseDto getPostingResult(EbaoFinanceTransPostingRequest request) {
    log.info("EbaoFinanceTransPostingRequest:{}", request);
    var vo = service.getTransPostingInfo(mapper.toTransPostingCmd(request));
    log.info("transPostingDto:{}", vo);
    return mapper.fromVo(vo);
  }

  @Override
  public void cancel() {

  }

}
