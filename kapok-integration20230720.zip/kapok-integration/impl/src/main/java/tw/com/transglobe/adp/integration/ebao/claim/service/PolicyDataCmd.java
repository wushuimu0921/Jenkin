package tw.com.transglobe.adp.integration.ebao.claim.service;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
@Builder
public class PolicyDataCmd {

  String policyCode;

  String policyAddress;

  String relation;

  BigDecimal policyPayAmount;

  List<ProductDataCmd> productDataList;
}
