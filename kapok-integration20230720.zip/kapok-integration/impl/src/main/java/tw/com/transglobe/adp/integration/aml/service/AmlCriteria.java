package tw.com.transglobe.adp.integration.aml.service;

import java.util.List;
import lombok.Builder;
import lombok.Data;
import tw.com.transglobe.adp.integration.aml.enums.AmlAppCode;
import tw.com.transglobe.adp.integration.aml.enums.AmlCalculateType;
import tw.com.transglobe.adp.integration.aml.enums.AmlCallType;

@Data
@Builder
public class AmlCriteria {

  AmlAppCode appCode;
  String unit;
  AmlCallType callType;
  String loginAccount;
  AmlCalculateType calcType;
  AmlCifData cif;
  List<AmlRelData> rels;
  List<AmlAccData> acc;
  boolean isFull;

}
