
package tw.com.transglobe.adp.integration.aml.wsclient;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the tw.com.transglobe.kapok.integration.aml.wsclient package.
 * <p>
 * An ObjectFactory allows you to programatically
 * construct new instances of the Java representation
 * for XML content. The Java representation of XML
 * content can consist of schema derived interfaces
 * and classes representing the binding of schema
 * type definitions, element declarations and model
 * groups. Factory methods for each of these are
 * provided in this class.
 *
 */
@XmlRegistry
public class ObjectFactory {

  private final static QName _FofDecApply_QNAME = new QName("http://webservice.lyods.com/", "FofDecApply");
  private final static QName _FofDecApplyResponse_QNAME = new QName("http://webservice.lyods.com/", "FofDecApplyResponse");
  private final static QName _FofExecCif_QNAME = new QName("http://webservice.lyods.com/", "FofExecCif");
  private final static QName _FofExecCifResponse_QNAME = new QName("http://webservice.lyods.com/", "FofExecCifResponse");
  private final static QName _FofExecFmt_QNAME = new QName("http://webservice.lyods.com/", "FofExecFmt");
  private final static QName _FofExecFmtResponse_QNAME = new QName("http://webservice.lyods.com/", "FofExecFmtResponse");
  private final static QName _LyodsException_QNAME = new QName("http://webservice.lyods.com/", "LyodsException");

  /**
   * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package:
   * tw.com.transglobe.kapok.integration.aml.wsclient
   *
   */
  public ObjectFactory() {
  }

  /**
   * Create an instance of {@link FofDecApply }
   *
   */
  public FofDecApply createFofDecApply() {
    return new FofDecApply();
  }

  /**
   * Create an instance of {@link FofDecApplyResponse }
   *
   */
  public FofDecApplyResponse createFofDecApplyResponse() {
    return new FofDecApplyResponse();
  }

  /**
   * Create an instance of {@link FofExecCif }
   *
   */
  public FofExecCif createFofExecCif() {
    return new FofExecCif();
  }

  /**
   * Create an instance of {@link FofExecCifResponse }
   *
   */
  public FofExecCifResponse createFofExecCifResponse() {
    return new FofExecCifResponse();
  }

  /**
   * Create an instance of {@link FofExecFmt }
   *
   */
  public FofExecFmt createFofExecFmt() {
    return new FofExecFmt();
  }

  /**
   * Create an instance of {@link FofExecFmtResponse }
   *
   */
  public FofExecFmtResponse createFofExecFmtResponse() {
    return new FofExecFmtResponse();
  }

  /**
   * Create an instance of {@link LyodsException }
   *
   */
  public LyodsException createLyodsException() {
    return new LyodsException();
  }

  /**
   * Create an instance of {@link Exts }
   *
   */
  public Exts createExts() {
    return new Exts();
  }

  /**
   * Create an instance of {@link E }
   *
   */
  public E createE() {
    return new E();
  }

  /**
   * Create an instance of {@link Head }
   *
   */
  public Head createHead() {
    return new Head();
  }

  /**
   * Create an instance of {@link Dec }
   *
   */
  public Dec createDec() {
    return new Dec();
  }

  /**
   * Create an instance of {@link Hits }
   *
   */
  public Hits createHits() {
    return new Hits();
  }

  /**
   * Create an instance of {@link H }
   *
   */
  public H createH() {
    return new H();
  }

  /**
   * Create an instance of {@link FofDecApply.FIRCO }
   *
   */
  public FofDecApply.FIRCO createFofDecApplyFIRCO() {
    return new FofDecApply.FIRCO();
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link FofDecApply }{@code >}
   *
   * @param value
   *        Java instance representing xml element's value.
   * @return
   *         the new instance of {@link JAXBElement }{@code <}{@link FofDecApply }{@code >}
   */
  @XmlElementDecl(namespace = "http://webservice.lyods.com/", name = "FofDecApply")
  public JAXBElement<FofDecApply> createFofDecApply(FofDecApply value) {
    return new JAXBElement<FofDecApply>(_FofDecApply_QNAME, FofDecApply.class, null, value);
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link FofDecApplyResponse }{@code >}
   *
   * @param value
   *        Java instance representing xml element's value.
   * @return
   *         the new instance of {@link JAXBElement }{@code <}{@link FofDecApplyResponse }{@code >}
   */
  @XmlElementDecl(namespace = "http://webservice.lyods.com/", name = "FofDecApplyResponse")
  public JAXBElement<FofDecApplyResponse> createFofDecApplyResponse(FofDecApplyResponse value) {
    return new JAXBElement<FofDecApplyResponse>(_FofDecApplyResponse_QNAME, FofDecApplyResponse.class, null, value);
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link FofExecCif }{@code >}
   *
   * @param value
   *        Java instance representing xml element's value.
   * @return
   *         the new instance of {@link JAXBElement }{@code <}{@link FofExecCif }{@code >}
   */
  @XmlElementDecl(namespace = "http://webservice.lyods.com/", name = "FofExecCif")
  public JAXBElement<FofExecCif> createFofExecCif(FofExecCif value) {
    return new JAXBElement<FofExecCif>(_FofExecCif_QNAME, FofExecCif.class, null, value);
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link FofExecCifResponse }{@code >}
   *
   * @param value
   *        Java instance representing xml element's value.
   * @return
   *         the new instance of {@link JAXBElement }{@code <}{@link FofExecCifResponse }{@code >}
   */
  @XmlElementDecl(namespace = "http://webservice.lyods.com/", name = "FofExecCifResponse")
  public JAXBElement<FofExecCifResponse> createFofExecCifResponse(FofExecCifResponse value) {
    return new JAXBElement<FofExecCifResponse>(_FofExecCifResponse_QNAME, FofExecCifResponse.class, null, value);
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link FofExecFmt }{@code >}
   *
   * @param value
   *        Java instance representing xml element's value.
   * @return
   *         the new instance of {@link JAXBElement }{@code <}{@link FofExecFmt }{@code >}
   */
  @XmlElementDecl(namespace = "http://webservice.lyods.com/", name = "FofExecFmt")
  public JAXBElement<FofExecFmt> createFofExecFmt(FofExecFmt value) {
    return new JAXBElement<FofExecFmt>(_FofExecFmt_QNAME, FofExecFmt.class, null, value);
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link FofExecFmtResponse }{@code >}
   *
   * @param value
   *        Java instance representing xml element's value.
   * @return
   *         the new instance of {@link JAXBElement }{@code <}{@link FofExecFmtResponse }{@code >}
   */
  @XmlElementDecl(namespace = "http://webservice.lyods.com/", name = "FofExecFmtResponse")
  public JAXBElement<FofExecFmtResponse> createFofExecFmtResponse(FofExecFmtResponse value) {
    return new JAXBElement<FofExecFmtResponse>(_FofExecFmtResponse_QNAME, FofExecFmtResponse.class, null, value);
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link LyodsException }{@code >}
   *
   * @param value
   *        Java instance representing xml element's value.
   * @return
   *         the new instance of {@link JAXBElement }{@code <}{@link LyodsException }{@code >}
   */
  @XmlElementDecl(namespace = "http://webservice.lyods.com/", name = "LyodsException")
  public JAXBElement<LyodsException> createLyodsException(LyodsException value) {
    return new JAXBElement<LyodsException>(_LyodsException_QNAME, LyodsException.class, null, value);
  }

}
