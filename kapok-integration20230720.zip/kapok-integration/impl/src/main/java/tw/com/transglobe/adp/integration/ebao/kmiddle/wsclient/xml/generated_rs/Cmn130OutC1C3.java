//
// ���ɮ׬O�� JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.8-b130911.1802 �Ҳ���
// �аѾ\ <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a>
// �@�����s�sĶ�ӷ����n, �惡�ɮשҰ�������קﳣ�N�|��.
// ���ͮɶ�: 2022.10.05 �� 12:31:29 PM CST
//

package tw.com.transglobe.adp.integration.ebao.kmiddle.wsclient.xml.generated_rs;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * <p>
 * cmn130OutC1C3 complex type �� Java ���O.
 *
 * <p>
 * �U�C���n���q�|���w�����O���]�t���w�����e.
 *
 * <pre>
 * &lt;complexType name="cmn130OutC1C3">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="billType" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="startDate" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="endDate" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="hospitalName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "cmn130OutC1C3", propOrder = {
    "billType",
    "startDate",
    "endDate",
    "hospitalName"
})
public class Cmn130OutC1C3 {

  protected long billType;
  @XmlElement(required = true)
  @XmlSchemaType(name = "date")
  protected XMLGregorianCalendar startDate;
  @XmlElement(required = true)
  @XmlSchemaType(name = "date")
  protected XMLGregorianCalendar endDate;
  @XmlElement(required = true)
  protected String hospitalName;

  /**
   * ���o billType �S�ʪ���.
   *
   */
  public long getBillType() {
    return billType;
  }

  /**
   * �]�w billType �S�ʪ���.
   *
   */
  public void setBillType(long value) {
    this.billType = value;
  }

  /**
   * ���o startDate �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link XMLGregorianCalendar }
   *
   */
  public XMLGregorianCalendar getStartDate() {
    return startDate;
  }

  /**
   * �]�w startDate �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link XMLGregorianCalendar }
   *
   */
  public void setStartDate(XMLGregorianCalendar value) {
    this.startDate = value;
  }

  /**
   * ���o endDate �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link XMLGregorianCalendar }
   *
   */
  public XMLGregorianCalendar getEndDate() {
    return endDate;
  }

  /**
   * �]�w endDate �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link XMLGregorianCalendar }
   *
   */
  public void setEndDate(XMLGregorianCalendar value) {
    this.endDate = value;
  }

  /**
   * ���o hospitalName �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getHospitalName() {
    return hospitalName;
  }

  /**
   * �]�w hospitalName �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setHospitalName(String value) {
    this.hospitalName = value;
  }

}
