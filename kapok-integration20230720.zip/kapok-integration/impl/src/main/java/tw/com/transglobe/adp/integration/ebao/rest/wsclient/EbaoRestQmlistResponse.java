package tw.com.transglobe.adp.integration.ebao.rest.wsclient;

import java.time.LocalDate;
import lombok.Builder;
import lombok.Data;

@Data
public class EbaoRestQmlistResponse {
  String qualityManageType;
  String certiCode;
  String certiType;
  String registerCode;
  String devCode;
  String devName;
  String name;
  LocalDate birthdate;
  String cause;
  String causeDesc;
  String source;
  String sourceDescs;
  LocalDate startDate;
  LocalDate endDate;
  String meno;
  String sourceListId;

}
