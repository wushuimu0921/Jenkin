//
// ���ɮ׬O�� JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.8-b130911.1802 �Ҳ���
// �аѾ\ <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a>
// �@�����s�sĶ�ӷ����n, �惡�ɮשҰ�������קﳣ�N�|��.
// ���ͮɶ�: 2022.10.05 �� 12:31:29 PM CST
//

package tw.com.transglobe.adp.integration.ebao.kmiddle.wsclient.xml.generated_rs;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * <p>
 * cmn130OutC1 complex type �� Java ���O.
 *
 * <p>
 * �U�C���n���q�|���w�����O���]�t���w�����e.
 *
 * <pre>
 * &lt;complexType name="cmn130OutC1">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="caseNo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="approveDate" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="status" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="insuredId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="insuredName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="accidentDate" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="accidentReason" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="diagnosisName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="remark" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ClaimPolicyDataList" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element ref="{}ClaimPolicyData" maxOccurs="unbounded"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="ClaimSurgeryDataList" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element ref="{}ClaimSurgeryData" maxOccurs="unbounded"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="ClaimBillDataList" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element ref="{}ClaimBillData" maxOccurs="unbounded"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "cmn130OutC1", propOrder = {
    "caseNo",
    "approveDate",
    "status",
    "insuredId",
    "insuredName",
    "accidentDate",
    "accidentReason",
    "diagnosisName",
    "remark",
    "claimPolicyDataList",
    "claimSurgeryDataList",
    "claimBillDataList"
})
public class Cmn130OutC1 {

  @XmlElement(required = true)
  protected String caseNo;
  @XmlElement(required = true)
  @XmlSchemaType(name = "date")
  protected XMLGregorianCalendar approveDate;
  @XmlElement(required = true)
  protected String status;
  @XmlElement(required = true)
  protected String insuredId;
  @XmlElement(required = true)
  protected String insuredName;
  @XmlElement(required = true)
  @XmlSchemaType(name = "date")
  protected XMLGregorianCalendar accidentDate;
  @XmlElement(required = true)
  protected String accidentReason;
  @XmlElement(required = true)
  protected String diagnosisName;
  @XmlElement(required = true)
  protected String remark;
  @XmlElement(name = "ClaimPolicyDataList")
  protected Cmn130OutC1.ClaimPolicyDataList claimPolicyDataList;
  @XmlElement(name = "ClaimSurgeryDataList")
  protected Cmn130OutC1.ClaimSurgeryDataList claimSurgeryDataList;
  @XmlElement(name = "ClaimBillDataList")
  protected Cmn130OutC1.ClaimBillDataList claimBillDataList;

  /**
   * ���o caseNo �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getCaseNo() {
    return caseNo;
  }

  /**
   * �]�w caseNo �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCaseNo(String value) {
    this.caseNo = value;
  }

  /**
   * ���o approveDate �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link XMLGregorianCalendar }
   *
   */
  public XMLGregorianCalendar getApproveDate() {
    return approveDate;
  }

  /**
   * �]�w approveDate �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link XMLGregorianCalendar }
   *
   */
  public void setApproveDate(XMLGregorianCalendar value) {
    this.approveDate = value;
  }

  /**
   * ���o status �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getStatus() {
    return status;
  }

  /**
   * �]�w status �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setStatus(String value) {
    this.status = value;
  }

  /**
   * ���o insuredId �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getInsuredId() {
    return insuredId;
  }

  /**
   * �]�w insuredId �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setInsuredId(String value) {
    this.insuredId = value;
  }

  /**
   * ���o insuredName �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getInsuredName() {
    return insuredName;
  }

  /**
   * �]�w insuredName �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setInsuredName(String value) {
    this.insuredName = value;
  }

  /**
   * ���o accidentDate �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link XMLGregorianCalendar }
   *
   */
  public XMLGregorianCalendar getAccidentDate() {
    return accidentDate;
  }

  /**
   * �]�w accidentDate �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link XMLGregorianCalendar }
   *
   */
  public void setAccidentDate(XMLGregorianCalendar value) {
    this.accidentDate = value;
  }

  /**
   * ���o accidentReason �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getAccidentReason() {
    return accidentReason;
  }

  /**
   * �]�w accidentReason �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setAccidentReason(String value) {
    this.accidentReason = value;
  }

  /**
   * ���o diagnosisName �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getDiagnosisName() {
    return diagnosisName;
  }

  /**
   * �]�w diagnosisName �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setDiagnosisName(String value) {
    this.diagnosisName = value;
  }

  /**
   * ���o remark �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getRemark() {
    return remark;
  }

  /**
   * �]�w remark �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setRemark(String value) {
    this.remark = value;
  }

  /**
   * ���o claimPolicyDataList �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link Cmn130OutC1 .ClaimPolicyDataList }
   *
   */
  public Cmn130OutC1.ClaimPolicyDataList getClaimPolicyDataList() {
    return claimPolicyDataList;
  }

  /**
   * �]�w claimPolicyDataList �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link Cmn130OutC1 .ClaimPolicyDataList }
   *
   */
  public void setClaimPolicyDataList(Cmn130OutC1.ClaimPolicyDataList value) {
    this.claimPolicyDataList = value;
  }

  /**
   * ���o claimSurgeryDataList �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link Cmn130OutC1 .ClaimSurgeryDataList }
   *
   */
  public Cmn130OutC1.ClaimSurgeryDataList getClaimSurgeryDataList() {
    return claimSurgeryDataList;
  }

  /**
   * �]�w claimSurgeryDataList �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link Cmn130OutC1 .ClaimSurgeryDataList }
   *
   */
  public void setClaimSurgeryDataList(Cmn130OutC1.ClaimSurgeryDataList value) {
    this.claimSurgeryDataList = value;
  }

  /**
   * ���o claimBillDataList �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link Cmn130OutC1 .ClaimBillDataList }
   *
   */
  public Cmn130OutC1.ClaimBillDataList getClaimBillDataList() {
    return claimBillDataList;
  }

  /**
   * �]�w claimBillDataList �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link Cmn130OutC1 .ClaimBillDataList }
   *
   */
  public void setClaimBillDataList(Cmn130OutC1.ClaimBillDataList value) {
    this.claimBillDataList = value;
  }

  /**
   * <p>
   * anonymous complex type �� Java ���O.
   *
   * <p>
   * �U�C���n���q�|���w�����O���]�t���w�����e.
   *
   * <pre>
   * &lt;complexType>
   *   &lt;complexContent>
   *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
   *       &lt;sequence>
   *         &lt;element ref="{}ClaimBillData" maxOccurs="unbounded"/>
   *       &lt;/sequence>
   *     &lt;/restriction>
   *   &lt;/complexContent>
   * &lt;/complexType>
   * </pre>
   *
   *
   */
  @XmlAccessorType(XmlAccessType.FIELD)
  @XmlType(name = "", propOrder = {
      "claimBillData"
  })
  public static class ClaimBillDataList {

    @XmlElement(name = "ClaimBillData", required = true)
    protected List<Cmn130OutC1C3> claimBillData;

    /**
     * Gets the value of the claimBillData property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the claimBillData property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     * 
     * <pre>
     * getClaimBillData().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Cmn130OutC1C3 }
     *
     *
     */
    public List<Cmn130OutC1C3> getClaimBillData() {
      if (claimBillData == null) {
        claimBillData = new ArrayList<Cmn130OutC1C3>();
      }
      return this.claimBillData;
    }

  }

  /**
   * <p>
   * anonymous complex type �� Java ���O.
   *
   * <p>
   * �U�C���n���q�|���w�����O���]�t���w�����e.
   *
   * <pre>
   * &lt;complexType>
   *   &lt;complexContent>
   *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
   *       &lt;sequence>
   *         &lt;element ref="{}ClaimPolicyData" maxOccurs="unbounded"/>
   *       &lt;/sequence>
   *     &lt;/restriction>
   *   &lt;/complexContent>
   * &lt;/complexType>
   * </pre>
   *
   *
   */
  @XmlAccessorType(XmlAccessType.FIELD)
  @XmlType(name = "", propOrder = {
      "claimPolicyData"
  })
  public static class ClaimPolicyDataList {

    @XmlElement(name = "ClaimPolicyData", required = true)
    protected List<Cmn130OutC1C1> claimPolicyData;

    /**
     * Gets the value of the claimPolicyData property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the claimPolicyData property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     * 
     * <pre>
     * getClaimPolicyData().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Cmn130OutC1C1 }
     *
     *
     */
    public List<Cmn130OutC1C1> getClaimPolicyData() {
      if (claimPolicyData == null) {
        claimPolicyData = new ArrayList<Cmn130OutC1C1>();
      }
      return this.claimPolicyData;
    }

  }

  /**
   * <p>
   * anonymous complex type �� Java ���O.
   *
   * <p>
   * �U�C���n���q�|���w�����O���]�t���w�����e.
   *
   * <pre>
   * &lt;complexType>
   *   &lt;complexContent>
   *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
   *       &lt;sequence>
   *         &lt;element ref="{}ClaimSurgeryData" maxOccurs="unbounded"/>
   *       &lt;/sequence>
   *     &lt;/restriction>
   *   &lt;/complexContent>
   * &lt;/complexType>
   * </pre>
   *
   *
   */
  @XmlAccessorType(XmlAccessType.FIELD)
  @XmlType(name = "", propOrder = {
      "claimSurgeryData"
  })
  public static class ClaimSurgeryDataList {

    @XmlElement(name = "ClaimSurgeryData", required = true)
    protected List<Cmn130OutC1C2> claimSurgeryData;

    /**
     * Gets the value of the claimSurgeryData property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the claimSurgeryData property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     * 
     * <pre>
     * getClaimSurgeryData().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Cmn130OutC1C2 }
     *
     *
     */
    public List<Cmn130OutC1C2> getClaimSurgeryData() {
      if (claimSurgeryData == null) {
        claimSurgeryData = new ArrayList<Cmn130OutC1C2>();
      }
      return this.claimSurgeryData;
    }

  }

}
