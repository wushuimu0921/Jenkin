package tw.com.transglobe.adp.integration.ebao.rest.http;

import java.util.List;
import org.mapstruct.Mapper;
import tw.com.transglobe.adp.integration.ebao.rest.http.dto.QmlistDto;
import tw.com.transglobe.adp.integration.ebao.rest.http.request.QmlistRequest;
import tw.com.transglobe.adp.integration.ebao.rest.service.EbaoRestQmlistCriteria;
import tw.com.transglobe.adp.integration.ebao.rest.service.EbaoRestQmlistVo;

@Mapper
interface EbaoRestDtoMapper {

  EbaoRestQmlistCriteria toCriteria(QmlistRequest request);

  QmlistDto fromVo(EbaoRestQmlistVo vo);

  List<QmlistDto> fromVoList(List<EbaoRestQmlistVo> voList);

}
