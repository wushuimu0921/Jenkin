//
// ���ɮ׬O�� JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.3.0 �Ҳ��� 
// �аѾ\ <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a> 
// �@�����s�sĶ�ӷ����n, �惡�ɮשҰ�������קﳣ�N�|��. 
// ���ͮɶ�: 2022.11.22 �� 03:29:21 PM CST 
//

package tw.com.transglobe.adp.integration.ebao.policy.wsclient.xml;

import java.time.LocalDate;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import javax.xml.datatype.XMLGregorianCalendar;
import lombok.ToString;
import tw.com.transglobe.adp.integration.ebao.common.wsclient.LocalDateAdapter;

/**
 * <p>
 * effectPolicyDataVO complex type �� Java ���O.
 * 
 * <p>
 * �U�C���n���q�|���w�����O���]�t���w�����e.
 * 
 * <pre>
 * &lt;complexType name="effectPolicyDataVO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="policyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="partyRole" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="validateDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="romanName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="birthdate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="jobCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="jobClass" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="jobChgDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@ToString
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EffectPolicyDataVO", propOrder = {
    "policyCode",
    "partyRole",
    "validateDate",
    "name",
    "romanName",
    "birthdate",
    "jobCode",
    "jobClass",
    "jobChgDate"
})
public class EffectPolicyDataVO {

  protected String policyCode;
  protected String partyRole;
  @XmlSchemaType(name = "dateTime")
  protected XMLGregorianCalendar validateDate;
  protected String name;
  protected String romanName;
  @XmlSchemaType(name = "dateTime")
  @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
  protected LocalDate birthdate;
  protected String jobCode;
  protected String jobClass;
  @XmlSchemaType(name = "dateTime")
  protected XMLGregorianCalendar jobChgDate;

  /**
   * ���o policyCode �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link String }
   * 
   */
  public String getPolicyCode() {
    return policyCode;
  }

  /**
   * �]�w policyCode �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link String }
   * 
   */
  public void setPolicyCode(String value) {
    this.policyCode = value;
  }

  /**
   * ���o partyRole �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link String }
   * 
   */
  public String getPartyRole() {
    return partyRole;
  }

  /**
   * �]�w partyRole �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link String }
   * 
   */
  public void setPartyRole(String value) {
    this.partyRole = value;
  }

  /**
   * ���o validateDate �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link XMLGregorianCalendar }
   * 
   */
  public XMLGregorianCalendar getValidateDate() {
    return validateDate;
  }

  /**
   * �]�w validateDate �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link XMLGregorianCalendar }
   * 
   */
  public void setValidateDate(XMLGregorianCalendar value) {
    this.validateDate = value;
  }

  /**
   * ���o name �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link String }
   * 
   */
  public String getName() {
    return name;
  }

  /**
   * �]�w name �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link String }
   * 
   */
  public void setName(String value) {
    this.name = value;
  }

  /**
   * ���o romanName �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link String }
   * 
   */
  public String getRomanName() {
    return romanName;
  }

  /**
   * �]�w romanName �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link String }
   * 
   */
  public void setRomanName(String value) {
    this.romanName = value;
  }

  /**
   * ���o birthdate �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link XMLGregorianCalendar }
   * 
   */
  public LocalDate getBirthdate() {
    return birthdate;
  }

  /**
   * �]�w birthdate �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link XMLGregorianCalendar }
   * 
   */
  public void setBirthdate(LocalDate value) {
    this.birthdate = value;
  }

  /**
   * ���o jobCode �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link String }
   * 
   */
  public String getJobCode() {
    return jobCode;
  }

  /**
   * �]�w jobCode �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link String }
   * 
   */
  public void setJobCode(String value) {
    this.jobCode = value;
  }

  /**
   * ���o jobClass �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link String }
   * 
   */
  public String getJobClass() {
    return jobClass;
  }

  /**
   * �]�w jobClass �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link String }
   * 
   */
  public void setJobClass(String value) {
    this.jobClass = value;
  }

  /**
   * ���o jobChgDate �S�ʪ���.
   * 
   * @return
   *         possible object is
   *         {@link XMLGregorianCalendar }
   * 
   */
  public XMLGregorianCalendar getJobChgDate() {
    return jobChgDate;
  }

  /**
   * �]�w jobChgDate �S�ʪ���.
   * 
   * @param value
   *        allowed object is
   *        {@link XMLGregorianCalendar }
   * 
   */
  public void setJobChgDate(XMLGregorianCalendar value) {
    this.jobChgDate = value;
  }

}
