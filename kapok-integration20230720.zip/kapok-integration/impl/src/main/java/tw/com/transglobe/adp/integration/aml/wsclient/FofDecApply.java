
package tw.com.transglobe.adp.integration.aml.wsclient;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * FofDecApply complex type 的 Java 類別.
 *
 * <p>
 * 下列綱要片段會指定此類別中包含的預期內容.
 *
 * <pre>
 * &lt;complexType name="FofDecApply"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="FIRCO" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="head" type="{http://webservice.lyods.com/}head"/&gt;
 *                   &lt;element name="dec" type="{http://webservice.lyods.com/}dec"/&gt;
 *                   &lt;element name="hits" type="{http://webservice.lyods.com/}hits" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="authkey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="authname" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FofDecApply", propOrder = {
    "firco",
    "authkey",
    "authname"
})
public class FofDecApply {

  @XmlElement(name = "FIRCO")
  protected FofDecApply.FIRCO firco;
  protected String authkey;
  protected String authname;

  /**
   * 取得 firco 特性的值.
   *
   * @return
   *         possible object is
   *         {@link FofDecApply.FIRCO }
   *
   */
  public FofDecApply.FIRCO getFIRCO() {
    return firco;
  }

  /**
   * 設定 firco 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link FofDecApply.FIRCO }
   *
   */
  public void setFIRCO(FofDecApply.FIRCO value) {
    this.firco = value;
  }

  /**
   * 取得 authkey 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getAuthkey() {
    return authkey;
  }

  /**
   * 設定 authkey 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setAuthkey(String value) {
    this.authkey = value;
  }

  /**
   * 取得 authname 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getAuthname() {
    return authname;
  }

  /**
   * 設定 authname 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setAuthname(String value) {
    this.authname = value;
  }

  /**
   * <p>
   * anonymous complex type 的 Java 類別.
   *
   * <p>
   * 下列綱要片段會指定此類別中包含的預期內容.
   *
   * <pre>
   * &lt;complexType&gt;
   *   &lt;complexContent&gt;
   *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
   *       &lt;sequence&gt;
   *         &lt;element name="head" type="{http://webservice.lyods.com/}head"/&gt;
   *         &lt;element name="dec" type="{http://webservice.lyods.com/}dec"/&gt;
   *         &lt;element name="hits" type="{http://webservice.lyods.com/}hits" minOccurs="0"/&gt;
   *       &lt;/sequence&gt;
   *     &lt;/restriction&gt;
   *   &lt;/complexContent&gt;
   * &lt;/complexType&gt;
   * </pre>
   *
   *
   */
  @XmlAccessorType(XmlAccessType.FIELD)
  @XmlType(name = "", propOrder = {
      "head",
      "dec",
      "hits"
  })
  public static class FIRCO {

    @XmlElement(required = true)
    protected Head head;
    @XmlElement(required = true)
    protected Dec dec;
    protected Hits hits;

    /**
     * 取得 head 特性的值.
     *
     * @return
     *         possible object is
     *         {@link Head }
     *
     */
    public Head getHead() {
      return head;
    }

    /**
     * 設定 head 特性的值.
     *
     * @param value
     *        allowed object is
     *        {@link Head }
     *
     */
    public void setHead(Head value) {
      this.head = value;
    }

    /**
     * 取得 dec 特性的值.
     *
     * @return
     *         possible object is
     *         {@link Dec }
     *
     */
    public Dec getDec() {
      return dec;
    }

    /**
     * 設定 dec 特性的值.
     *
     * @param value
     *        allowed object is
     *        {@link Dec }
     *
     */
    public void setDec(Dec value) {
      this.dec = value;
    }

    /**
     * 取得 hits 特性的值.
     *
     * @return
     *         possible object is
     *         {@link Hits }
     *
     */
    public Hits getHits() {
      return hits;
    }

    /**
     * 設定 hits 特性的值.
     *
     * @param value
     *        allowed object is
     *        {@link Hits }
     *
     */
    public void setHits(Hits value) {
      this.hits = value;
    }

  }

}
