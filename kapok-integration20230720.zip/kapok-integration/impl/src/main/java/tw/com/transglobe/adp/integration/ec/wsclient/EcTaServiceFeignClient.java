package tw.com.transglobe.adp.integration.ec.wsclient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import tw.com.transglobe.adp.integration.ec.service.cmd.EcTaPolicyPrintReplyCmd;
import tw.com.transglobe.adp.integration.ec.service.EcTaResultVo;

@FeignClient(name = "ec-ta-service", url = "${transglobe.integration.ec-ta.url}")
public interface EcTaServiceFeignClient {

  @PostMapping("/ec-server/adp/policyPrintReply")
  EcTaResultVo policyPrintReply(EcTaPolicyPrintReplyCmd cmd);

}
