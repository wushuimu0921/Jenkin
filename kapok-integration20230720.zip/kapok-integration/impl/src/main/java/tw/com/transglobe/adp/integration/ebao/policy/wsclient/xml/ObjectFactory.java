//
// ���ɮ׬O�� JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.3.0 �Ҳ��� 
// �аѾ\ <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a> 
// �@�����s�sĶ�ӷ����n, �惡�ɮשҰ�������קﳣ�N�|��. 
// ���ͮɶ�: 2022.11.22 �� 03:29:21 PM CST 
//

package tw.com.transglobe.adp.integration.ebao.policy.wsclient.xml;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the tw.com.transglobe.adp.integration.ebao.policy.wsclient.xml package.
 * <p>
 * An ObjectFactory allows you to programatically
 * construct new instances of the Java representation
 * for XML content. The Java representation of XML
 * content can consist of schema derived interfaces
 * and classes representing the binding of schema
 * type definitions, element declarations and model
 * groups. Factory methods for each of these are
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

  private final static QName _EffectPolicyListRq_QNAME = new QName("", "EffectPolicyListRq");
  private final static QName _EffectPolicyDataVO_QNAME = new QName("", "EffectPolicyDataVO");
  private final static QName _EffectPolicyListRs_QNAME = new QName("", "EffectPolicyListRs");

  /**
   * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package:
   * tw.com.transglobe.adp.integration.ebao.policy.wsclient.xml
   * 
   */
  public ObjectFactory() {
  }

  /**
   * Create an instance of {@link EffectPolicyListRq }
   * 
   */
  public EffectPolicyListRq createEffectPolicyListRq() {
    return new EffectPolicyListRq();
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link EffectPolicyListRq }{@code >}
   * 
   * @param value
   *        Java instance representing xml element's value.
   * @return
   *         the new instance of {@link JAXBElement }{@code <}{@link EffectPolicyListRq }{@code >}
   */
  @XmlElementDecl(namespace = "", name = "EffectPolicyListRq")
  public JAXBElement<EffectPolicyListRq> createEffectPolicyListRq(EffectPolicyListRq value) {
    return new JAXBElement<EffectPolicyListRq>(_EffectPolicyListRq_QNAME, EffectPolicyListRq.class, null, value);
  }

  /**
   * Create an instance of {@link EffectPolicyListRs }
   * 
   */
  public EffectPolicyListRs createEffectPolicyListRs() {
    return new EffectPolicyListRs();
  }

  /**
   * Create an instance of {@link EffectPolicyDataVO }
   * 
   */
  public EffectPolicyDataVO createEffectPolicyDataVO() {
    return new EffectPolicyDataVO();
  }

  /**
   * Create an instance of {@link EffectPolicyListRs.EffectPolicyDataList }
   * 
   */
  public EffectPolicyListRs.EffectPolicyDataList createEffectPolicyListRsEffectPolicyDataList() {
    return new EffectPolicyListRs.EffectPolicyDataList();
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link EffectPolicyDataVO }{@code >}
   * 
   * @param value
   *        Java instance representing xml element's value.
   * @return
   *         the new instance of {@link JAXBElement }{@code <}{@link EffectPolicyDataVO }{@code >}
   */
  @XmlElementDecl(namespace = "", name = "EffectPolicyDataVO")
  public JAXBElement<EffectPolicyDataVO> createEffectPolicyDataVO(EffectPolicyDataVO value) {
    return new JAXBElement<EffectPolicyDataVO>(_EffectPolicyDataVO_QNAME, EffectPolicyDataVO.class, null, value);
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link EffectPolicyListRs }{@code >}
   * 
   * @param value
   *        Java instance representing xml element's value.
   * @return
   *         the new instance of {@link JAXBElement }{@code <}{@link EffectPolicyListRs }{@code >}
   */
  @XmlElementDecl(namespace = "", name = "EffectPolicyListRs")
  public JAXBElement<EffectPolicyListRs> createEffectPolicyListRs(EffectPolicyListRs value) {
    return new JAXBElement<EffectPolicyListRs>(_EffectPolicyListRs_QNAME, EffectPolicyListRs.class, null, value);
  }

}
