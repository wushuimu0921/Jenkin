package tw.com.transglobe.adp.integration.esp.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import tw.com.softleader.data.security.guardium.annotation.Safeguard;
import tw.com.transglobe.adp.integration.esp.service.cmd.EspSmsMessageCmd;
import tw.com.transglobe.adp.integration.esp.service.client.EspSmsMessageWebServiceClient;

@Slf4j
@Service
@RequiredArgsConstructor
@Safeguard
public class EspSmsService {

  final EspSmsMessageWebServiceClient client;

  public String sendSmsMessage(EspSmsMessageCmd cmd) {
    return client.sendSmsMessage(cmd);
  }

}
