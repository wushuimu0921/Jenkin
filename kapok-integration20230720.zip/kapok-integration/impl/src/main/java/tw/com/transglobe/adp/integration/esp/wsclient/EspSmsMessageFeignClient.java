package tw.com.transglobe.adp.integration.esp.wsclient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import tw.com.transglobe.adp.integration.esp.wsclient.request.EspSmsMessageWsRequest;
import tw.com.transglobe.adp.integration.esp.wsclient.response.EspSmsResponse;

@FeignClient(name = "esp-sms-message", url = "${transglobe.integration.esp-sms-message.url}")
public interface EspSmsMessageFeignClient {

  @PostMapping
  EspSmsResponse sendSmsMessage(EspSmsMessageWsRequest request);

}
