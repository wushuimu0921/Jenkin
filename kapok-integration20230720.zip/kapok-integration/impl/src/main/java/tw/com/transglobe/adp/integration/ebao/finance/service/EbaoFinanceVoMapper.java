package tw.com.transglobe.adp.integration.ebao.finance.service;

import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import tw.com.transglobe.adp.integration.commons.enums.EbaoChequeStatus;
import tw.com.transglobe.adp.integration.ebao.finance.service.chequeInfo.EbaoChequeInfoVo;
import tw.com.transglobe.adp.integration.ebao.finance.service.chequeInfo.EbaoChequeVo;
import tw.com.transglobe.adp.integration.ebao.finance.service.exchange.EbaoExchangeResponseVo;
import tw.com.transglobe.adp.integration.ebao.finance.service.transPayment.EbaoTransPaymentInfoVo;
import tw.com.transglobe.adp.integration.ebao.finance.service.transPosting.EbaoTransPostingInfoVo;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.exchangeRs.GlTransRs;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRs.TransCheckInfoRs;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRs.TransPaymentInfoRs;
import tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRs.TransPostingInfoRs;

@Mapper(nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
public interface EbaoFinanceVoMapper {

  Logger log = LoggerFactory.getLogger(EbaoFinanceVoMapper.class.getName());

  //@Mapping(target = "chequeStatus", ignore = true)

  //  List<EbaoChequeVo> toVos(List<TransCheckInfoRs.Cheque> cheque);

}
