package tw.com.transglobe.adp.integration.ec.wsclient;

import org.springframework.stereotype.Component;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import tw.com.transglobe.adp.integration.ec.service.cmd.EcTaPolicyPrintReplyCmd;
import tw.com.transglobe.adp.integration.ec.service.EcTaResultVo;
import tw.com.transglobe.adp.integration.ec.service.EcTaServiceClient;

@Slf4j
@RequiredArgsConstructor
@Component
public class EcTaServiceClientImpl implements EcTaServiceClient {

  final EcTaServiceFeignClient client;

  @Override
  public EcTaResultVo policyPrintReply(EcTaPolicyPrintReplyCmd cmd) {
    log.debug("{}", cmd);
    return client.policyPrintReply(cmd);
  }

}
