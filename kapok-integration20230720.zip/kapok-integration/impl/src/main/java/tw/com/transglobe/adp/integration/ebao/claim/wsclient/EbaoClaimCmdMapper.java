package tw.com.transglobe.adp.integration.ebao.claim.wsclient;

import org.mapstruct.Mapper;
import tw.com.transglobe.adp.integration.ebao.claim.service.ClaimRecordQuery071RqCmd;
import tw.com.transglobe.adp.integration.ebao.claim.service.ClaimRecordQuery071RsCmd;
import tw.com.transglobe.adp.integration.ebao.claim.wsclient.xml.ClaimRecordQuery071Rq;
import tw.com.transglobe.adp.integration.ebao.claim.wsclient.xml.ClaimRecordQuery071Rs;

@Mapper
public interface EbaoClaimCmdMapper {

  ClaimRecordQuery071Rq rqFromCmd(ClaimRecordQuery071RqCmd rq);

  ClaimRecordQuery071RsCmd rsToCmd(ClaimRecordQuery071Rs rs);
}
