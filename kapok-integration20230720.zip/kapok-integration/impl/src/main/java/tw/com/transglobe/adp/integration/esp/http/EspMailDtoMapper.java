package tw.com.transglobe.adp.integration.esp.http;

import org.mapstruct.Mapper;
import tw.com.transglobe.adp.integration.esp.http.req.EspAttachFileRequest;
import tw.com.transglobe.adp.integration.esp.http.req.EspMailAttachFileRequest;
import tw.com.transglobe.adp.integration.esp.http.req.EspMailRequest;
import tw.com.transglobe.adp.integration.esp.service.cmd.EspAttachFileCmd;
import tw.com.transglobe.adp.integration.esp.service.cmd.EspMailAttachFileCmd;
import tw.com.transglobe.adp.integration.esp.service.cmd.EspMailCmd;

@Mapper
interface EspMailDtoMapper {

  EspMailAttachFileCmd toAttachCmd(EspMailAttachFileRequest request);

  EspMailCmd toCmd(EspMailRequest request);

  EspAttachFileCmd toCmd(EspAttachFileRequest request);

}
