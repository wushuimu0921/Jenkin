package tw.com.transglobe.adp.integration.ebao.claim.wsclient.xml;

import lombok.*;
import tw.com.transglobe.adp.integration.ebao.common.wsclient.LocalDateAdapter;
import javax.xml.bind.annotation.*;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.time.LocalDate;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "claimRecordQuery071Rq", propOrder = {
    "queryType",
    "queryParam",
    "startDate",
    "endDate",
    "isDC",
    "serviceRegisterCode",
    "reporterRegisterCode",
    "limitIndicator",
    "querySource"
})
@XmlRootElement(name = "claimRecordQuery071Rq")
@Getter
@Setter
public class ClaimRecordQuery071Rq {

  @XmlElement(required = true)
  protected String queryType;

  @XmlElement(required = true)
  protected String queryParam;

  @XmlElement(required = true, type = String.class)
  @XmlSchemaType(name = "date")
  @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
  protected LocalDate startDate;

  @XmlElement(required = true, type = String.class)
  @XmlSchemaType(name = "date")
  @XmlJavaTypeAdapter(value = LocalDateAdapter.class)
  protected LocalDate endDate;

  @XmlElement(required = true)
  protected String isDC;

  @XmlElement
  protected String serviceRegisterCode;

  @XmlElement
  protected String reporterRegisterCode;

  @XmlElement
  protected Integer limitIndicator;

  @XmlElement
  protected String querySource;

}
