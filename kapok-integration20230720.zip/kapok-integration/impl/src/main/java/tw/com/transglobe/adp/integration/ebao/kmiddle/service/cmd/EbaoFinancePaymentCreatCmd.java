package tw.com.transglobe.adp.integration.ebao.kmiddle.service.cmd;

import lombok.Builder;
import lombok.Data;
import tw.com.transglobe.adp.integration.commons.enums.*;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@Builder
public class EbaoFinancePaymentCreatCmd {

  LocalDate dataDate;
  String cashSeq;
  Integer systemId;
  Integer subSystemId;
  String refId;
  String adpPolNo;
  String divideIndi;
  PhCertiType phCertiType;
  String phCertiCode;
  String phName;
  FeeType feeType;
  PayMode payMode;
  MoneyId moneyId;
  BigDecimal feeAmount;
  MoneyId payMoneyId;
  BigDecimal payAmount;

  String cashierDeptCode;
  String cashierDeptName;
  String cashierName;

  ChannelType agentChannelType;
  String agentChannelCode;
  String agentRegisterCode;

  LocalDate dueTime;
  LocalDate approveDate;

  String approveUserName;
  String approveUserDeptCode;
  String approveUserDeptName;
  String approveUserId;

  String payeeCertiCode;
  String payeeName;
  String payeeBankCode;
  String payeeBankName;
  String payeeAccount;

  String creditCardNum;
  String creditCardAuth;
  String creditCardExpireDate;
  Long creditCardAcquirerId;

  String withdrawType;
  PaySource paymentSource;

  YesNo cancelEndorsementIndi;
  YesNo cancelScoreIndi;
  String sendZipCode;
  String sendAddress;
  String companyName;
  String recipientName;
  String attachmentIndi;
  String posAcceptNo;
  String chequeSendType;
  LocalDate accountingDate;

}
