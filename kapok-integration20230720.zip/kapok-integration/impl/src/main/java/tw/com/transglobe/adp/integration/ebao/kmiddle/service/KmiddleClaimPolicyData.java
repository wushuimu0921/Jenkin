package tw.com.transglobe.adp.integration.ebao.kmiddle.service;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;

@Data
@Builder
public class KmiddleClaimPolicyData {

  /** 保單號碼 */
  String policyCode;

  /** 關係 */
  String insuredRelation;

  /** 險種代號 */
  String publicCode;

  /** 理賠金額 */
  BigDecimal payAmount;

}
