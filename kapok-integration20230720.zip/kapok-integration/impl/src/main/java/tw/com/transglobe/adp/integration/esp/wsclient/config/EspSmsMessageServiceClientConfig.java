package tw.com.transglobe.adp.integration.esp.wsclient.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tw.com.transglobe.adp.integration.config.AdpIntegrationProperties;
import tw.com.transglobe.adp.integration.esp.wsclient.impl.EspSmsMessageWebServiceClientImpl;
import tw.com.transglobe.adp.integration.esp.wsclient.impl.EspSmsMessageWebServiceClientMock;
import tw.com.transglobe.adp.integration.esp.wsclient.EspSmsMessageFeignClient;
import tw.com.transglobe.adp.integration.esp.service.client.EspSmsMessageWebServiceClient;

@Slf4j
@Configuration
class EspSmsMessageServiceClientConfig {

  @Bean
  @ConditionalOnMissingBean
  @ConditionalOnProperty(value = "sms-client.enabled", havingValue = "false")
  public EspSmsMessageWebServiceClient espSmsMessageWebServiceClientOfMock(AdpIntegrationProperties properties) {
    return new EspSmsMessageWebServiceClientMock(properties);
  }

  @Bean
  @ConditionalOnProperty(value = "sms-client.enabled", havingValue = "true")
  public EspSmsMessageWebServiceClient espSmsMessageWebServiceClient(EspSmsMessageFeignClient feignClient,
      AdpIntegrationProperties properties) {
    return new EspSmsMessageWebServiceClientImpl(feignClient, properties);
  }
}
