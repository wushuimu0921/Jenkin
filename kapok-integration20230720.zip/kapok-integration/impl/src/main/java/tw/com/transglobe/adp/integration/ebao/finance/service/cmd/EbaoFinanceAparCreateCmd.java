package tw.com.transglobe.adp.integration.ebao.finance.service.cmd;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;
import tw.com.transglobe.adp.integration.commons.enums.*;

@Data
@Builder
public class EbaoFinanceAparCreateCmd {
  LocalDateTime dataDate;
  Integer arapSeq;
  Integer systemId;
  Integer subSystemId;
  Integer businessTypeId;
  String refId; // REF ID, 取得 Record.id
  PayMode payMode; // 付款方式
  FeeType feeType; // 費用類型
  BigDecimal feeAmount; // 費用金額
  FeeStatus feeStatus; // 費用狀態 , default 0
  String adpPolNo; // 保單號碼, 非必填
  String divideIndi; // 區隔標記 ??
  MoneyId moneyId; // 保單幣別
  MoneyId payMoneyId; // 交易幣別
  BigDecimal payAmount; // 交易幣金額
  LocalDate checkEnterTime; // 交易日期
  String phCertiCode;
  PhCertiType phCertiType;
  String phName;
  String phNational;
  String phPostCode;
  ChannelType agentChannelType;
  String agentChannelCode;
  String agentRegisterCode;
  String agentChannelName;
  ChannelType issueChannelType;//領傭業務員通路別 ebao:issueChannelTypeCode .order = issueChannelType
  String issueChannelCode;
  String issueRegisterCode;
  String issueChannelName;
  LocalDate validateDate;
  LocalDate dueTime;
  String cashierDeptCode;
  String cashierDeptName;
  String cashierName;
  String cashierJobNo;
  LocalDateTime cashierTime;

  LocalDate accountingDate; // 入帳日, 轉檔日期
  Integer policyYear; //保費年度
  Integer premAllocYear;//保費認證年度
  String internalId;//險種代碼 ebao:internalId
  String productName;//險種名稱
  ProductCategory productCategory;//商品大類
  ProdContract prodContract;//合約種類 .value = prodContractName
  ChargeType chargeType;//繳別
  ChargePeriod chargePeriod;//繳費類型
  Integer chargeYear;//繳費年期(民國)
  CoveragePeriod coveragePeriod;//保障類型
  Integer coverageYear;//保障年期
  Integer familyId;//眷屬碼
  Integer giempId;//個人碼
  Integer policyPeriod;
  WithdrawType withdrawType;//付費原因
  String glPeriod;
  String glPlanCode;
  PaymentSource paymentSource;
  String isDiscretion;// 具有裁量參與特性(是/否)

  String grTotalIndi; //總額制
  LocalDate grValidateDate; //團險生效日
  String grEmpPolIndi; //員工保險保單註記

  //理賠
  String clmCaseNo;
  Integer clmAuditDecision;
  String liabCategory;
  String liabId;
  Long clmAccidentAge;
  String insuredCertiType;
  String insuredCertiCode;
  String insuredGender;
  Integer insuredEntryAge;
  String payeeNationality;
}