package tw.com.transglobe.adp.integration.ec.service.cmd;

import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;
import tw.com.transglobe.adp.integration.commons.enums.ProductGroupType;

@Data
@Builder
public class EcTaPolicyPrintReplyCmd {
  ProductGroupType productGroupType;
  String productTypeCode; // TA
  String policyNo;
  LocalDateTime approveTime;
}
