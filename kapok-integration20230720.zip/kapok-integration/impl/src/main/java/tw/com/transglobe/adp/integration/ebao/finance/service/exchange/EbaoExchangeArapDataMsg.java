package tw.com.transglobe.adp.integration.ebao.finance.service.exchange;

import lombok.Builder;
import lombok.Data;
import java.util.List;

@Data
@Builder
public class EbaoExchangeArapDataMsg {

  Integer dataSeq; // Arap的流水號

  String dataMsgCode; // Arap資料執行結果

  String dataMsg; // Cash資料執行結果說明

  Long ebaoFeeId; // 儲存後的eBao流水號

  String refId; // 團旅險提供的資料

  List<EbaoExchangeEventMsg> eventMsgs; // 檢核或錯誤事件主檔
}
