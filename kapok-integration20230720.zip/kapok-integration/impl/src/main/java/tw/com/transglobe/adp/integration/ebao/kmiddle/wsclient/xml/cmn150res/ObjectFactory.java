//
// ���ɮ׬O�� JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.3.0 �Ҳ��� 
// �аѾ\ <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a> 
// �@�����s�sĶ�ӷ����n, �惡�ɮשҰ�������קﳣ�N�|��. 
// ���ͮɶ�: 2022.11.17 �� 02:36:56 PM CST 
//

package tw.com.transglobe.adp.integration.ebao.kmiddle.wsclient.xml.cmn150res;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the tw.com.transglobe.adp.integration.ebao.kmiddle.xml.cmn150res package.
 * <p>
 * An ObjectFactory allows you to programatically
 * construct new instances of the Java representation
 * for XML content. The Java representation of XML
 * content can consist of schema derived interfaces
 * and classes representing the binding of schema
 * type definitions, element declarations and model
 * groups. Factory methods for each of these are
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

  private final static QName _GroupPolicyListQueryRs_QNAME = new QName("", "GroupPolicyListQueryRs");

  /**
   * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package:
   * tw.com.transglobe.adp.integration.ebao.kmiddle.xml.cmn150res
   * 
   */
  public ObjectFactory() {
  }

  /**
   * Create an instance of {@link Cmn150Out }
   * 
   */
  public Cmn150Out createCmn150Out() {
    return new Cmn150Out();
  }

  /**
   * Create an instance of {@link Cmn150OutC1 }
   * 
   */
  public Cmn150OutC1 createCmn150OutC1() {
    return new Cmn150OutC1();
  }

  /**
   * Create an instance of {@link Cmn150Out.GroupPolicyList }
   * 
   */
  public Cmn150Out.GroupPolicyList createCmn150OutGroupPolicyList() {
    return new Cmn150Out.GroupPolicyList();
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link Cmn150Out }{@code >}
   * 
   * @param value
   *        Java instance representing xml element's value.
   * @return
   *         the new instance of {@link JAXBElement }{@code <}{@link Cmn150Out }{@code >}
   */
  @XmlElementDecl(namespace = "", name = "GroupPolicyListQueryRs")
  public JAXBElement<Cmn150Out> createGroupPolicyListQueryRs(Cmn150Out value) {
    return new JAXBElement<Cmn150Out>(_GroupPolicyListQueryRs_QNAME, Cmn150Out.class, null, value);
  }

}
