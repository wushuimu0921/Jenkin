package tw.com.transglobe.adp.integration.aml.http;

import org.mapstruct.Mapper;
import tw.com.transglobe.adp.integration.aml.http.dto.AmlCifResponse;
import tw.com.transglobe.adp.integration.aml.http.query.AmlQueryRequest;
import tw.com.transglobe.adp.integration.aml.service.AmlCifResultVo;
import tw.com.transglobe.adp.integration.aml.service.AmlCriteria;

@Mapper
interface AmlDtoMapper {

  AmlCriteria toCriteria(AmlQueryRequest request);

  AmlCifResponse fromVo(AmlCifResultVo vo);
}
