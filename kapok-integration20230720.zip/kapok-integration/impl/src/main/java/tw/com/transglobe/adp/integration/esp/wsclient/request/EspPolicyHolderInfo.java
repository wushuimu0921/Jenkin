package tw.com.transglobe.adp.integration.esp.wsclient.request;

import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotEmpty;

/**
 *
 * 保險相關資料 (omicard查詢用)
 *
 * @author Default User
 *
 */
@Data
@Builder
public class EspPolicyHolderInfo {

  @NotEmpty
  String policyNo;

  @NotEmpty
  String proposerId; // 要保人證號
  String insuredId;
  String beneficiaryId;

}
