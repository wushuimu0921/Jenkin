package tw.com.transglobe.adp.integration.ebao.common.wsclient;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.xml.bind.annotation.adapters.XmlAdapter;

class ISODateTimeAdapter extends XmlAdapter<String, LocalDateTime> {

  final DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;

  @Override
  public LocalDateTime unmarshal(String v) throws Exception {
    return LocalDateTime.parse(v, formatter);
  }

  @Override
  public String marshal(LocalDateTime v) throws Exception {
    return v.format(formatter);
  }

}
