package tw.com.transglobe.adp.integration.crystalreport.service;

import org.springframework.stereotype.Service;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import tw.com.softleader.data.security.guardium.annotation.Safeguard;

@Slf4j
@Service
@RequiredArgsConstructor
@Safeguard
public class CrystalReportService {

  final CrystalReportWebServiceClient wsClient;

  public CrystalReportVo getCrystalreport(CrystalGenCmd genCmd) {

    return CrystalReportVo.builder().file(wsClient.getCrystalreport(genCmd)).build();

  }

}
