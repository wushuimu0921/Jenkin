package tw.com.transglobe.adp.integration.ebao.policy.http;

import java.util.List;
import org.mapstruct.Mapper;
import tw.com.transglobe.adp.integration.ebao.policy.http.dto.EbaoPolicyDto;
import tw.com.transglobe.adp.integration.ebao.policy.service.EbaoPolicyCommonVo;

@Mapper
interface EbaoPolicyDtoMapper {

  EbaoPolicyDto fromVo(EbaoPolicyCommonVo vo);

  List<EbaoPolicyDto> fromVoList(List<EbaoPolicyCommonVo> vo);
}
