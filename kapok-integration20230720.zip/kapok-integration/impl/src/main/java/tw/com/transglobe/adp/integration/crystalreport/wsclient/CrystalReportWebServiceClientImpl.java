package tw.com.transglobe.adp.integration.crystalreport.wsclient;

import com.google.common.collect.Lists;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import tw.com.transglobe.adp.integration.config.AdpIntegrationProperties;
import tw.com.transglobe.adp.integration.crystalreport.service.CrystalGenCmd;
import tw.com.transglobe.adp.integration.crystalreport.service.CrystalReportWebServiceClient;

@Slf4j
@RequiredArgsConstructor
class CrystalReportWebServiceClientImpl implements CrystalReportWebServiceClient {

  final CrystalReportFeignClient crystalReportFeignClient;
  final AdpIntegrationProperties adpIntegrationProperties;

  @Override
  public byte[] getCrystalreport(CrystalGenCmd genCmd) {

    EspCrRequest espCrReqeust = getEspCrRequest(genCmd);
    log.info("CrystalReport request:{}, before crystalReportFeignClient", espCrReqeust);
    byte[] result = crystalReportFeignClient.getCrystalreport(espCrReqeust);
    log.info("CrystalReport request:{}, after crystalReportFeignClient", espCrReqeust);
    return result;

  }

  private EspCrRequest getEspCrRequest(CrystalGenCmd genCmd) {
    List<EspCrParameter> parameters = Lists.newArrayList();

    if ("ReportId".equals(genCmd.getReportType().getReportParam())) {
      parameters.add(EspCrParameter.builder()
          .key("ReportId").value(genCmd.getReportId())
          .type("string").isArray("0").build());
    }

    final String moduleName = StringUtils.isEmpty(adpIntegrationProperties.getCrystalReport().getModuleName()) ? "PROD_DEV"
        : adpIntegrationProperties.getCrystalReport().getModuleName();

    return EspCrRequest.builder()
        .requestSystem("GT")
        .moduleName(moduleName)
        .fileFormat("pdf")
        .reportId(genCmd.getReportType().getReportName())
        .p_userid(genCmd.getUserAccount())
        .parameterList(parameters)
        .build();

  }

}
