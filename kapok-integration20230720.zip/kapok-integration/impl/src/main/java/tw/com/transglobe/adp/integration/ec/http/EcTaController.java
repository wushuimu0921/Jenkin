package tw.com.transglobe.adp.integration.ec.http;

import org.springframework.web.bind.annotation.RestController;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import tw.com.transglobe.adp.integration.ec.http.dto.EcTaPolicyPrintReplyRequest;
import tw.com.transglobe.adp.integration.ec.http.dto.EcTaResultDto;
import tw.com.transglobe.adp.integration.ec.service.EcTaService;

@Slf4j
@RestController
@RequiredArgsConstructor
class EcTaController implements EcTaApi {

  final EcTaService service;
  final EcTaDtoMapper mapper;

  //  @Override
  //  public EcResultDto noticePolicyDecision(EcTaPolicyDecisionRequest request) {
  //    // TODO Auto-generated method stub
  //    return null;
  //  }

  @Override
  public EcTaResultDto policyPrintReply(EcTaPolicyPrintReplyRequest request) {
    log.debug("{}", request);
    return mapper.fromVo(service.policyPrintReply(mapper.toCmd(request)));

  }

}
