package tw.com.transglobe.adp.integration.esp.wsclient.request;

import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotEmpty;

@Data
@Builder
public class EspAttachFileInfo {
  @NotEmpty
  String attachFileName;
  @NotEmpty
  String attachFileNameExt;
  @NotEmpty
  String attachFileContent;
  String attachFileCert;
}
