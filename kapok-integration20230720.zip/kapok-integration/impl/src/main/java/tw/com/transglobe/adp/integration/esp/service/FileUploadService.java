package tw.com.transglobe.adp.integration.esp.service;

import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import tw.com.softleader.data.security.guardium.annotation.Safeguard;
import tw.com.transglobe.adp.integration.common.exception.NotFoundException;
import tw.com.transglobe.adp.integration.config.FileUploadProperties;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@Slf4j
@Transactional
@Service
@RequiredArgsConstructor
@Safeguard
public class FileUploadService {

  final FileUploadProperties properties;

  public Resource getResource(final String key, final List<String> paths) {
    log.debug("download key:{}, paths:{}", key, paths);
    return new FileSystemResource(getDirectoryByPaths(paths).resolve(key));
  }

  /**
   * 取得 path
   *
   * @return
   */
  @SneakyThrows
  private Path getPath() {
    if (StringUtils.isBlank(properties.getPath())) {
      throw new NotFoundException("上傳路徑未設定，請洽資訊人員");
    }
    if (!Files.exists(Paths.get(properties.getPath()))) {
      throw new NotFoundException("上傳路徑不存在，請洽資訊人員");
    }
    return Paths.get(properties.getPath());
  }

  /**
   * 依路徑取得資料夾
   *
   * @param paths
   * @return
   */
  @SneakyThrows
  private Path getDirectoryByPaths(List<String> paths) {
    if (CollectionUtils.isEmpty(paths)) {
      return getPath();
    }
    Path path = getPath();
    for (String pathStr : paths) {
      path = Paths.get(String.join(File.separator, path.toString(), pathStr));
      if (!Files.exists(path)) {
        log.error("path不存在:{}", path);
      }
    }
    return path;
  }
}
