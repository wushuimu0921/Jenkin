package tw.com.transglobe.adp.integration.ebao.finance.service.cmd;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

@Data
@Builder
public class EbaoFinanceGetPaymentCmd {

  LocalDate paymentDate;

  String policyCode;

}
