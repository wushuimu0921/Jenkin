package tw.com.transglobe.adp.integration.ebao.finance.service;

import tw.com.transglobe.adp.integration.ebao.finance.service.chequeInfo.EbaoChequeInfoVo;
import tw.com.transglobe.adp.integration.ebao.finance.service.cmd.EbaoFinanceAparCreateCmd;
import tw.com.transglobe.adp.integration.ebao.finance.service.cmd.EbaoFinanceCollectCreateCmd;
import tw.com.transglobe.adp.integration.ebao.finance.service.cmd.EbaoFinanceGetPaymentCmd;
import tw.com.transglobe.adp.integration.ebao.finance.service.cmd.EbaoFinancePayCreateCmd;
import tw.com.transglobe.adp.integration.ebao.finance.service.cmd.EbaoFinanceQueryChequeCmd;
import tw.com.transglobe.adp.integration.ebao.finance.service.cmd.EbaoFinanceTransPostingCmd;
import tw.com.transglobe.adp.integration.ebao.finance.service.exchange.EbaoExchangeResponseVo;
import tw.com.transglobe.adp.integration.ebao.finance.service.transPayment.EbaoTransPaymentInfoVo;
import tw.com.transglobe.adp.integration.ebao.finance.service.transPosting.EbaoTransPostingInfoVo;

import java.util.List;

public interface EbaoCommonWsClient {

  /**
   * 收款 : cashColMixedService
   *
   * @return
   */
  public EbaoExchangeResponseVo exchangeReceivable(String systemCode, String policyNo,
      List<EbaoFinanceAparCreateCmd> aparCreateCmds, List<EbaoFinanceCollectCreateCmd> colCreateCmds);

  /**
   * 付款 : cashPayMixedService
   *
   * @return
   */
  public EbaoExchangeResponseVo exchangePayable(String systemCode, String policyNo,
      List<EbaoFinanceAparCreateCmd> aparCreateCmds, List<EbaoFinancePayCreateCmd> payCreateCmds);

  /**
   * 查詢支票 : queryChequeService
   */
  public EbaoChequeInfoVo getChequeInfo(String systemCode, EbaoFinanceQueryChequeCmd cmd);

  public EbaoTransPaymentInfoVo getPaymentResult(String systemCode, EbaoFinanceGetPaymentCmd cmd);

  /**
   * 過帳查詢 : postingResultService
   */
  public EbaoTransPostingInfoVo getTransPostingInfo(String systemCode, EbaoFinanceTransPostingCmd cmd);

}
