package tw.com.transglobe.adp.integration.ebao.claim.service;

import tw.com.transglobe.adp.integration.commons.enums.ProductGroupType;

public interface EbaoClaimCommonWsClient {

  /**
   * 查詢理賠記錄查詢 : clm071
   *
   * @param rq -
   *        1:保單號碼
   *        2:事故人ID
   *        3:理賠案號
   *        4:要保人ID
   */
  ClaimRecordQuery071RsCmd clm071(ProductGroupType productGroupType, ClaimRecordQuery071RqCmd rq);

}
