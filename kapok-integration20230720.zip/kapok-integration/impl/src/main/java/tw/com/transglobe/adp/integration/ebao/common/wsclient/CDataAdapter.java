package tw.com.transglobe.adp.integration.ebao.common.wsclient;

import javax.xml.bind.annotation.adapters.XmlAdapter;

class CDataAdapter extends XmlAdapter<String, String> {

  @Override
  public String marshal(String data) throws Exception {
    return "\n<![CDATA[\n" + data + "\n]]>\n";
  }

  @Override
  public String unmarshal(String xml) throws Exception {
    return xml;
  }

}
