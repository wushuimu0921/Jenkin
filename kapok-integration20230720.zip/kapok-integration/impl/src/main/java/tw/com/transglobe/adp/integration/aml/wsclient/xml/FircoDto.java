package tw.com.transglobe.adp.integration.aml.wsclient.xml;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import tw.com.transglobe.adp.integration.aml.wsclient.Head;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
@XmlRootElement(name = "FIRCO")
@XmlAccessorType(XmlAccessType.FIELD)
public class FircoDto {
  @XmlElement(name = "head", required = true)
  protected Head head;
  @XmlElement(name = "ret", required = true)
  protected RetDto ret;
  @XmlElement(name = "calc")
  protected CalcDto calcDto;
  @XmlElement(name = "RiskRegion")
  protected String riskRegion;
  @XmlElement(name = "tm")
  protected TmDto tmDto;
  @XmlElement(name = "cif")
  protected CifForXmlDto cif;
  @XmlElement(name = "rel")
  protected List<RelForXmlDto> rels;

}
