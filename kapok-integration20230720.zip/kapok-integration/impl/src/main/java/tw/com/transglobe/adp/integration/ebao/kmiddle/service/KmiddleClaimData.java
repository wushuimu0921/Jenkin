package tw.com.transglobe.adp.integration.ebao.kmiddle.service;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

@Data
@Builder
public class KmiddleClaimData {

  /** 理賠案號 */
  String caseNo;

  /** 理賠受理日 */
  LocalDate approveDate;

  /** 理賠案件狀態 */
  String status;

  /** 事故人ID */
  String insuredId;

  /** 事故人姓名 */
  String insuredName;

  /** 事故日 */
  LocalDate accidentDate;

  /** 事故原因 */
  String accidentReason;

  /** 診斷名 */
  String diagnosisName;

  /** 備註 */
  String remark;

  /** 理賠保單資料 */
  KmiddleClaimPolicyDataList claimPolicyDataList;

  /** 理賠調查資料 */
  KmiddleClaimSurgeryDataList claimSurgeryDataList;

  /** 理賠就醫經過 */
  KmiddleClaimBillDataList claimBillDataList;

}
