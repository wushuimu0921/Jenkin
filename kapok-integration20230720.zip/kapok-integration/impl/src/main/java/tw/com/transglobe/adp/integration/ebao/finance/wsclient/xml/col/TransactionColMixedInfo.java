//
// ���ɮ׬O�� JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.3.0 �Ҳ���
// �аѾ\ <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a>
// �@�����s�sĶ�ӷ����n, �惡�ɮשҰ�������קﳣ�N�|��.
// ���ͮɶ�: 2022.05.28 �� 10:58:49 AM CST
//

package tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.col;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * transactionColMixedInfo complex type �� Java ���O.
 *
 * <p>
 * �U�C���n���q�|���w�����O���]�t���w�����e.
 *
 * <pre>
 * &lt;complexType name="transactionColMixedInfo"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="TransSeq" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="CollectionInfos" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element ref="{}CollectionInfo" maxOccurs="unbounded"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ReceivableInfos" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="ReceivableInfo" type="{}transactionColArapInfo" maxOccurs="unbounded" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "transactionColMixedInfo", propOrder = {
    "transSeq",
    "collectionInfos",
    "receivableInfos"
})
public class TransactionColMixedInfo {

  @XmlElement(name = "TransSeq")
  protected int transSeq;
  @XmlElement(name = "CollectionInfos")
  protected TransactionColMixedInfo.CollectionInfos collectionInfos;
  @XmlElement(name = "ReceivableInfos")
  protected TransactionColMixedInfo.ReceivableInfos receivableInfos;

  /**
   * ���o transSeq �S�ʪ���.
   *
   */
  public int getTransSeq() {
    return transSeq;
  }

  /**
   * �]�w transSeq �S�ʪ���.
   *
   */
  public void setTransSeq(int value) {
    this.transSeq = value;
  }

  /**
   * ���o collectionInfos �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link TransactionColMixedInfo.CollectionInfos }
   *
   */
  public TransactionColMixedInfo.CollectionInfos getCollectionInfos() {
    return collectionInfos;
  }

  /**
   * �]�w collectionInfos �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link TransactionColMixedInfo.CollectionInfos }
   *
   */
  public void setCollectionInfos(TransactionColMixedInfo.CollectionInfos value) {
    this.collectionInfos = value;
  }

  /**
   * ���o receivableInfos �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link TransactionColMixedInfo.ReceivableInfos }
   *
   */
  public TransactionColMixedInfo.ReceivableInfos getReceivableInfos() {
    return receivableInfos;
  }

  /**
   * �]�w receivableInfos �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link TransactionColMixedInfo.ReceivableInfos }
   *
   */
  public void setReceivableInfos(TransactionColMixedInfo.ReceivableInfos value) {
    this.receivableInfos = value;
  }

  /**
   * <p>
   * anonymous complex type �� Java ���O.
   *
   * <p>
   * �U�C���n���q�|���w�����O���]�t���w�����e.
   *
   * <pre>
   * &lt;complexType&gt;
   *   &lt;complexContent&gt;
   *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
   *       &lt;sequence&gt;
   *         &lt;element ref="{}CollectionInfo" maxOccurs="unbounded"/&gt;
   *       &lt;/sequence&gt;
   *     &lt;/restriction&gt;
   *   &lt;/complexContent&gt;
   * &lt;/complexType&gt;
   * </pre>
   *
   *
   */
  @XmlAccessorType(XmlAccessType.FIELD)
  @XmlType(name = "", propOrder = {
      "collectionInfo"
  })
  public static class CollectionInfos {

    @XmlElement(name = "CollectionInfo", required = true)
    protected List<CollectionInfo> collectionInfo;

    /**
     * Gets the value of the collectionInfo property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the collectionInfo property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     *
     * <pre>
     * getCollectionInfo().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CollectionInfo }
     *
     *
     */
    public List<CollectionInfo> getCollectionInfo() {
      if (collectionInfo == null) {
        collectionInfo = new ArrayList<CollectionInfo>();
      }
      return this.collectionInfo;
    }

  }

  /**
   * <p>
   * anonymous complex type �� Java ���O.
   *
   * <p>
   * �U�C���n���q�|���w�����O���]�t���w�����e.
   *
   * <pre>
   * &lt;complexType&gt;
   *   &lt;complexContent&gt;
   *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
   *       &lt;sequence&gt;
   *         &lt;element name="ReceivableInfo" type="{}transactionColArapInfo" maxOccurs="unbounded" minOccurs="0"/&gt;
   *       &lt;/sequence&gt;
   *     &lt;/restriction&gt;
   *   &lt;/complexContent&gt;
   * &lt;/complexType&gt;
   * </pre>
   *
   *
   */
  @XmlAccessorType(XmlAccessType.FIELD)
  @XmlType(name = "", propOrder = {
      "receivableInfo"
  })
  public static class ReceivableInfos {

    @XmlElement(name = "ReceivableInfo")
    protected List<TransactionColArapInfo> receivableInfo;

    /**
     * Gets the value of the receivableInfo property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the receivableInfo property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     *
     * <pre>
     * getReceivableInfo().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TransactionColArapInfo }
     *
     *
     */
    public List<TransactionColArapInfo> getReceivableInfo() {
      if (receivableInfo == null) {
        receivableInfo = new ArrayList<TransactionColArapInfo>();
      }
      return this.receivableInfo;
    }

  }

}
