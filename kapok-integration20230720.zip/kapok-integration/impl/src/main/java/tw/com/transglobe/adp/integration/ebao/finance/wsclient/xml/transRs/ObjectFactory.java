
package tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRs;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the trans package.
 * <p>
 * An ObjectFactory allows you to programatically
 * construct new instances of the Java representation
 * for XML content. The Java representation of XML
 * content can consist of schema derived interfaces
 * and classes representing the binding of schema
 * type definitions, element declarations and model
 * groups. Factory methods for each of these are
 * provided in this class.
 *
 */
@XmlRegistry
public class ObjectFactory {

  private final static QName _GlPaymentFailInfo_QNAME = new QName("", "GlPaymentFailInfo");
  private final static QName _GlPaymentResult_QNAME = new QName("", "GlPaymentResult");
  private final static QName _GlPaymentSuccessInfo_QNAME = new QName("", "GlPaymentSuccessInfo");
  private final static QName _GlTransPaymentInfoRs_QNAME = new QName("", "GlTransPaymentInfoRs");

  /**
   * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: trans
   *
   */
  public ObjectFactory() {
  }

  /**
   * Create an instance of {@link PaymentSuccessInfo }
   *
   */
  public PaymentSuccessInfo createPaymentSuccessInfo() {
    return new PaymentSuccessInfo();
  }

  /**
   * Create an instance of {@link PaymentFailInfo }
   *
   */
  public PaymentFailInfo createPaymentFailInfo() {
    return new PaymentFailInfo();
  }

  /**
   * Create an instance of {@link PaymentResult }
   *
   */
  public PaymentResult createPaymentResult() {
    return new PaymentResult();
  }

  /**
   * Create an instance of {@link TransPaymentInfoRs }
   *
   */
  public TransPaymentInfoRs createTransPaymentInfoRs() {
    return new TransPaymentInfoRs();
  }

  /**
   * Create an instance of {@link PaymentSuccessInfo.PaymentSuccessResults }
   *
   */
  public PaymentSuccessInfo.PaymentSuccessResults createPaymentSuccessInfoPaymentSuccessResults() {
    return new PaymentSuccessInfo.PaymentSuccessResults();
  }

  /**
   * Create an instance of {@link PaymentFailInfo.PaymentFailResults }
   *
   */
  public PaymentFailInfo.PaymentFailResults createPaymentFailInfoPaymentFailResults() {
    return new PaymentFailInfo.PaymentFailResults();
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link PaymentFailInfo }{@code >}
   *
   * @param value
   *        Java instance representing xml element's value.
   * @return
   *         the new instance of {@link JAXBElement }{@code <}{@link PaymentFailInfo }{@code >}
   */
  @XmlElementDecl(namespace = "", name = "GlPaymentFailInfo")
  public JAXBElement<PaymentFailInfo> createGlPaymentFailInfo(PaymentFailInfo value) {
    return new JAXBElement<PaymentFailInfo>(_GlPaymentFailInfo_QNAME, PaymentFailInfo.class, null, value);
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link PaymentResult }{@code >}
   *
   * @param value
   *        Java instance representing xml element's value.
   * @return
   *         the new instance of {@link JAXBElement }{@code <}{@link PaymentResult }{@code >}
   */
  @XmlElementDecl(namespace = "", name = "GlPaymentResult")
  public JAXBElement<PaymentResult> createGlPaymentResult(PaymentResult value) {
    return new JAXBElement<PaymentResult>(_GlPaymentResult_QNAME, PaymentResult.class, null, value);
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link PaymentSuccessInfo }{@code >}
   *
   * @param value
   *        Java instance representing xml element's value.
   * @return
   *         the new instance of {@link JAXBElement }{@code <}{@link PaymentSuccessInfo }{@code >}
   */
  @XmlElementDecl(namespace = "", name = "GlPaymentSuccessInfo")
  public JAXBElement<PaymentSuccessInfo> createGlPaymentSuccessInfo(PaymentSuccessInfo value) {
    return new JAXBElement<PaymentSuccessInfo>(_GlPaymentSuccessInfo_QNAME, PaymentSuccessInfo.class, null, value);
  }

  /**
   * Create an instance of {@link JAXBElement }{@code <}{@link TransPaymentInfoRs }{@code >}
   *
   * @param value
   *        Java instance representing xml element's value.
   * @return
   *         the new instance of {@link JAXBElement }{@code <}{@link TransPaymentInfoRs }{@code >}
   */
  @XmlElementDecl(namespace = "", name = "GlTransPaymentInfoRs")
  public JAXBElement<TransPaymentInfoRs> createGlTransPaymentInfoRs(TransPaymentInfoRs value) {
    return new JAXBElement<TransPaymentInfoRs>(_GlTransPaymentInfoRs_QNAME, TransPaymentInfoRs.class, null, value);
  }

}
