package tw.com.transglobe.adp.integration.ebao.claim.wsclient.xml;

import lombok.Getter;
import lombok.Setter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import java.math.BigDecimal;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "productDataVo", propOrder = {
    "internalId",
    "productName",
    "payAmount"

})
@Getter
@Setter
public class ProductDataVO {

  @XmlElement(required = true)
  protected String internalId;

  @XmlElement(required = true)
  protected String productName;

  @XmlElement(required = true)
  protected BigDecimal payAmount;
}
