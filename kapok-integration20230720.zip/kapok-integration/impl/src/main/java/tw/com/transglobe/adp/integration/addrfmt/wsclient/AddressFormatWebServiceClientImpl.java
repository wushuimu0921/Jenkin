package tw.com.transglobe.adp.integration.addrfmt.wsclient;

import java.io.IOException;
import java.net.URL;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import tw.com.transglobe.adp.integration.addrfmt.service.AddressFormatVo;
import tw.com.transglobe.adp.integration.addrfmt.service.AddressFormatWebServiceClient;
import tw.com.transglobe.adp.integration.config.AdpIntegrationProperties;

@Slf4j
@RequiredArgsConstructor
public class AddressFormatWebServiceClientImpl implements AddressFormatWebServiceClient {

  final AdpIntegrationProperties properties;

  @Override
  public AddressFormatVo getAddressFormat(String inputAddress) {

    AddressFormatVo vo = new AddressFormatVo();
    try {
      //      var resource = new ClassPathResource("wsdl/address-format.wsdl");
      Service serviceImpl = new Service(new URL(properties.getAddrFmt().getUrl()));
      ServiceSoap service = serviceImpl.getServiceSoap();

      String result = service.orgAddEz(inputAddress);
      log.debug("{}", result);

      String[] formats = result.split("\\|");
      //    for(int i=0; i<formats.length; i++) {
      //      log.debug("index={}, data={}",i, formats[i]);
      //    }
      //
      vo.setZipCode(formats[0]);
      vo.setArea(formats[1]);
      vo.setDistrict(formats[2]);
      vo.setVillage(formats[3]);
      vo.setRoad(formats[4]);
      vo.setNeighborhood(formats[5]);
      vo.setLane(formats[6]);
      vo.setAlley(formats[7]);
      vo.setSubAlley(formats[8]);
      vo.setNumber(formats[9]);
      vo.setFloor(formats[10]);
      vo.setOther(formats[11]);
      vo.setErrorDescription(formats[12]);
      vo.setErrorCode(formats[13]);
      vo.setMailBox(formats[14]);
      vo.setFullAddress(formats[15]);
      vo.setReserve(formats[16]);
    } catch (IOException e) {
      log.error("讀取 resources/wsdl/address-format.wsdl 失敗", e);
    }
    return vo;
  }
}
