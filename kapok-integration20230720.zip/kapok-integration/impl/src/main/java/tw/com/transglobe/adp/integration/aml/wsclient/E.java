
package tw.com.transglobe.adp.integration.aml.wsclient;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * E complex type 的 Java 類別.
 *
 * <p>
 * 下列綱要片段會指定此類別中包含的預期內容.
 *
 * <pre>
 * &lt;complexType name="E"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="NAM" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="VAL" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "E", propOrder = {
    "nam",
    "val"
})
public class E {

  @XmlElement(name = "NAM")
  protected String nam;
  @XmlElement(name = "VAL")
  protected String val;

  /**
   * 取得 nam 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getNAM() {
    return nam;
  }

  /**
   * 設定 nam 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setNAM(String value) {
    this.nam = value;
  }

  /**
   * 取得 val 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getVAL() {
    return val;
  }

  /**
   * 設定 val 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setVAL(String value) {
    this.val = value;
  }

}
