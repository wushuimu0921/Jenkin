package tw.com.transglobe.adp.integration.ebao.kmiddle.wsclient;

import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import tw.com.transglobe.adp.integration.commons.enums.ProductGroupType;
import tw.com.transglobe.adp.integration.ebao.kmiddle.service.KmiddleClaimDataList;
import tw.com.transglobe.adp.integration.ebao.kmiddle.service.KmiddleClaimVo;
import tw.com.transglobe.adp.integration.ebao.kmiddle.service.KmiddleCommonWsClient;
import tw.com.transglobe.adp.integration.ebao.kmiddle.service.KmiddlePolicyVo;

import java.util.List;

@Slf4j
@RequiredArgsConstructor
public class KmiddleCommonWsClientMock implements KmiddleCommonWsClient {

  @SneakyThrows
  @Override
  public KmiddleClaimVo cmn130(ProductGroupType productGroupType, String type, String data) {
    return KmiddleClaimVo.builder()
        .claimDataList(KmiddleClaimDataList.builder()
            .claimData(List.of())
            .build())
        .build();
  }

  @SneakyThrows
  @Override
  public List<KmiddlePolicyVo> cmn150(ProductGroupType productGroupType, String idno) {
    return List.of();
  }

}
