//
// ���ɮ׬O�� JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.3.0 �Ҳ���
// �аѾ\ <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a>
// �@�����s�sĶ�ӷ����n, �惡�ɮשҰ�������קﳣ�N�|��.
// ���ͮɶ�: 2022.05.28 �� 10:58:57 AM CST
//

package tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.pay;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import tw.com.transglobe.adp.integration.ebao.common.wsclient.SlashLocalDateAdapter;
import tw.com.transglobe.adp.integration.ebao.common.wsclient.SlashLocalDateTimeAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "paymentInfo", propOrder = {
    "dataDate",
    "cashSeq",
    "systemId",
    "subSystemId",
    "businessTypeId",
    "refId",
    "adpPolNo",
    "adpNonPolicyCode",
    "divideIndi",
    "phCertiType",
    "phCertiCode",
    "phName",
    "feeType",
    "payMode",
    "moneyId",
    "feeAmount",
    "payMoneyId",
    "payAmount",
    "exchangeDate",
    "exchangeRate",
    "cashierDeptCode",
    "cashierDeptName",
    "cashierId",
    "cashierName",
    "cashierJobNo",
    "cashierTime",
    "agentChannelType",
    "agentChannelCode",
    "agentRegisterCode",
    "dueTime",
    "approveDate",
    "approveUserId",
    "approveUserName",
    "approveUserDeptCode",
    "approveUserDeptName",
    "approveUserJobNo",
    "paymentSource",
    "withdrawType",
    "payeeCertiCode",
    "payeeName",
    "payeeBankCode",
    "payeeBankName",
    "payeeAccount",
    "creditCardNum",
    "creditCardAuth",
    "creditCardExpireDate",
    "creditCardTransDate",
    "creditCardAcquirerId",
    "cancelEndorsementIndi",
    "cancelScoreIndi",
    "sendZipCode",
    "sendAddress",
    "companyName",
    "recipientName",
    "attachmentIndi",
    "posAcceptNo",
    "chequeSendType",
    "refNo",
    "formNo",
    "docNo",
    "clmCaseNo",
    "accountingDate",
    "productCategory",
    "agentChannelName",
    "agentChannelTypeCode",
    "relatedId"
})
public class PaymentInfo {

  @XmlElement(name = "DataDate", required = true)
  @XmlJavaTypeAdapter(SlashLocalDateTimeAdapter.class)
  protected LocalDateTime dataDate;

  @XmlElement(name = "CashSeq")
  protected int cashSeq;
  @XmlElement(name = "SystemId")
  protected int systemId;
  @XmlElement(name = "SubSystemId")
  protected int subSystemId;
  @XmlElement(name = "BusinessTypeId")
  protected int businessTypeId;
  @XmlElement(name = "RefId", required = true)
  protected String refId;
  @XmlElement(name = "AdpPolNo")
  protected String adpPolNo;
  @XmlElement(name = "AdpNonPolicyCode")
  protected String adpNonPolicyCode;
  @XmlElement(name = "DivideIndi")
  protected String divideIndi;
  @XmlElement(name = "PhCertiType")
  protected String phCertiType;
  @XmlElement(name = "PhCertiCode")
  protected String phCertiCode;
  @XmlElement(name = "PhName")
  protected String phName;
  @XmlElement(name = "FeeType")
  protected int feeType;
  @XmlElement(name = "PayMode")
  protected int payMode;
  @XmlElement(name = "MoneyId")
  protected int moneyId;
  @XmlElement(name = "FeeAmount", required = true)
  protected BigDecimal feeAmount;
  @XmlElement(name = "PayMoneyId")
  protected int payMoneyId;
  @XmlElement(name = "PayAmount", required = true)
  protected BigDecimal payAmount;

  @XmlElement(name = "ExchangeDate")
  @XmlJavaTypeAdapter(SlashLocalDateAdapter.class)
  protected LocalDate exchangeDate;

  @XmlElement(name = "ExchangeRate")
  protected BigDecimal exchangeRate;
  @XmlElement(name = "CashierDeptCode", required = true)
  protected String cashierDeptCode;
  @XmlElement(name = "CashierDeptName", required = true)
  protected String cashierDeptName;
  @XmlElement(name = "CashierId")
  protected String cashierId;
  @XmlElement(name = "CashierName", required = true)
  protected String cashierName;
  @XmlElement(name = "CashierJobNo", required = true)
  protected String cashierJobNo;
  @XmlElement(name = "CashierTime", required = true)
  @XmlJavaTypeAdapter(SlashLocalDateTimeAdapter.class)
  LocalDateTime cashierTime;

  @XmlElement(name = "AgentChannelType")
  protected Long agentChannelType;
  @XmlElement(name = "AgentChannelCode")
  protected String agentChannelCode;
  @XmlElement(name = "AgentRegisterCode")
  protected String agentRegisterCode;

  @XmlElement(name = "DueTime", required = true)
  @XmlJavaTypeAdapter(SlashLocalDateAdapter.class)
  protected LocalDate dueTime;

  @XmlElement(name = "ApproveDate", required = true)
  @XmlJavaTypeAdapter(SlashLocalDateTimeAdapter.class)
  protected LocalDateTime approveDate;

  @XmlElement(name = "ApproveUserId")
  protected String approveUserId;
  @XmlElement(name = "ApproveUserName", required = true)
  protected String approveUserName;
  @XmlElement(name = "ApproveUserJobNo", required = true)
  protected String approveUserJobNo;

  @XmlElement(name = "ApproveUserDeptCode", required = true)
  protected String approveUserDeptCode;
  @XmlElement(name = "ApproveUserDeptName", required = true)
  protected String approveUserDeptName;

  @XmlElement(name = "PayeeCertiCode")
  protected String payeeCertiCode;
  @XmlElement(name = "PayeeName")
  protected String payeeName;
  @XmlElement(name = "PayeeBankCode")
  protected String payeeBankCode;
  @XmlElement(name = "PayeeBankName")
  protected String payeeBankName;
  @XmlElement(name = "PayeeAccount")
  protected String payeeAccount;
  @XmlElement(name = "CreditCardNum")
  protected String creditCardNum;
  @XmlElement(name = "CreditCardAuth")
  protected String creditCardAuth;

  @XmlElement(name = "CreditCardExpireDate")
  @XmlJavaTypeAdapter(SlashLocalDateAdapter.class)
  protected LocalDate creditCardExpireDate;

  @XmlElement(name = "CreditCardTransDate")
  @XmlJavaTypeAdapter(SlashLocalDateAdapter.class)
  protected LocalDate creditCardTransDate;

  @XmlElement(name = "CreditCardAcquirerId")
  protected Long creditCardAcquirerId;
  @XmlElement(name = "WithdrawType")
  protected String withdrawType;
  @XmlElement(name = "PaymentSource", required = true)
  protected String paymentSource;
  @XmlElement(name = "CancelEndorsementIndi")
  protected String cancelEndorsementIndi;
  @XmlElement(name = "CancelScoreIndi")
  protected String cancelScoreIndi;
  @XmlElement(name = "SendZipCode")
  protected String sendZipCode;
  @XmlElement(name = "SendAddress")
  protected String sendAddress;
  @XmlElement(name = "CompanyName")
  protected String companyName;
  @XmlElement(name = "RecipientName")
  protected String recipientName;
  @XmlElement(name = "AttachmentIndi")
  protected String attachmentIndi;
  @XmlElement(name = "PosAcceptNo")
  protected String posAcceptNo;
  @XmlElement(name = "ChequeSendType")
  protected String chequeSendType;
  @XmlElement(name = "RefNo")
  protected String refNo;
  @XmlElement(name = "FormNo")
  protected String formNo;
  @XmlElement(name = "DocNo")
  protected String docNo;
  @XmlElement(name = "ClmCaseNo")
  protected String clmCaseNo;
  @XmlElement(name = "AccountingDate")
  protected String accountingDate;
  @XmlElement(name = "ProductCategory")
  protected String productCategory;
  @XmlElement(name = "AgentChannelName")
  protected String agentChannelName;
  @XmlElement(name = "AgentChannelTypeCode")
  protected String agentChannelTypeCode;
  @XmlElement(name = "RelatedId")
  protected Long relatedId;

  /**
   * ���o dataDate �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public LocalDateTime getDataDate() {
    return dataDate;
  }

  /**
   * �]�w dataDate �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setDataDate(LocalDateTime value) {
    this.dataDate = value;
  }

  /**
   * ���o cashSeq �S�ʪ���.
   *
   */
  public int getCashSeq() {
    return cashSeq;
  }

  /**
   * �]�w cashSeq �S�ʪ���.
   *
   */
  public void setCashSeq(int value) {
    this.cashSeq = value;
  }

  /**
   * ���o systemId �S�ʪ���.
   *
   */
  public int getSystemId() {
    return systemId;
  }

  /**
   * �]�w systemId �S�ʪ���.
   *
   */
  public void setSystemId(int value) {
    this.systemId = value;
  }

  /**
   * ���o subSystemId �S�ʪ���.
   *
   */
  public int getSubSystemId() {
    return subSystemId;
  }

  /**
   * �]�w subSystemId �S�ʪ���.
   *
   */
  public void setSubSystemId(int value) {
    this.subSystemId = value;
  }

  /**
   * ���o businessTypeId �S�ʪ���.
   *
   */
  public int getBusinessTypeId() {
    return businessTypeId;
  }

  /**
   * �]�w businessTypeId �S�ʪ���.
   *
   */
  public void setBusinessTypeId(int value) {
    this.businessTypeId = value;
  }

  /**
   * ���o refId �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getRefId() {
    return refId;
  }

  /**
   * �]�w refId �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setRefId(String value) {
    this.refId = value;
  }

  /**
   * ���o adpPolNo �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getAdpPolNo() {
    return adpPolNo;
  }

  /**
   * �]�w adpPolNo �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setAdpPolNo(String value) {
    this.adpPolNo = value;
  }

  /**
   * ���o adpNonPolicyCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getAdpNonPolicyCode() {
    return adpNonPolicyCode;
  }

  /**
   * �]�w adpNonPolicyCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setAdpNonPolicyCode(String value) {
    this.adpNonPolicyCode = value;
  }

  /**
   * ���o divideIndi �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getDivideIndi() {
    return divideIndi;
  }

  /**
   * �]�w divideIndi �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setDivideIndi(String value) {
    this.divideIndi = value;
  }

  /**
   * ���o phCertiType �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getPhCertiType() {
    return phCertiType;
  }

  /**
   * �]�w phCertiType �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setPhCertiType(String value) {
    this.phCertiType = value;
  }

  /**
   * ���o phCertiCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getPhCertiCode() {
    return phCertiCode;
  }

  /**
   * �]�w phCertiCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setPhCertiCode(String value) {
    this.phCertiCode = value;
  }

  /**
   * ���o phName �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getPhName() {
    return phName;
  }

  /**
   * �]�w phName �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setPhName(String value) {
    this.phName = value;
  }

  /**
   * ���o feeType �S�ʪ���.
   *
   */
  public int getFeeType() {
    return feeType;
  }

  /**
   * �]�w feeType �S�ʪ���.
   *
   */
  public void setFeeType(int value) {
    this.feeType = value;
  }

  /**
   * ���o payMode �S�ʪ���.
   *
   */
  public int getPayMode() {
    return payMode;
  }

  /**
   * �]�w payMode �S�ʪ���.
   *
   */
  public void setPayMode(int value) {
    this.payMode = value;
  }

  /**
   * ���o moneyId �S�ʪ���.
   *
   */
  public int getMoneyId() {
    return moneyId;
  }

  /**
   * �]�w moneyId �S�ʪ���.
   *
   */
  public void setMoneyId(int value) {
    this.moneyId = value;
  }

  /**
   * ���o feeAmount �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link BigDecimal }
   *
   */
  public BigDecimal getFeeAmount() {
    return feeAmount;
  }

  /**
   * �]�w feeAmount �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link BigDecimal }
   *
   */
  public void setFeeAmount(BigDecimal value) {
    this.feeAmount = value;
  }

  /**
   * ���o payMoneyId �S�ʪ���.
   *
   */
  public int getPayMoneyId() {
    return payMoneyId;
  }

  /**
   * �]�w payMoneyId �S�ʪ���.
   *
   */
  public void setPayMoneyId(int value) {
    this.payMoneyId = value;
  }

  /**
   * ���o payAmount �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link BigDecimal }
   *
   */
  public BigDecimal getPayAmount() {
    return payAmount;
  }

  /**
   * �]�w payAmount �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link BigDecimal }
   *
   */
  public void setPayAmount(BigDecimal value) {
    this.payAmount = value;
  }

  /**
   * ���o exchangeDate �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public LocalDate getExchangeDate() {
    return exchangeDate;
  }

  /**
   * �]�w exchangeDate �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setExchangeDate(LocalDate value) {
    this.exchangeDate = value;
  }

  /**
   * ���o exchangeRate �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link BigDecimal }
   *
   */
  public BigDecimal getExchangeRate() {
    return exchangeRate;
  }

  /**
   * �]�w exchangeRate �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link BigDecimal }
   *
   */
  public void setExchangeRate(BigDecimal value) {
    this.exchangeRate = value;
  }

  /**
   * ���o cashierDeptCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getCashierDeptCode() {
    return cashierDeptCode;
  }

  /**
   * �]�w cashierDeptCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCashierDeptCode(String value) {
    this.cashierDeptCode = value;
  }

  /**
   * ���o cashierDeptName �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getCashierDeptName() {
    return cashierDeptName;
  }

  /**
   * �]�w cashierDeptName �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCashierDeptName(String value) {
    this.cashierDeptName = value;
  }

  /**
   * ���o cashierId �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getCashierId() {
    return cashierId;
  }

  /**
   * �]�w cashierId �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCashierId(String value) {
    this.cashierId = value;
  }

  /**
   * ���o cashierName �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getCashierName() {
    return cashierName;
  }

  /**
   * �]�w cashierName �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCashierName(String value) {
    this.cashierName = value;
  }

  /**
   * ���o agentChannelType �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link Long }
   *
   */
  public Long getAgentChannelType() {
    return agentChannelType;
  }

  /**
   * �]�w agentChannelType �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link Long }
   *
   */
  public void setAgentChannelType(Long value) {
    this.agentChannelType = value;
  }

  /**
   * ���o agentChannelCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getAgentChannelCode() {
    return agentChannelCode;
  }

  /**
   * �]�w agentChannelCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setAgentChannelCode(String value) {
    this.agentChannelCode = value;
  }

  /**
   * ���o agentRegisterCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getAgentRegisterCode() {
    return agentRegisterCode;
  }

  /**
   * �]�w agentRegisterCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setAgentRegisterCode(String value) {
    this.agentRegisterCode = value;
  }

  /**
   * ���o dueTime �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public LocalDate getDueTime() {
    return dueTime;
  }

  /**
   * �]�w dueTime �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setDueTime(LocalDate value) {
    this.dueTime = value;
  }

  /**
   * ���o approveDate �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public LocalDateTime getApproveDate() {
    return approveDate;
  }

  /**
   * �]�w approveDate �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setApproveDate(LocalDateTime value) {
    this.approveDate = value;
  }

  /**
   * ���o approveUserId �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getApproveUserId() {
    return approveUserId;
  }

  /**
   * �]�w approveUserId �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setApproveUserId(String value) {
    this.approveUserId = value;
  }

  /**
   * ���o approveUserName �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getApproveUserName() {
    return approveUserName;
  }

  /**
   * �]�w approveUserName �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setApproveUserName(String value) {
    this.approveUserName = value;
  }

  /**
   * ���o approveUserDeptCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getApproveUserDeptCode() {
    return approveUserDeptCode;
  }

  /**
   * �]�w approveUserDeptCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setApproveUserDeptCode(String value) {
    this.approveUserDeptCode = value;
  }

  /**
   * ���o approveUserDeptName �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getApproveUserDeptName() {
    return approveUserDeptName;
  }

  /**
   * �]�w approveUserDeptName �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setApproveUserDeptName(String value) {
    this.approveUserDeptName = value;
  }

  /**
   * ���o payeeCertiCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getPayeeCertiCode() {
    return payeeCertiCode;
  }

  /**
   * �]�w payeeCertiCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setPayeeCertiCode(String value) {
    this.payeeCertiCode = value;
  }

  /**
   * ���o payeeName �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getPayeeName() {
    return payeeName;
  }

  /**
   * �]�w payeeName �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setPayeeName(String value) {
    this.payeeName = value;
  }

  /**
   * ���o payeeBankCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getPayeeBankCode() {
    return payeeBankCode;
  }

  /**
   * �]�w payeeBankCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setPayeeBankCode(String value) {
    this.payeeBankCode = value;
  }

  /**
   * ���o payeeBankName �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getPayeeBankName() {
    return payeeBankName;
  }

  /**
   * �]�w payeeBankName �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setPayeeBankName(String value) {
    this.payeeBankName = value;
  }

  /**
   * ���o payeeAccount �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getPayeeAccount() {
    return payeeAccount;
  }

  /**
   * �]�w payeeAccount �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setPayeeAccount(String value) {
    this.payeeAccount = value;
  }

  /**
   * ���o creditCardNum �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getCreditCardNum() {
    return creditCardNum;
  }

  /**
   * �]�w creditCardNum �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCreditCardNum(String value) {
    this.creditCardNum = value;
  }

  /**
   * ���o creditCardAuth �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getCreditCardAuth() {
    return creditCardAuth;
  }

  /**
   * �]�w creditCardAuth �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCreditCardAuth(String value) {
    this.creditCardAuth = value;
  }

  /**
   * ���o creditCardExpireDate �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public LocalDate getCreditCardExpireDate() {
    return creditCardExpireDate;
  }

  /**
   * �]�w creditCardExpireDate �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCreditCardExpireDate(LocalDate value) {
    this.creditCardExpireDate = value;
  }

  public String getCashierJobNo() {
    return cashierJobNo;
  }

  public void setCashierJobNo(String cashierJobNo) {
    this.cashierJobNo = cashierJobNo;
  }

  public String getApproveUserJobNo() {
    return approveUserJobNo;
  }

  public void setApproveUserJobNo(String approveUserJobNo) {
    this.approveUserJobNo = approveUserJobNo;
  }

  public LocalDate getCreditCardTransDate() {
    return creditCardTransDate;
  }

  public void setCreditCardTransDate(LocalDate creditCardTransDate) {
    this.creditCardTransDate = creditCardTransDate;
  }

  /**
   * ���o creditCardAcquirerId �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link Long }
   *
   */
  public Long getCreditCardAcquirerId() {
    return creditCardAcquirerId;
  }

  /**
   * �]�w creditCardAcquirerId �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link Long }
   *
   */
  public void setCreditCardAcquirerId(Long value) {
    this.creditCardAcquirerId = value;
  }

  /**
   * ���o withdrawType �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getWithdrawType() {
    return withdrawType;
  }

  /**
   * �]�w withdrawType �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setWithdrawType(String value) {
    this.withdrawType = value;
  }

  /**
   * ���o paymentSource �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getPaymentSource() {
    return paymentSource;
  }

  /**
   * �]�w paymentSource �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setPaymentSource(String value) {
    this.paymentSource = value;
  }

  /**
   * ���o cancelEndorsementIndi �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getCancelEndorsementIndi() {
    return cancelEndorsementIndi;
  }

  /**
   * �]�w cancelEndorsementIndi �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCancelEndorsementIndi(String value) {
    this.cancelEndorsementIndi = value;
  }

  /**
   * ���o cancelScoreIndi �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getCancelScoreIndi() {
    return cancelScoreIndi;
  }

  /**
   * �]�w cancelScoreIndi �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCancelScoreIndi(String value) {
    this.cancelScoreIndi = value;
  }

  /**
   * ���o sendZipCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getSendZipCode() {
    return sendZipCode;
  }

  /**
   * �]�w sendZipCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setSendZipCode(String value) {
    this.sendZipCode = value;
  }

  /**
   * ���o sendAddress �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getSendAddress() {
    return sendAddress;
  }

  /**
   * �]�w sendAddress �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setSendAddress(String value) {
    this.sendAddress = value;
  }

  /**
   * ���o companyName �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getCompanyName() {
    return companyName;
  }

  /**
   * �]�w companyName �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setCompanyName(String value) {
    this.companyName = value;
  }

  /**
   * ���o recipientName �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getRecipientName() {
    return recipientName;
  }

  /**
   * �]�w recipientName �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setRecipientName(String value) {
    this.recipientName = value;
  }

  /**
   * ���o attachmentIndi �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getAttachmentIndi() {
    return attachmentIndi;
  }

  /**
   * �]�w attachmentIndi �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setAttachmentIndi(String value) {
    this.attachmentIndi = value;
  }

  /**
   * ���o posAcceptNo �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getPosAcceptNo() {
    return posAcceptNo;
  }

  /**
   * �]�w posAcceptNo �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setPosAcceptNo(String value) {
    this.posAcceptNo = value;
  }

  /**
   * ���o chequeSendType �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getChequeSendType() {
    return chequeSendType;
  }

  /**
   * �]�w chequeSendType �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setChequeSendType(String value) {
    this.chequeSendType = value;
  }

  /**
   * ���o refNo �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getRefNo() {
    return refNo;
  }

  /**
   * �]�w refNo �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setRefNo(String value) {
    this.refNo = value;
  }

  /**
   * ���o formNo �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getFormNo() {
    return formNo;
  }

  /**
   * �]�w formNo �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setFormNo(String value) {
    this.formNo = value;
  }

  /**
   * ���o docNo �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getDocNo() {
    return docNo;
  }

  /**
   * �]�w docNo �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setDocNo(String value) {
    this.docNo = value;
  }

  /**
   * ���o clmCaseNo �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getClmCaseNo() {
    return clmCaseNo;
  }

  /**
   * �]�w clmCaseNo �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setClmCaseNo(String value) {
    this.clmCaseNo = value;
  }

  /**
   * ���o accountingDate �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getAccountingDate() {
    return accountingDate;
  }

  /**
   * �]�w accountingDate �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setAccountingDate(String value) {
    this.accountingDate = value;
  }

  /**
   * ���o productCategory �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getProductCategory() {
    return productCategory;
  }

  /**
   * �]�w productCategory �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setProductCategory(String value) {
    this.productCategory = value;
  }

  /**
   * ���o agentChannelName �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getAgentChannelName() {
    return agentChannelName;
  }

  /**
   * �]�w agentChannelName �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setAgentChannelName(String value) {
    this.agentChannelName = value;
  }

  /**
   * ���o agentChannelTypeCode �S�ʪ���.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getAgentChannelTypeCode() {
    return agentChannelTypeCode;
  }

  /**
   * �]�w agentChannelTypeCode �S�ʪ���.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setAgentChannelTypeCode(String value) {
    this.agentChannelTypeCode = value;
  }

  public LocalDateTime getCashierTime() {
    return cashierTime;
  }

  public void setCashierTime(LocalDateTime cashierTime) {
    this.cashierTime = cashierTime;
  }

  public Long getRelatedId() {
    return relatedId;
  }

  public void setRelatedId(Long relatedId) {
    this.relatedId = relatedId;
  }

}
