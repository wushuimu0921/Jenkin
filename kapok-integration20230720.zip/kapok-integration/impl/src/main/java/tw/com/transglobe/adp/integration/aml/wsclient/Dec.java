
package tw.com.transglobe.adp.integration.aml.wsclient;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * dec complex type 的 Java 類別.
 *
 * <p>
 * 下列綱要片段會指定此類別中包含的預期內容.
 *
 * <pre>
 * &lt;complexType name="dec"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DecType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DecDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DecBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DecComments" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "dec", propOrder = {
    "decType",
    "decDate",
    "decBy",
    "decComments"
})
public class Dec {

  @XmlElement(name = "DecType")
  protected String decType;
  @XmlElement(name = "DecDate")
  protected String decDate;
  @XmlElement(name = "DecBy")
  protected String decBy;
  @XmlElement(name = "DecComments")
  protected String decComments;

  /**
   * 取得 decType 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getDecType() {
    return decType;
  }

  /**
   * 設定 decType 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setDecType(String value) {
    this.decType = value;
  }

  /**
   * 取得 decDate 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getDecDate() {
    return decDate;
  }

  /**
   * 設定 decDate 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setDecDate(String value) {
    this.decDate = value;
  }

  /**
   * 取得 decBy 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getDecBy() {
    return decBy;
  }

  /**
   * 設定 decBy 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setDecBy(String value) {
    this.decBy = value;
  }

  /**
   * 取得 decComments 特性的值.
   *
   * @return
   *         possible object is
   *         {@link String }
   *
   */
  public String getDecComments() {
    return decComments;
  }

  /**
   * 設定 decComments 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link String }
   *
   */
  public void setDecComments(String value) {
    this.decComments = value;
  }

}
