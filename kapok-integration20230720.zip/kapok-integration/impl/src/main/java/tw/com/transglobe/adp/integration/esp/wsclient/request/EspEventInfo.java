package tw.com.transglobe.adp.integration.esp.wsclient.request;

import lombok.Builder;
import lombok.Data;

/**
 * ESP 事件資訊
 *
 * @author Default User
 *
 */
@Data
@Builder
public class EspEventInfo {

  // ESP的事件ID，有塞此欄位則可在ESP遞送狀態查詢用事件ID查詢
  String eventId;

}
