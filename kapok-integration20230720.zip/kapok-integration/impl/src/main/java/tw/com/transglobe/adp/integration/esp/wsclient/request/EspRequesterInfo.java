package tw.com.transglobe.adp.integration.esp.wsclient.request;

import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotEmpty;

/**
 * ESP 記錄來源用途用
 *
 * @author Default User
 *
 */
@Data
@Builder
public class EspRequesterInfo {
  @NotEmpty
  String contactSysId; // ADP-GI
  @NotEmpty
  String contactSysOperatorId; // 登入者帳號
  String contactSysOperatorName; // 登入者姓名
  @NotEmpty
  String functionCategory; // 使用功能 ID
  @NotEmpty
  String functionName; // 使用功能說明

}
