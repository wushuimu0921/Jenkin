package tw.com.transglobe.adp.integration.ebao.rest.http;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RestController;
import tw.com.transglobe.adp.integration.ebao.rest.http.dto.QmlistDto;
import tw.com.transglobe.adp.integration.ebao.rest.http.request.QmlistRequest;
import tw.com.transglobe.adp.integration.ebao.rest.service.EbaoRestQmlistCriteria;
import tw.com.transglobe.adp.integration.ebao.rest.service.EbaoRestService;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
class EbaoRestController implements EbaoRestApi {

  final EbaoRestService service;
  final EbaoRestDtoMapper mapper;

  @Override
  public List<QmlistDto> getQmlist(QmlistRequest request) {
    EbaoRestQmlistCriteria criteria = mapper.toCriteria(request);
    return mapper.fromVoList(service.getQmlist(criteria));
  }

}
