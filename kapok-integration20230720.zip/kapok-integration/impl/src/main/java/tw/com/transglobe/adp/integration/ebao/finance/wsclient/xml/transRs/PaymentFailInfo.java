
package tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.transRs;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * paymentFailInfo complex type 的 Java 類別.
 *
 * <p>
 * 下列綱要片段會指定此類別中包含的預期內容.
 *
 * <pre>
 * &lt;complexType name="paymentFailInfo"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="FailCount" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="PaymentFailResults" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="PaymentFailResult" type="{}paymentResult" maxOccurs="unbounded"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "paymentFailInfo", propOrder = {
    "failCount",
    "paymentFailResults"
})
public class PaymentFailInfo {

  @XmlElement(name = "FailCount")
  protected int failCount;
  @XmlElement(name = "PaymentFailResults")
  protected PaymentFailInfo.PaymentFailResults paymentFailResults;

  /**
   * 取得 failCount 特性的值.
   *
   */
  public int getFailCount() {
    return failCount;
  }

  /**
   * 設定 failCount 特性的值.
   *
   */
  public void setFailCount(int value) {
    this.failCount = value;
  }

  /**
   * 取得 paymentFailResults 特性的值.
   *
   * @return
   *         possible object is
   *         {@link PaymentFailInfo.PaymentFailResults }
   *
   */
  public PaymentFailInfo.PaymentFailResults getPaymentFailResults() {
    return paymentFailResults;
  }

  /**
   * 設定 paymentFailResults 特性的值.
   *
   * @param value
   *        allowed object is
   *        {@link PaymentFailInfo.PaymentFailResults }
   *
   */
  public void setPaymentFailResults(PaymentFailInfo.PaymentFailResults value) {
    this.paymentFailResults = value;
  }

  /**
   * <p>
   * anonymous complex type 的 Java 類別.
   *
   * <p>
   * 下列綱要片段會指定此類別中包含的預期內容.
   *
   * <pre>
   * &lt;complexType&gt;
   *   &lt;complexContent&gt;
   *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
   *       &lt;sequence&gt;
   *         &lt;element name="PaymentFailResult" type="{}paymentResult" maxOccurs="unbounded"/&gt;
   *       &lt;/sequence&gt;
   *     &lt;/restriction&gt;
   *   &lt;/complexContent&gt;
   * &lt;/complexType&gt;
   * </pre>
   *
   *
   */
  @XmlAccessorType(XmlAccessType.FIELD)
  @XmlType(name = "", propOrder = {
      "paymentFailResult"
  })
  public static class PaymentFailResults {

    @XmlElement(name = "PaymentFailResult", required = true)
    protected List<PaymentResult> paymentFailResult;

    /**
     * Gets the value of the paymentFailResult property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the paymentFailResult property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     * 
     * <pre>
     * getPaymentFailResult().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PaymentResult }
     *
     *
     */
    public List<PaymentResult> getPaymentFailResult() {
      if (paymentFailResult == null) {
        paymentFailResult = new ArrayList<PaymentResult>();
      }
      return this.paymentFailResult;
    }

  }

}
