package tw.com.transglobe.adp.integration.ebao.common.service.vo;

import lombok.Data;
import tw.com.transglobe.adp.integration.commons.enums.Status;

@Data
public class EbaoCommonResponseVo {
  Status status;
  String message;
  String rsBody;
}
