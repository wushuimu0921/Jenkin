package tw.com.transglobe.adp.integration.ebao.finance.wsclient.xml.exchangeRs;

import javax.xml.bind.annotation.*;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "eventMsg", propOrder = {
    "detectTypeName",
    "messages"
})
public class EventMsg {

  @XmlElement(name = "DetectTypeName")
  protected String detectTypeName;

  @XmlElementWrapper(name = "Messages")
  @XmlElement(name = "Message")
  protected List<Message> messages;

  public String getDetectTypeName() {
    return detectTypeName;
  }

  public void setDetectTypeName(String detectTypeName) {
    this.detectTypeName = detectTypeName;
  }

  public List<Message> getMessages() {
    return messages;
  }

  public void setMessages(List<Message> messages) {
    this.messages = messages;
  }

  @Override
  public String toString() {
    return "EventMsg{" +
        "detectTypeName='" + detectTypeName + '\'' +
        ", messages=" + messages +
        '}';
  }
}
